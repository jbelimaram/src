import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TranslationService } from '../../services/translation.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  standalone: false
})
export class HeaderComponent {
  currentLang: string = 'fr';

  constructor(
    private router: Router,
    private translationService: TranslationService
  ) {
    this.currentLang = this.translationService.getCurrentLang();
  }

  changeLanguage(lang: string) {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
  }

  logout() {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('current_user');
    this.router.navigate(['/login']);
  }
}