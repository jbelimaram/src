import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-simple-callback',
  standalone: true,
  imports: [CommonModule, IonicModule],
  template: `
    <ion-content class="ion-padding">
      <div style="display: flex; justify-content: center; align-items: center; height: 100%; flex-direction: column;">
        <ion-spinner name="crescent" style="width: 50px; height: 50px; color: #2E7D32;"></ion-spinner>
        <p style="margin-top: 20px; color: #2E7D32; font-weight: 500;">
          Redirection en cours...
        </p>
      </div>
    </ion-content>
  `
})
export class SimpleCallbackComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe({
      next: (params) => {
        const token = params['token'];
        if (token) {
          const user = this.authService.handleToken(token);
          if (!user.hasPassword) {
            this.router.navigate(['/set-password']);
          } else if (!user.hasFarm) {
            this.router.navigate(['/farm-setup']);
          } else {
            this.router.navigate(['/dashboard']);
          }
        } else {
          this.router.navigate(['/login']);
        }
      }
    });
  }
}