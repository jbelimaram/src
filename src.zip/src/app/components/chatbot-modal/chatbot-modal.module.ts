import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { TranslateModule } from '@ngx-translate/core';

import { ChatbotModalComponent } from './chatbot-modal.component';

@NgModule({
  declarations: [ChatbotModalComponent],
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TranslateModule
  ],
  exports: [ChatbotModalComponent]
})
export class ChatbotModalModule { }