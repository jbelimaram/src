import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { ChatbotService } from '../../services/chatbot.service';
import { OverlayService } from '../../services/overlay.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-chatbot-modal',
  templateUrl: './chatbot-modal.component.html',
  styleUrls: ['./chatbot-modal.component.scss'],
  standalone: false
})
export class ChatbotModalComponent implements OnInit, OnDestroy {
  @Input() isOpen: boolean = false;
  @Input() page: string = 'dashboard';
  @Output() closeModal = new EventEmitter<void>();

  @ViewChild('scrollMe') private messagesScrollContainer!: ElementRef;

  messages: Array<{text: string, sender: 'user' | 'bot', timestamp: Date}> = [];
  userInput: string = '';
  isLoading: boolean = false;
  hasNewResponse: boolean = false;
  currentTime: Date = new Date();
  welcomeMessage: string = '';

  private timeInterval: any;
  private overlaySubscription: Subscription | null = null;  // ⭐ Initialisé à null

  constructor(
    private chatbotService: ChatbotService,
    private overlayService: OverlayService
  ) {}

  ngOnInit() {
    this.setWelcomeMessage();
    this.startTimeUpdates();
    
    // S'abonner aux changements d'état des overlays
    this.overlaySubscription = this.overlayService.overlayState$.subscribe(state => {
      // Si un drawer (navigation ou notifications) s'ouvre, fermer le chatbot
      if ((state.navDrawerOpen || state.notificationsPanelOpen) && this.isOpen) {
        this.close();
      }
    });
  }

  ngOnDestroy() {
    if (this.timeInterval) {
      clearInterval(this.timeInterval);
    }
    if (this.overlaySubscription) {
      this.overlaySubscription.unsubscribe();
      this.overlaySubscription = null;
    }
  }

  private setWelcomeMessage() {
    const messages: {[key: string]: string} = {
      'dashboard': 'Bonjour ! Je suis votre assistant agricole. Comment puis-je vous aider avec votre ferme aujourd\'hui ? 😊',
      'diseases': 'Bonjour ! Je suis spécialiste en maladies des plantes. Quelle culture vous préoccupe ? 🔍',
      'irrigation': 'Bonjour ! Je vous conseille sur l\'irrigation. Quelle est votre question ? 💧',
      'history': 'Bonjour ! Je peux analyser l\'historique de votre ferme. 📊',
      'forum': 'Bonjour ! Je suis là pour vous guider sur le forum. 💬',
      'admin': 'Bonjour ! Je suis votre assistant d\'administration. Comment puis-je vous aider ? 👑'
    };
    this.welcomeMessage = messages[this.page] || 'Bonjour ! Je suis votre assistant agricole. Comment puis-je vous aider ? 🌱';
  }

  private startTimeUpdates() {
    this.timeInterval = setInterval(() => {
      this.currentTime = new Date();
    }, 60000);
  }

  toggle() {
    if (this.isOpen) {
      this.close();
    } else {
      this.open();
    }
  }

  open() {
    this.overlayService.setChatbotOpen(true);
    // La variable isOpen sera mise à jour via le subscription
    setTimeout(() => {
      this.hasNewResponse = false;
      this.scrollToBottom();
    }, 100);
  }

  close() {
    this.isOpen = false;
    this.overlayService.setChatbotOpen(false);
    this.closeModal.emit();
  }

  sendMessage(question?: string) {
    const message = question || this.userInput.trim();
    if (!message) return;

    this.messages.push({
      text: message,
      sender: 'user',
      timestamp: new Date()
    });
    this.userInput = '';
    this.scrollToBottom();

    this.isLoading = true;
    
    this.chatbotService.askQuestion(message, this.page).subscribe({
      next: (response) => {
        const botText = response.reponse || 'Je n\'ai pas compris votre question.';
        this.messages.push({
          text: botText,
          sender: 'bot',
          timestamp: new Date()
        });
        this.isLoading = false;
        this.scrollToBottom();
        this.hasNewResponse = true;
      },
      error: (error) => {
        console.error('Erreur API chatbot:', error);
        this.messages.push({
          text: 'Désolé, une erreur est survenue. Veuillez réessayer plus tard. 🤔',
          sender: 'bot',
          timestamp: new Date()
        });
        this.isLoading = false;
        this.scrollToBottom();
      }
    });
  }

  /**
   * Copie le texte dans le presse-papier
   * @param text Le texte à copier
   */
  copyToClipboard(text: string) {
    navigator.clipboard.writeText(text).then(() => {
      this.showCopyNotification('success');
    }).catch(() => {
      this.showCopyNotification('error');
    });
  }

  /**
   * Affiche une notification de copie
   * @param type 'success' ou 'error'
   */
  private showCopyNotification(type: 'success' | 'error') {
    const existingNotification = document.querySelector('.copy-notification');
    if (existingNotification) {
      existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `copy-notification ${type === 'error' ? 'error' : ''}`;
    notification.textContent = type === 'success' ? '✓ Texte copié !' : '❌ Erreur lors de la copie';
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (notification && notification.remove) {
        notification.remove();
      }
    }, 1500);
  }

  /**
   * Fait défiler la zone des messages vers le bas
   */
  private scrollToBottom(): void {
    setTimeout(() => {
      if (this.messagesScrollContainer) {
        const element = this.messagesScrollContainer.nativeElement;
        element.scrollTop = element.scrollHeight;
      }
    }, 100);
  }
}