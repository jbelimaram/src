import { Component } from '@angular/core';
import { Platform } from '@ionic/angular';
import { AuthService } from './services/auth.service'; // Ajustez le chemin selon votre projet
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false
})
export class AppComponent {
  
  constructor(
    private platform: Platform,
    private authService: AuthService  // Injection du service
  ) {
    this.initializeApp();
  }

  async initializeApp() {
    await this.platform.ready();
    console.log('✅ Application initialisée');

    // Vérification optionnelle de la session
    const userEmail = sessionStorage.getItem('current_user_email');
    if (userEmail) {
      try {
        // Utiliser checkEmail avec firstValueFrom au lieu de checkUserExists
        const response = await firstValueFrom(this.authService.checkEmail(userEmail));
        
        // Si l'email n'est pas disponible, c'est qu'il n'existe pas en base
        if (response.available === true) {
          // Email n'existe pas en base mais présent en session => nettoyage
          console.log('🔄 Session invalide - nettoyage');
          sessionStorage.clear();
        }
      } catch (error) {
        console.error('❌ Erreur vérification session:', error);
        sessionStorage.clear();
      }
    }
  }
}