import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone:false
})
export class HomePage implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
    console.log('Page d\'accueil AgriTunisie chargée');
  }

  navigateToLogin(): void {
    this.router.navigate(['/login']);
  }

  navigateToRegister(): void {
    this.router.navigate(['/register']);
  }

  handleImageError(event: any): void {
    const img = event.target as HTMLImageElement;
    img.src = 'assets/photos/logo-default.png';
  }
}