// src/app/services/forum.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { AuthService } from './auth.service';

export interface Topic {
  id: string;
  title: string;
  excerpt: string;
  fullContent: string;
  category: string;
  author: string;
  author_email: string;
  replies: number;
  views: number;
  solved: boolean;
  status: string;
  date: string;
  images?: string[];
}

// forum.service.ts - Mettre à jour l'interface Reply
export interface Reply {
  id: string;
  topicId: string;
  author: string;
  author_email: string;
  content: string;
  date: string;
  helpfulCount: number;
  helpful_users?: string[];  // ⭐ AJOUTER
  images?: string[];
  userHasMarkedHelpful?: boolean;  // ⭐ Pour le frontend
}

@Injectable({
  providedIn: 'root'
})
export class ForumService {
  private apiUrl = `${environment.apiUrl}/forum`;

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  // Méthode pour récupérer les headers avec le token
  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // Options pour les requêtes GET et DELETE
  private getAuthOptions(): { headers: HttpHeaders } {
    return { headers: this.getHeaders() };
  }

  // Options pour les requêtes POST et PUT
  private getAuthPostOptions(): { headers: HttpHeaders } {
    return { headers: this.getHeaders() };
  }

  // Récupérer tous les sujets (avec token)
  getTopics(category?: string, sortBy?: string): Observable<Topic[]> {
    let url = `${this.apiUrl}/topics?`;
    if (category && category !== 'all') {
      url += `category=${category}&`;
    }
    if (sortBy) {
      url += `sort_by=${sortBy}`;
    }
    const options = this.getAuthOptions();
    return this.http.get<Topic[]>(url, options);
  }

  // Récupérer un sujet par son ID (avec token)
  getTopic(id: string): Observable<Topic> {
    const options = this.getAuthOptions();
    return this.http.get<Topic>(`${this.apiUrl}/topics/${id}`, options);
  }

  // Créer un nouveau sujet (avec token)
  createTopic(topic: Partial<Topic>): Observable<Topic> {
    const options = this.getAuthPostOptions();
    return this.http.post<Topic>(`${this.apiUrl}/topics`, topic, options);
  }

  // Récupérer les réponses d'un sujet (avec token)
  getReplies(topicId: string): Observable<Reply[]> {
    const options = this.getAuthOptions();
    return this.http.get<Reply[]>(`${this.apiUrl}/replies/${topicId}`, options);
  }

  // Ajouter une réponse (avec token)
  addReply(topicId: string, content: string, images: string[] = []): Observable<Reply> {
    const options = this.getAuthPostOptions();
    return this.http.post<Reply>(`${this.apiUrl}/replies`, { topicId, content, images }, options);
  }

  // forum.service.ts - La méthode markHelpful reste identique
markHelpful(replyId: string): Observable<any> {
  const options = this.getAuthPostOptions();
  return this.http.put(`${this.apiUrl}/replies/${replyId}/helpful`, {}, options);
}

  // Récupérer tous les sujets pour l'admin (avec token)
  getAdminTopics(status?: string): Observable<Topic[]> {
    let url = `${environment.apiUrl}/forum/admin/topics`;
    if (status && status !== 'all') {
      url += `?status=${status}`;
    }
    const options = this.getAuthOptions();
    return this.http.get<Topic[]>(url, options);
  }

  // Approuver un sujet (admin) (avec token)
  approveTopic(topicId: string): Observable<any> {
    const options = this.getAuthPostOptions();
    return this.http.put(`${environment.apiUrl}/forum/admin/topics/${topicId}/approve`, {}, options);
  }

  // Rejeter un sujet (admin) (avec token)
  rejectTopic(topicId: string): Observable<any> {
    const options = this.getAuthPostOptions();
    return this.http.put(`${environment.apiUrl}/forum/admin/topics/${topicId}/reject`, {}, options);
  }

  // Supprimer un sujet (admin) (avec token)
  deleteTopicAdmin(topicId: string): Observable<any> {
    const options = this.getAuthOptions();
    return this.http.delete(`${environment.apiUrl}/forum/admin/topics/${topicId}`, options);
  }

  // Récupérer mes sujets (avec token)
  getMyTopics(): Observable<Topic[]> {
    const options = this.getAuthOptions();
    return this.http.get<Topic[]>(`${this.apiUrl}/my-topics`, options);
  }

  // Signaler un sujet (avec token)
  reportTopic(topicId: string): Observable<any> {
    const options = this.getAuthPostOptions();
    return this.http.post(`${this.apiUrl}/topics/${topicId}/report`, {}, options);
  }

  // Upload d'image (avec token)
  uploadImage(file: File): Observable<{ url: string }> {
    const formData = new FormData();
    formData.append('file', file);
    
    const token = this.authService.getToken();
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
    
    return this.http.post<{ url: string }>(`${this.apiUrl}/upload`, formData, { headers }).pipe(
      map(response => {
        if (response.url.startsWith('http')) {
          return response;
        }
        return {
          url: `${environment.baseUrl}${response.url.startsWith('/') ? '' : '/'}${response.url}`
        };
      })
    );
  }
  deleteTopic(topicId: string): Observable<any> {
  return this.http.delete(`${this.apiUrl}/topics/${topicId}`, { headers: this.getHeaders() });
  }
}