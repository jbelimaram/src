import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class FarmSetupGuard implements CanActivate {
  
  constructor(
    private router: Router,
    private authService: AuthService
  ) {}

  canActivate(): boolean {
    console.log('🛡️ FarmSetupGuard - vérification');
    
    // Cas 1: Inscription en cours (temp_registration existe)
    const temp = sessionStorage.getItem('temp_registration');
    if (temp) {
      console.log('  ✅ Inscription en cours - accès autorisé');
      return true;
    }
    
    // Cas 2: Utilisateur connecté (Google ou login normal) mais sans ferme
    const user = this.authService.getCurrentUser();
    if (user && !user.hasFarm) {
      console.log('  ✅ Utilisateur connecté sans ferme - accès autorisé');
      return true;
    }
    
    // Cas 3: Utilisateur avec ferme déjà configurée
    if (user && user.hasFarm) {
      // Redirection selon le rôle
      if (user.role === 'admin') {
        console.log('  ⚠️ Admin avec ferme → redirection admin');
        this.router.navigate(['/admin']);
      } else {
        console.log('  ⚠️ Ferme déjà configurée → redirection dashboard');
        this.router.navigate(['/dashboard']);
      }
      return false;
    }
    
    // Cas 4: Aucun utilisateur valide
    console.log('  ❌ Aucun utilisateur valide → redirection accueil');
    this.router.navigate(['/accueil']);
    return false;
  }
}