import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ResetPasswordGuard implements CanActivate {

  constructor(
    private router: Router,
    private authService: AuthService
  ) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    // If user is already logged in, redirect to home
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/accueil']);
      return false;
    }

    const token = route.queryParams['token'];
    if (!this.isValidToken(token)) {
      this.router.navigate(['/login']);
      return false;
    }

    return true;
  }

  /**
   * Basic validation – must look like a JWT (three parts, not empty, reasonable length)
   */
  private isValidToken(token: string | undefined): boolean {
    if (!token || typeof token !== 'string') return false;
    const parts = token.split('.');
    if (parts.length !== 3) return false;
    if (parts.some(part => part.length === 0)) return false;
    if (token.length < 20) return false;
    return true;
  }
}