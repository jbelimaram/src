import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../environments/environment';
export interface WeatherData {
  temp: number;
  humidity: number;
  description: string;
  icon: string;
  wind: number;
  city: string;
}

export interface ForecastDay {
  date: Date;
  temp: number;
  icon: string;
  description: string;
}

@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  // Changement : utiliser le backend comme proxy au lieu d'appeler OpenWeatherMap directement
  private backendUrl = `${environment.apiUrl}/api/weather`;
  constructor(private http: HttpClient) {}

  /**
   * Récupère la météo actuelle à partir de coordonnées géographiques (via backend proxy)
   * @param lat Latitude
   * @param lon Longitude
   */
  getWeatherByCoords(lat: number, lon: number): Observable<WeatherData> {
    return this.http.get(`${this.backendUrl}/current`, {
      params: {
        lat: lat.toString(),
        lon: lon.toString()
      }
    }).pipe(
      map((response: any) => ({
        temp: Math.round(response.main.temp),
        humidity: response.main.humidity,
        description: response.weather[0].description,
        icon: response.weather[0].icon,
        wind: Math.round(response.wind.speed * 3.6),
        city: response.name
      }))
    );
  }

  /**
   * Récupère la météo actuelle à partir du nom d'une ville (via backend proxy)
   * @param city Nom de la ville
   */
  getWeatherByCity(city: string): Observable<WeatherData> {
    return this.http.get(`${this.backendUrl}/by-city`, {
      params: { city: city }
    }).pipe(
      map((response: any) => ({
        temp: Math.round(response.main.temp),
        humidity: response.main.humidity,
        description: response.weather[0].description,
        icon: response.weather[0].icon,
        wind: Math.round(response.wind.speed * 3.6),
        city: response.name
      }))
    );
  }

  /**
   * Récupère les prévisions sur 5 jours à partir de coordonnées (via backend proxy)
   * @param lat Latitude
   * @param lon Longitude
   */
  getForecastByCoords(lat: number, lon: number): Observable<ForecastDay[]> {
    return this.http.get(`${this.backendUrl}/forecast`, {
      params: {
        lat: lat.toString(),
        lon: lon.toString()
      }
    }).pipe(
      map((response: any) => this.groupForecastByDay(response.list))
    );
  }

  /**
   * Récupère les prévisions sur 5 jours à partir du nom d'une ville (via backend proxy)
   * @param city Nom de la ville
   */
  getForecastByCity(city: string): Observable<ForecastDay[]> {
    return this.http.get(`${this.backendUrl}/forecast-by-city`, {
      params: { city: city }
    }).pipe(
      map((response: any) => this.groupForecastByDay(response.list))
    );
  }

  /**
   * Fallback météo : utilise Tunis par défaut.
   */
  getWeatherFallback(): Observable<WeatherData> {
    return this.getWeatherByCity('Tunis');
  }

  /**
   * Fallback prévisions : utilise Tunis par défaut.
   */
  getForecastFallback(): Observable<ForecastDay[]> {
    return this.getForecastByCity('Tunis');
  }

  /**
   * Regroupe les prévisions par jour et renvoie les 5 prochains jours (hors aujourd'hui).
   * @param list Liste des prévisions horaires fournies par l'API
   */
  private groupForecastByDay(list: any[]): ForecastDay[] {
    const dailyMap = new Map<string, any>();
    
    list.forEach((item: any) => {
      const date = new Date(item.dt * 1000);
      const dateKey = date.toISOString().split('T')[0];
      
      if (!dailyMap.has(dateKey)) {
        dailyMap.set(dateKey, {
          date: new Date(dateKey),
          temp: Math.round(item.main.temp),
          icon: item.weather[0].icon,
          description: item.weather[0].description
        });
      } else if (date.getHours() === 12) {
        dailyMap.set(dateKey, {
          date: new Date(dateKey),
          temp: Math.round(item.main.temp),
          icon: item.weather[0].icon,
          description: item.weather[0].description
        });
      }
    });
    
    const today = new Date().toISOString().split('T')[0];
    const forecastDays = Array.from(dailyMap.values())
      .filter((day: any) => {
        const dayStr = day.date.toISOString().split('T')[0];
        return dayStr > today;
      })
      .slice(0, 5);
    
    return forecastDays;
  }
}