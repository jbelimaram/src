import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable, firstValueFrom } from 'rxjs';
import { environment } from '../../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = environment.apiUrl;   // instead of 'http://127.0.0.1:8000'
  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  checkUserExists(email: string): Observable<boolean> {
    return this.http.get<boolean>(`${this.apiUrl}/check-user-exists`, { params: { email } });
  }

  checkEmail(email: string): Observable<{available: boolean}> {
    return this.http.get<{available: boolean}>(`${this.apiUrl}/check-email`, { params: { email } });
  }

  handleToken(token: string): any {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      console.log('✅ Token décodé:', payload);
      
      const user = {
        email: payload.email || payload.sub,
        username: payload.username || payload.email?.split('@')[0] || 'Utilisateur',
        hasFarm: payload.hasFarm === true,
        role: payload.role || 'agriculteur',
        hasPassword: payload.has_password === true   // ← new
      };
      
      sessionStorage.setItem('current_user', JSON.stringify(user));
      sessionStorage.setItem('current_user_email', user.email);
      sessionStorage.setItem('farm_configured', user.hasFarm ? 'true' : 'false');
      sessionStorage.setItem('user_role', user.role);
      sessionStorage.setItem('has_password', user.hasPassword ? 'true' : 'false');
      sessionStorage.setItem('jwt_token', token);
      
      console.log('✅ Utilisateur stocké dans sessionStorage:', user);
      return user;
    } catch (error) {
      console.error('❌ Erreur décodage token:', error);
      throw new Error('Invalid token');
    }
  }

  async login(email: string, password: string): Promise<any> {
  try {
    const response: any = await firstValueFrom(
      this.http.post(`${this.apiUrl}/login`, { email, password })
    );
    
    if (!response.email || !response.username) {
      throw new Error('Réponse invalide du serveur');
    }

    // Save token if present
    if (response.token) {
      sessionStorage.setItem('jwt_token', response.token);
    }

    const user = {
      email: response.email,
      username: response.username,
      hasFarm: response.hasFarm === true,
      role: response.role || 'agriculteur',
      hasPassword: true   // Email users always have a password
    };

    sessionStorage.setItem('current_user', JSON.stringify(user));
    sessionStorage.setItem('current_user_email', email);
    sessionStorage.setItem('farm_configured', user.hasFarm ? 'true' : 'false');
    sessionStorage.setItem('user_role', user.role);
    sessionStorage.setItem('has_password', 'true');

    return user;
  } catch (error) {
    console.error('Erreur login:', error);
    throw error;
  }
}
  
  setCurrentUser(user: any): void {
    if (user) {
      sessionStorage.setItem('current_user', JSON.stringify(user));
      sessionStorage.setItem('current_user_email', user.email);
      sessionStorage.setItem('farm_configured', user.hasFarm ? 'true' : 'false');
      sessionStorage.setItem('user_role', user.role || 'agriculteur');
      sessionStorage.setItem('has_password', user.hasPassword ? 'true' : 'false');
    }
  }

  getCurrentUserEmail(): string | null {
    return sessionStorage.getItem('current_user_email');
  }

  isAuthenticated(): boolean {
    return !!sessionStorage.getItem('current_user');
  }

  getCurrentUser(): any {
    const userStr = sessionStorage.getItem('current_user');
    if (userStr) {
      try {
        const user = JSON.parse(userStr);
        if (!user.role) {
          user.role = sessionStorage.getItem('user_role') || 'agriculteur';
        }
        if (user.hasPassword === undefined) {
          user.hasPassword = sessionStorage.getItem('has_password') === 'true';
        }
        return user;
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  getUserRole(): string | null {
    return sessionStorage.getItem('user_role');
  }

  getToken(): string | null {
    return sessionStorage.getItem('jwt_token');
  }

  isAdmin(): boolean {
    const role = this.getUserRole();
    return role === 'admin';
  }

  isFarmer(): boolean {
    const role = this.getUserRole();
    return role === 'agriculteur';
  }

  hasFarm(): boolean {
    const farmConfigured = sessionStorage.getItem('farm_configured');
    if (farmConfigured) {
      return farmConfigured === 'true';
    }
    const user = this.getCurrentUser();
    return user?.hasFarm === true;
  }

  logout(): void {
    sessionStorage.clear();
    this.router.navigate(['/accueil']);
  }

  validateEmail(email: string): boolean {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }
}