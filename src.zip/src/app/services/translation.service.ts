import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class TranslationService {

  constructor(private translate: TranslateService) {
    // Initialisation
    this.translate.addLangs(['fr', 'ar']);
    this.translate.setDefaultLang('fr');
    
    // FORCER le français et IGNORER localStorage
    this.forceFrench();
  }

  private forceFrench() {
    // Effacer toute langue sauvegardée
    localStorage.removeItem('language');
    
    // Forcer le français
    this.switchLanguage('fr');
    console.log('🚀 Force française au démarrage');
  }

  switchLanguage(lang: string) {
    this.translate.use(lang);
    
    // Gestion RTL
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
    
    // Sauvegarder pour les prochaines visites
    localStorage.setItem('language', lang);
    console.log('Langue changée:', lang);
  }

  getCurrentLang(): string {
    return this.translate.currentLang || 'fr';
  }
}