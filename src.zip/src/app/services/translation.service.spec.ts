import { TestBed } from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { TranslationService } from './translation.service';

describe('TranslationService', () => {
  let service: TranslationService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      providers: [TranslateService]
    });
    service = TestBed.inject(TranslationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should switch language to french', () => {
    service.switchLanguage('fr');
    expect(service.getCurrentLang()).toBe('fr');
  });

  it('should switch language to arabic', () => {
    service.switchLanguage('ar');
    expect(service.getCurrentLang()).toBe('ar');
  });
});