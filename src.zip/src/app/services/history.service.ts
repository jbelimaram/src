import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { environment } from '../../environments/environment';
export interface HistoryEntry {
  _id?: string;
  user_email: string;
  operation_type: 'disease_detection' | 'yield_prediction' | 'irrigation_decision';
  operation_key: string;
  details: any;
  status: 'success' | 'warning' | 'error' | 'info';
  created_at?: Date;
}

@Injectable({
  providedIn: 'root'
})
export class HistoryService {
  private apiUrl = environment.apiUrl;   // remove hardcoded string

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  private getAuthOptions() {
    return { headers: this.getHeaders() };
  }

  addHistory(entry: HistoryEntry): Observable<any> {
    return this.http.post(`${this.apiUrl}/api/history`, entry);
  }

  getHistory(userEmail: string, limit: number = 100, skip: number = 0): Observable<{entries: HistoryEntry[], total: number}> {
    return this.http.get<{entries: HistoryEntry[], total: number}>(
      `${this.apiUrl}/api/history/${userEmail}?limit=${limit}&skip=${skip}`,
      this.getAuthOptions()
    );
  }

  // Supprimer une entrée spécifique
  deleteHistoryEntry(entryId: string, userEmail: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/api/history/${userEmail}/${entryId}`, this.getAuthOptions());
  }

  // Supprimer tout l'historique d'un utilisateur
  clearAllHistory(userEmail: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/api/history/${userEmail}`, this.getAuthOptions());
  }
}