import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthStateService {
  
  constructor(private authService: AuthService) {}
  
  getCurrentUserEmail(): string | null {
    return sessionStorage.getItem('current_user_email');
  }
  
  hasFarmConfiguration(): boolean {
    return this.authService.hasFarm();
  }

  /**
   * Récupère le rôle de l'utilisateur
   */
  getCurrentUserRole(): string | null {
    return sessionStorage.getItem('user_role');
  }

  /**
   * Vérifie si l'utilisateur est un administrateur
   */
  isAdmin(): boolean {
    return this.getCurrentUserRole() === 'admin';
  }

  /**
   * Vérifie si l'utilisateur est un agriculteur
   */
  isFarmer(): boolean {
    return this.getCurrentUserRole() === 'agriculteur';
  }
}