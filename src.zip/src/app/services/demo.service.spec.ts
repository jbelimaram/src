// ============================================
// FICHIER: src/app/services/demo.service.spec.ts
// ============================================

import { TestBed } from '@angular/core/testing';
import { DemoService } from './demo.service';

describe('DemoService', () => {
  let service: DemoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DemoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return parcelles', () => {
    const parcelles = service.getParcelles();
    expect(parcelles.length).toBe(3);
    expect(parcelles[0].name).toBe('Champ Nord');
  });

  it('should return diseases', () => {
    const diseases = service.getDiseases();
    expect(diseases.length).toBeGreaterThan(0);
  });

  it('should return history data', () => {
    const history = service.getHistoryData();
    expect(history.length).toBeGreaterThan(0);
  });

  it('should return forum topics', () => {
    const topics = service.getForumTopics();
    expect(topics.length).toBeGreaterThan(0);
  });

  it('should calculate irrigation decision', () => {
    const metrics = {
      soilMoisture: 50,
      temperature: 24,
      airHumidity: 60,
      timestamp: new Date()
    };
    const decision = service.getIrrigationDecision('P1', metrics);
    expect(decision).toBeDefined();
    expect(decision.confidence).toBeGreaterThan(0);
  });

  it('should analyze disease', async () => {
    const result = await service.analyzeDisease();
    expect(result).toBeDefined();
    expect(result.disease).toBeDefined();
  });

  it('should predict yield', () => {
    const params = {
      crop: 'Blé',
      ph: 6.5,
      organicMatter: 2.5,
      irrigationType: 'aspersion'
    };
    const prediction = service.predictYield(params);
    expect(prediction).toBeDefined();
    expect(prediction.yieldValue).toBeGreaterThan(0);
  });
});