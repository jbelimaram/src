import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface OverlayState {
  navDrawerOpen: boolean;
  notificationsPanelOpen: boolean;
  chatbotOpen: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class OverlayService {
  private overlayState = new BehaviorSubject<OverlayState>({
    navDrawerOpen: false,
    notificationsPanelOpen: false,
    chatbotOpen: false
  });

  // Observable pour écouter les changements d'état
  overlayState$: Observable<OverlayState> = this.overlayState.asObservable();

  constructor() {}

  /**
   * Met à jour l'état du drawer de navigation
   * Ferme automatiquement le chatbot si le drawer s'ouvre
   */
  setNavDrawerOpen(isOpen: boolean): void {
    const currentState = this.overlayState.getValue();
    
    // Si on ouvre le drawer et que le chatbot est ouvert, on le ferme
    if (isOpen && currentState.chatbotOpen) {
      this.setChatbotOpen(false);
    }
    
    this.overlayState.next({
      ...currentState,
      navDrawerOpen: isOpen
    });
  }

  /**
   * Met à jour l'état du panneau de notifications
   * Ferme automatiquement le chatbot si le panneau s'ouvre
   */
  setNotificationsPanelOpen(isOpen: boolean): void {
    const currentState = this.overlayState.getValue();
    
    // Si on ouvre le panneau et que le chatbot est ouvert, on le ferme
    if (isOpen && currentState.chatbotOpen) {
      this.setChatbotOpen(false);
    }
    
    this.overlayState.next({
      ...currentState,
      notificationsPanelOpen: isOpen
    });
  }

  /**
   * Met à jour l'état du chatbot
   * Ferme automatiquement les drawers si le chatbot s'ouvre
   */
  setChatbotOpen(isOpen: boolean): void {
    const currentState = this.overlayState.getValue();
    
    // Si on ouvre le chatbot et qu'un drawer est ouvert, on le ferme
    if (isOpen && (currentState.navDrawerOpen || currentState.notificationsPanelOpen)) {
      this.overlayState.next({
        ...currentState,
        navDrawerOpen: false,
        notificationsPanelOpen: false,
        chatbotOpen: isOpen
      });
    } else {
      this.overlayState.next({
        ...currentState,
        chatbotOpen: isOpen
      });
    }
  }

  /**
   * Ferme tous les overlays (drawers et chatbot)
   */
  closeAllOverlays(): void {
    this.overlayState.next({
      navDrawerOpen: false,
      notificationsPanelOpen: false,
      chatbotOpen: false
    });
  }

  /**
   * Récupère l'état actuel des overlays
   */
  getCurrentState(): OverlayState {
    return this.overlayState.getValue();
  }

  /**
   * Vérifie si un overlay est ouvert
   */
  isAnyOverlayOpen(): boolean {
    const state = this.overlayState.getValue();
    return state.navDrawerOpen || state.notificationsPanelOpen || state.chatbotOpen;
  }
}