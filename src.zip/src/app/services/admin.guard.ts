import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthStateService } from '../services/auth-state.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {
  
  constructor(
    private router: Router,
    private authState: AuthStateService
  ) {}

  canActivate(): boolean {
    console.log('🛡️ AdminGuard - vérification');
    
    const userEmail = this.authState.getCurrentUserEmail();
    const userRole = this.authState.getCurrentUserRole();
    
    if (!userEmail) {
      console.log('  ❌ Pas d\'email utilisateur, redirection vers login');
      this.router.navigate(['/login']);
      return false;
    }
    
    // Vérifier que l'utilisateur est bien un administrateur
    if (userRole !== 'admin') {
      console.log('  ❌ Accès refusé - réservé aux administrateurs');
      
      // Si c'est un agriculteur, rediriger vers le dashboard
      if (userRole === 'agriculteur') {
        this.router.navigate(['/dashboard']);
      } else {
        this.router.navigate(['/accueil']);
      }
      return false;
    }
    
    console.log('  ✅ Accès autorisé à la page admin');
    return true;
  }
}