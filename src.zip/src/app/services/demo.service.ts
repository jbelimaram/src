// ============================================
// FICHIER: src/app/services/demo.service.ts
// ============================================

import { Injectable } from '@angular/core';
import { Observable, interval, map } from 'rxjs';

// ========== INTERFACES ==========

export interface DemoParcelle {
  id: string;
  name: string;
  cropName: string;
  area: number;
  soilType: string;
  soilTypeLabel: string;
}

export interface DemoMetrics {
  soilMoisture: number;
  temperature: number;
  airHumidity: number;
  timestamp: Date;
}

export interface DemoIrrigation {
  active: boolean;
  confidence: number;
  explanation: string;
}

export interface DemoDisease {
  id: number;
  name: string;
  plant: string;
  description: string;
  symptoms: string[];
  treatment: string;
  severity: 'faible' | 'moyenne' | 'haute';
  imageUrl: string;
}

export interface DemoDiseaseAnalysis {
  disease: string;
  plant: string;
  probability: number;
  treatment: string;
  severity: string;
  symptoms: string[];
}

export interface DemoYieldParams {
  crop: string;
  ph: number;
  organicMatter: number;
  irrigationType: string;
  area?: number;
}

export interface DemoYieldPrediction {
  crop: string;
  yieldValue: number;
  yieldUnit: string;
  potential: number;
  factors: { name: string; impact: number; color: string }[];
  recommendations: string[];
}

export interface DemoHistoryItem {
  date: string;
  type: 'irrigation' | 'maladie' | 'rendement' | 'alerte';
  operation: string;
  details: string;
  status: 'success' | 'warning' | 'error' | 'info';
}

export interface DemoForumTopic {
  id: number;
  title: string;
  excerpt: string;
  category: 'irrigation' | 'diseases';
  author: string;
  replies: number;
  views: number;
  date: string;
  avatar?: string;
}

@Injectable({
  providedIn: 'root'
})
export class DemoService {
  
  // ========== DONNÉES STATIQUES ==========
  
  private demoParcelles: DemoParcelle[] = [
    { 
      id: 'P1', 
      name: 'Champ Nord', 
      cropName: 'Tomates', 
      area: 2.5, 
      soilType: 'loamy', 
      soilTypeLabel: 'Limoneux' 
    },
    { 
      id: 'P2', 
      name: 'Verger Est', 
      cropName: 'Oliviers', 
      area: 3.0, 
      soilType: 'clay', 
      soilTypeLabel: 'Argileux' 
    },
    { 
      id: 'P3', 
      name: 'Serre Ouest', 
      cropName: 'Fraises', 
      area: 0.8, 
      soilType: 'sandy', 
      soilTypeLabel: 'Sableux' 
    }
  ];

  private diseasesDatabase: DemoDisease[] = [
    {
      id: 1,
      name: "Mildiou",
      plant: "Tomate",
      description: "Maladie fongique grave causée par Phytophthora infestans. Elle se développe rapidement en conditions humides.",
      symptoms: [
        "Taches huileuses brun-vert sur feuilles",
        "Moisissure blanche au revers des feuilles",
        "Feuilles qui se dessèchent",
        "Taches brunes sur les fruits"
      ],
      treatment: "Appliquer de la bouillie bordelaise (20g/L) tous les 10 jours. Enlever et détruire les parties atteintes. Espacer les plants pour améliorer la circulation d'air.",
      severity: "haute",
      imageUrl: "assets/demo/mildiou.jpg"
    },
    {
      id: 2,
      name: "Oïdium",
      plant: "Courgette",
      description: "Maladie fongique apparaissant en période chaude et sèche. Forme un feutrage blanc sur les feuilles.",
      symptoms: [
        "Poudre blanche sur les feuilles",
        "Feuilles qui jaunissent",
        "Croissance ralentie",
        "Déformation des feuilles"
      ],
      treatment: "Pulvérisations de soufre ou de bicarbonate de soude (5g/L). Assurer une bonne aération. Arroser au pied sans mouiller le feuillage.",
      severity: "moyenne",
      imageUrl: "assets/demo/oidium.jpg"
    },
    {
      id: 3,
      name: "Rouille brune",
      plant: "Blé",
      description: "Maladie fongique très répandue dans les régions céréalières. Réduit la photosynthèse et le rendement.",
      symptoms: [
        "Pustules brunes-orangées sur feuilles",
        "Présence de poudre orange",
        "Feuilles qui sèchent",
        "Plantes affaiblies"
      ],
      treatment: "Fongicides à base de triazoles. Utiliser des variétés résistantes. Rotation des cultures.",
      severity: "moyenne",
      imageUrl: "assets/demo/rouille.jpg"
    },
    {
      id: 4,
      name: "Alternariose",
      plant: "Pomme de terre",
      description: "Maladie fongique causée par Alternaria solani, affectant feuilles et tubercules.",
      symptoms: [
        "Taches brunes concentriques",
        "Nécrose des feuilles",
        "Lésions sur tiges",
        "Pourriture des tubercules"
      ],
      treatment: "Fongicides à base de mancozèbe. Rotation des cultures. Éviter l'humidité sur le feuillage.",
      severity: "moyenne",
      imageUrl: "assets/demo/alternariose.jpg"
    }
  ];

  private historyData: DemoHistoryItem[] = [
    { 
      date: '2025-05-15 08:30', 
      type: 'irrigation', 
      operation: 'Arrosage automatique', 
      details: 'Durée: 30min - Volume: 500L - Parcelle: Champ Nord', 
      status: 'success' 
    },
    { 
      date: '2025-05-15 09:15', 
      type: 'maladie', 
      operation: 'Analyse des plantes', 
      details: 'Détection: Mildiou sur tomates - Traitement recommandé', 
      status: 'warning' 
    },
    { 
      date: '2025-05-14 10:30', 
      type: 'alerte', 
      operation: 'Niveau d\'eau bas', 
      details: 'Réservoir principal à 20% de capacité', 
      status: 'warning' 
    },
    { 
      date: '2025-05-14 16:45', 
      type: 'irrigation', 
      operation: 'Arrosage programmé', 
      details: 'Durée: 45min - Parcelle: Verger Est', 
      status: 'success' 
    },
    { 
      date: '2025-05-13 11:20', 
      type: 'maladie', 
      operation: 'Scan des cultures', 
      details: 'Aucune maladie détectée - Toutes les plantes sont saines', 
      status: 'success' 
    },
    { 
      date: '2025-05-13 14:30', 
      type: 'rendement', 
      operation: 'Prédiction rendement', 
      details: 'Blé: 3800 kg/ha estimés - Potentiel 108%', 
      status: 'success' 
    },
    { 
      date: '2025-05-12 09:00', 
      type: 'alerte', 
      operation: 'Capteur défaillant', 
      details: 'Capteur d\'humidité #4 ne répond pas', 
      status: 'error' 
    }
  ];

  private forumTopics: DemoForumTopic[] = [
    { 
      id: 1, 
      title: "Problème de mildiou sur mes tomates", 
      excerpt: "Depuis une semaine, mes plants de tomates présentent des taches brunes...", 
      category: "diseases", 
      author: "Karim Ben Salah", 
      replies: 8, 
      views: 145, 
      date: "2025-05-10", 
      avatar: "assets/avatars/user1.jpg" 
    },
    { 
      id: 2, 
      title: "Optimisation du système d'irrigation", 
      excerpt: "Comment économiser l'eau avec le goutte-à-goutte ? Retours d'expérience...", 
      category: "irrigation", 
      author: "Fatma Trabelsi", 
      replies: 12, 
      views: 210, 
      date: "2025-05-12", 
      avatar: "assets/avatars/user2.jpg" 
    },
    { 
      id: 3, 
      title: "Traitement naturel contre l'oïdium", 
      excerpt: "Je cherche des solutions bio pour traiter l'oïdium sur mes courgettes...", 
      category: "diseases", 
      author: "Mohamed Ali", 
      replies: 5, 
      views: 89, 
      date: "2025-05-14", 
      avatar: "assets/avatars/user3.jpg" 
    },
    { 
      id: 4, 
      title: "Programmation irrigation connectée", 
      excerpt: "Quel système d'automatisation recommandez-vous pour 5 hectares ?", 
      category: "irrigation", 
      author: "Leila Mabrouk", 
      replies: 7, 
      views: 112, 
      date: "2025-05-15", 
      avatar: "assets/avatars/user4.jpg" 
    }
  ];

  private baseMetrics = {
    soilMoisture: 58,
    temperature: 24,
    airHumidity: 62
  };

  constructor() { 
    console.log('✅ DemoService initialisé');
  }

  // ========== MÉTHODES PUBLIQUES ==========

  /**
   * Récupère la liste des parcelles de démonstration
   */
  getParcelles(): DemoParcelle[] {
    return [...this.demoParcelles];
  }

  /**
   * Récupère une parcelle par son ID
   */
  getParcelleById(id: string): DemoParcelle | undefined {
    return this.demoParcelles.find(p => p.id === id);
  }

  /**
   * Récupère la base de données des maladies
   */
  getDiseases(): DemoDisease[] {
    return [...this.diseasesDatabase];
  }

  /**
   * Récupère une maladie par son ID
   */
  getDiseaseById(id: number): DemoDisease | undefined {
    return this.diseasesDatabase.find(d => d.id === id);
  }

  /**
   * Récupère les données historiques
   */
  getHistoryData(): DemoHistoryItem[] {
    return [...this.historyData];
  }

  /**
   * Récupère les données historiques filtrées par type
   */
  getHistoryDataByType(type: string): DemoHistoryItem[] {
    return this.historyData.filter(item => item.type === type);
  }

  /**
   * Récupère les sujets du forum
   */
  getForumTopics(): DemoForumTopic[] {
    return [...this.forumTopics];
  }

  /**
   * Récupère les sujets du forum par catégorie
   */
  getForumTopicsByCategory(category: string): DemoForumTopic[] {
    return this.forumTopics.filter(topic => topic.category === category);
  }

  /**
   * Flux de métriques en temps réel simulées
   */
  getMetricsStream(): Observable<DemoMetrics> {
    return interval(4000).pipe(
      map(() => ({
        soilMoisture: this.simulateValue(this.baseMetrics.soilMoisture, 3, 40, 70),
        temperature: this.simulateValue(this.baseMetrics.temperature, 1, 20, 28),
        airHumidity: this.simulateValue(this.baseMetrics.airHumidity, 2, 50, 75),
        timestamp: new Date()
      }))
    );
  }

  /**
   * Calcule la décision d'irrigation IA
   */
  getIrrigationDecision(parcelleId: string, metrics: DemoMetrics): DemoIrrigation {
    const parcelle = this.demoParcelles.find(p => p.id === parcelleId);
    
    let seuilHumidite = 45;
    if (parcelle?.cropName === 'Tomates') seuilHumidite = 55;
    if (parcelle?.cropName === 'Fraises') seuilHumidite = 60;
    if (parcelle?.cropName === 'Oliviers') seuilHumidite = 40;
    
    const active = metrics.soilMoisture < seuilHumidite;
    const confidence = this.calculateConfidence(metrics, parcelle);
    
    let explanation = '';
    if (active) {
      explanation = `L'IA active l'irrigation car l'humidité du sol (${metrics.soilMoisture.toFixed(1)}%) est inférieure au seuil de ${seuilHumidite}% optimal pour les ${parcelle?.cropName || 'cette culture'}.`;
    } else {
      explanation = `L'IA désactive l'irrigation : l'humidité du sol (${metrics.soilMoisture.toFixed(1)}%) est suffisante pour les ${parcelle?.cropName || 'cette culture'}. Économie d'eau estimée : 120L.`;
    }
    
    return { active, confidence, explanation };
  }

  /**
   * Simule une analyse de maladie à partir d'une image
   */
  analyzeDisease(imageFile?: File): Promise<DemoDiseaseAnalysis> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const random = this.diseasesDatabase[Math.floor(Math.random() * this.diseasesDatabase.length)];
        resolve({
          disease: random.name,
          plant: random.plant,
          probability: 75 + Math.floor(Math.random() * 20),
          treatment: random.treatment,
          severity: random.severity,
          symptoms: random.symptoms.slice(0, 3)
        });
      }, 2000);
    });
  }

  /**
   * Prédit le rendement en fonction des paramètres
   */
  predictYield(params: DemoYieldParams): DemoYieldPrediction {
    const baseYields: {[key: string]: number} = {
      'Blé': 6000,
      'Maïs': 8000,
      'Tomate': 45000,
      'Olivier': 3000,
      'Pomme de terre': 35000,
      'Orge': 5000
    };
    
    const baseYield = baseYields[params.crop] || 5000;
    
    let factor = 1.0;
    const factors = [];
    
    // Facteur pH
    if (params.ph >= 6 && params.ph <= 7) {
      factor *= 1.12;
      factors.push({ name: 'pH optimal', impact: 12, color: '#4CAF50' });
    } else if (params.ph < 5.5 || params.ph > 7.5) {
      factor *= 0.85;
      factors.push({ name: 'pH défavorable', impact: -15, color: '#F44336' });
    } else {
      factor *= 1.0;
      factors.push({ name: 'pH acceptable', impact: 0, color: '#FF9800' });
    }
    
    // Facteur matière organique
    if (params.organicMatter > 3) {
      factor *= 1.08;
      factors.push({ name: 'Matière organique élevée', impact: 8, color: '#4CAF50' });
    } else if (params.organicMatter < 2) {
      factor *= 0.92;
      factors.push({ name: 'Matière organique faible', impact: -8, color: '#F44336' });
    } else {
      factor *= 1.0;
      factors.push({ name: 'Matière organique moyenne', impact: 0, color: '#FF9800' });
    }
    
    // Facteur irrigation
    if (params.irrigationType === 'goutte') {
      factor *= 1.15;
      factors.push({ name: 'Irrigation goutte-à-goutte', impact: 15, color: '#4CAF50' });
    } else if (params.irrigationType === 'aspersion') {
      factor *= 1.08;
      factors.push({ name: 'Irrigation par aspersion', impact: 8, color: '#4CAF50' });
    } else {
      factor *= 0.9;
      factors.push({ name: 'Pluie seule', impact: -10, color: '#F44336' });
    }
    
    const finalYield = Math.round(baseYield * factor);
    const potential = Math.round((finalYield / baseYield) * 100);
    
    const recommendations = [
      params.ph < 6 ? 'Augmentez le pH de votre sol avec un apport de chaux' : 
      params.ph > 7.5 ? 'Diminuez le pH avec du soufre ou de la matière organique' : 
      'Votre pH est idéal, continuez ainsi',
      
      params.organicMatter < 2 ? 'Apportez du compost ou des engrais verts pour augmenter la matière organique' : 
      'Bon niveau de matière organique',
      
      params.irrigationType !== 'goutte' ? 'Envisagez le goutte-à-goutte pour économiser 30% d\'eau et augmenter le rendement' : 
      'Excellent choix d\'irrigation'
    ];
    
    return {
      crop: params.crop,
      yieldValue: finalYield,
      yieldUnit: 'kg/ha',
      potential,
      factors,
      recommendations
    };
  }

  // ========== MÉTHODES PRIVÉES ==========

  /**
   * Simule une valeur avec variation aléatoire
   */
  private simulateValue(base: number, variance: number, min: number, max: number): number {
    let value = base + (Math.random() * variance * 2 - variance);
    return Math.max(min, Math.min(max, Math.round(value * 10) / 10));
  }

  /**
   * Calcule le niveau de confiance de l'IA
   */
  private calculateConfidence(metrics: DemoMetrics, parcelle?: DemoParcelle): number {
    let conf = 85;
    if (metrics.soilMoisture > 30 && metrics.soilMoisture < 70) conf += 3;
    if (metrics.temperature > 20 && metrics.temperature < 28) conf += 3;
    if (metrics.airHumidity > 50 && metrics.airHumidity < 75) conf += 3;
    return Math.min(98, conf);
  }

  // ========== UTILITAIRES ==========

  /**
   * Convertit le type en libellé français
   */
  getTypeLabel(type: string): string {
    const map: any = { 
      'irrigation': 'Irrigation', 
      'maladie': 'Maladie', 
      'rendement': 'Rendement', 
      'alerte': 'Alerte' 
    };
    return map[type] || type;
  }

  /**
   * Convertit le statut en libellé français
   */
  getStatusLabel(status: string): string {
    const map: any = { 
      'success': 'Réussi', 
      'warning': 'Alerte', 
      'error': 'Erreur', 
      'info': 'Info' 
    };
    return map[status] || status;
  }

  /**
   * Retourne la couleur associée au statut
   */
  getStatusColor(status: string): string {
    const map: any = { 
      'success': '#4CAF50', 
      'warning': '#FF9800', 
      'error': '#F44336', 
      'info': '#2196F3' 
    };
    return map[status] || '#9E9E9E';
  }

  /**
   * Retourne la couleur associée à la sévérité
   */
  getSeverityColor(severity: string): string {
    const map: any = { 
      'faible': '#4CAF50', 
      'moyenne': '#FF9800', 
      'haute': '#F44336' 
    };
    return map[severity] || '#9E9E9E';
  }
}