import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  status: 'actif' | 'inactif';
  parcelles?: number;
  date?: Date;
}

export interface Disease {
  id: string;
  name: string;
  plants: string[];
  severity: 'Faible' | 'Moyenne' | 'Haute';
  symptoms: string[];
  treatment: string;
  prevention?: string;
  images?: string[];
  description?: string;
}

export interface TopicDetail {
  id: string;
  title: string;
  author: string;
  author_email: string;
  date: Date;
  replies: number;
  views: number;
  reports?: number;
  excerpt?: string;
  fullContent?: string;
  category?: string;
  status?: string;
  images?: string[];
  solved?: boolean;
}

export interface Topic {
  id: string;
  title: string;
  author: string;
  date: Date;
  replies: number;
  reports?: number;
  excerpt?: string;
  category?: string;
  status?: string;
}

export interface Reply {
  id: string;
  topicId: string;
  author: string;
  author_email: string;
  content: string;
  date: Date;
  helpfulCount: number;
  images?: string[];
}

export interface AdminStats {
  totalUsers: number;
  newUsers: number;
  totalParcelles: number;
  totalArea: number;
  totalTopics: number;
  pendingTopics: number;
  totalDiseases: number;
  diseaseDetections: number;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = `${environment.apiUrl}/admin`;

  constructor(private http: HttpClient) {}

  private getAuthOptions() {
    return {};
  }

  // ==================== USERS ====================
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.apiUrl}/users`);
  }

  createUser(user: Partial<User>): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/users`, user);
  }

  updateUser(id: string, user: Partial<User>): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/users/${id}`, user);
  }

  deleteUser(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/users/${id}`);
  }

  // ==================== DISEASES (avec upload d'images) ====================
  getDiseases(): Observable<Disease[]> {
    return this.http.get<Disease[]>(`${this.apiUrl}/diseases`);
  }

  createDiseaseWithImages(formData: FormData): Observable<Disease> {
    return this.http.post<Disease>(`${this.apiUrl}/diseases`, formData);
  }

  updateDiseaseWithImages(id: string, formData: FormData): Observable<Disease> {
    return this.http.put<Disease>(`${this.apiUrl}/diseases/${id}`, formData);
  }

  createDisease(disease: Partial<Disease>): Observable<Disease> {
    return this.http.post<Disease>(`${this.apiUrl}/diseases`, disease);
  }

  updateDisease(id: string, disease: Partial<Disease>): Observable<Disease> {
    return this.http.put<Disease>(`${this.apiUrl}/diseases/${id}`, disease);
  }

  deleteDisease(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/diseases/${id}`);
  }

  uploadImage(file: File): Observable<{ status: string; filename: string; url: string }> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<{ status: string; filename: string; url: string }>(
      `${this.apiUrl}/upload-image`,
      formData
    );
  }

  uploadMultipleImages(files: File[]): Observable<{ status: string; files: { filename: string; url: string }[] }> {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });
    return this.http.post<{ status: string; files: { filename: string; url: string }[] }>(
      `${this.apiUrl}/upload-images`,
      formData
    );
  }

  // ==================== TOPICS (Forum) ====================
  getReportedTopics(): Observable<Topic[]> {
    return this.http.get<Topic[]>(`${this.apiUrl}/topics/reported`);
  }

  getRecentTopics(): Observable<Topic[]> {
    return this.http.get<Topic[]>(`${this.apiUrl}/topics/recent`);
  }

  approveTopic(topicId: string): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/topics/${topicId}/approve`, {});
  }

  deleteTopic(topicId: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/topics/${topicId}`);
  }

  // ==================== SUJET DETAIL (pour consultation) ====================
  getTopicById(topicId: string): Observable<TopicDetail> {
    return this.http.get<TopicDetail>(`${environment.apiUrl}/forum/topics/${topicId}`);
  }

  getTopicReplies(topicId: string): Observable<Reply[]> {
    return this.http.get<Reply[]>(`${environment.apiUrl}/forum/replies/${topicId}`);
  }

  // ==================== MODÉRATION FORUM ====================
  getPendingTopics(): Observable<Topic[]> {
    return this.http.get<Topic[]>(`${environment.apiUrl}/forum/admin/topics?status=pending`);
  }

  approveForumTopic(topicId: string): Observable<any> {
    return this.http.put(`${environment.apiUrl}/forum/admin/topics/${topicId}/approve`, {});
  }

  rejectForumTopic(topicId: string): Observable<any> {
    return this.http.put(`${environment.apiUrl}/forum/admin/topics/${topicId}/reject`, {});
  }

  deleteForumTopic(topicId: string): Observable<any> {
    return this.http.delete(`${environment.apiUrl}/forum/admin/topics/${topicId}`);
  }

  // ==================== STATISTIQUES ====================
  getStats(): Observable<AdminStats> {
    return this.http.get<AdminStats>(`${this.apiUrl}/stats`);
  }
}