import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ChatbotResponse {
  reponse: string;
  categorie: string;
  trouve: boolean;
}

export interface QuestionRequest {
  question: string;
  page: string;
  contexte?: any;
}

@Injectable({
  providedIn: 'root'
})
export class ChatbotService {
  private baseUrl = 'http://localhost:8002';

  constructor(private http: HttpClient) {}

  askQuestion(question: string, page: string = 'general'): Observable<ChatbotResponse> {
    const token = sessionStorage.getItem('jwt_token');
    console.log('Token récupéré :', token);   // ← clé corrigée
    let headers = new HttpHeaders();
    if (token) {
        headers = headers.set('Authorization', `Bearer ${token}`);
    }

    // Déterminer l'endpoint selon la page
    let endpoint = '/chat';
    
    switch(page) {
      case 'irrigation':
        endpoint = '/chat/irrigation';
        break;
      case 'diseases':
        endpoint = '/chat/maladies';
        break;
      case 'rendement':
        endpoint = '/chat/rendement';
        break;
      default:
        endpoint = '/chat/general';
        break;
    }
    
    // Corps de la requête POST
    const body: QuestionRequest = {
      question: question,
      page: page
    };
    
    return this.http.post<ChatbotResponse>(`${this.baseUrl}${endpoint}`, body, { headers });
  }

  getQuickQuestions(page: string): string[] {
    const questions: { [key: string]: string[] } = {
      'diseases': [
        'Comment reconnaître le mildiou ?',
        'Traitement naturel pour les maladies fongiques ?',
        'Feuilles jaunes, que faire ?'
      ],
      'irrigation': [
        'Comment irriguer les tomates en été ?',
        'Quelle est la meilleure période pour arroser ?',
        'Comment économiser l\'eau ?'
      ],
      'dashboard': [
        'Comment va ma ferme ?',
        'Prochaines tâches à faire ?',
        'Alertes importantes ?'
      ],
      'history': [
        'Que s\'est-il passé cette semaine ?',
        'Combien d\'irrigation en juillet ?',
        'Problèmes récurrents ?'
      ],
      'forum': [
        'Comment poser une bonne question ?',
        'Qui sont les experts vérifiés ?',
        'Comment aider la communauté ?'
      ]
    };
    return questions[page] || ['Comment puis-je vous aider ?'];
  }
}