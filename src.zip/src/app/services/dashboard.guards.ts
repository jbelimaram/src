import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthStateService } from '../services/auth-state.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardGuard implements CanActivate {
  
  constructor(
    private router: Router,
    private authState: AuthStateService
  ) {}

  canActivate(): boolean {
    console.log('🛡️ DashboardGuard - vérification');
    
    const userEmail = this.authState.getCurrentUserEmail();
    const userRole = this.authState.getCurrentUserRole();
    
    if (!userEmail) {
      console.log('  ❌ Pas d\'email utilisateur, redirection vers login');
      this.router.navigate(['/login']);
      return false;
    }
    
    // Vérifier que l'utilisateur est bien un agriculteur
    if (userRole !== 'agriculteur') {
      console.log('  ❌ Accès refusé - réservé aux agriculteurs');
      
      // Si c'est un admin, rediriger vers la page admin
      if (userRole === 'admin') {
        this.router.navigate(['/admin']);
      } else {
        this.router.navigate(['/accueil']);
      }
      return false;
    }
    
    const hasFarm = this.authState.hasFarmConfiguration();
    console.log('  hasFarm:', hasFarm);
    
    if (!hasFarm) {
      console.log('  ⚠️ Ferme non configurée, redirection vers farm-setup');
      this.router.navigate(['/farm-setup']);
      return false;
    }
    
    console.log('  ✅ Accès autorisé au dashboard');
    return true;
  }
}