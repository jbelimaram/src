// src/app/services/diseases.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Disease {
  id: string;
  name: string;
  plants: string[];
  description: string;
  symptoms: string[];
  treatment: string;
  prevention: string;
  images: string[];
  severity: string;
}

@Injectable({
  providedIn: 'root'
})
export class DiseasesService {
  private apiUrl = `${environment.apiUrl}/public/diseases`;

  constructor(private http: HttpClient) {}

  /**
   * Récupère toutes les maladies (public, sans authentification)
   * et corrige les URLs des images
   */
  getAllDiseases(): Observable<Disease[]> {
    return this.http.get<Disease[]>(`${this.apiUrl}/`).pipe(
      map(diseases => {
        // Corriger les URLs des images pour chaque maladie
        return diseases.map(disease => ({
          ...disease,
          images: disease.images?.map(img => this.fixImageUrl(img)) || []
        }));
      })
    );
  }

  /**
   * Récupère une maladie par son ID
   */
  getDiseaseById(id: string): Observable<Disease> {
    return this.http.get<Disease>(`${this.apiUrl}/${id}`).pipe(
      map(disease => ({
        ...disease,
        images: disease.images?.map(img => this.fixImageUrl(img)) || []
      }))
    );
  }

  /**
   * Corrige l'URL de l'image
   * - Si l'URL commence par /uploads/, on ajoute l'URL de base
   * - Si l'URL est un chemin relatif, on la corrige
   */
  private fixImageUrl(url: string): string {
    if (!url) return 'assets/default-disease.jpg';
    
    // Si l'URL est déjà complète
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    
    // Si l'URL commence par /uploads/
    if (url.startsWith('/uploads/')) {
      return `${environment.apiUrl}${url}`;
    }
    
    // Si l'URL commence par uploads/ (sans slash)
    if (url.startsWith('uploads/')) {
      return `${environment.apiUrl}/${url}`;
    }
    
    // Si l'URL est juste un nom de fichier
    return `${environment.apiUrl}/uploads/diseases/${url}`;
  }
}