import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private authService: AuthService
  ) {}

  canActivate(): boolean {
    console.log('🔍 AuthGuard - vérification');
    const isAuth = this.authService.isAuthenticated();
    const hasTemp = !!sessionStorage.getItem('temp_registration');
    
    console.log('  isAuth:', isAuth, 'hasTemp:', hasTemp);
    
    if (isAuth || hasTemp) {
      console.log('  ✅ Autorisation accordée');
      return true;
    }
    
    console.log('  ❌ Redirection vers login');
    this.router.navigate(['/login']);
    return false;
  }
}