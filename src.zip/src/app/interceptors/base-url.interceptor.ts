// src/app/interceptors/base-url.interceptor.ts
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable()
export class BaseUrlInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Ne pas modifier les requêtes qui commencent déjà par http
    if (req.url.startsWith('http')) {
      return next.handle(req);
    }
    
    // Modifier les URLs qui contiennent 'uploads' (images)
    if (req.url.includes('uploads') || req.url.startsWith('uploads/')) {
      // S'assurer que l'URL commence par un slash
      let url = req.url;
      if (!url.startsWith('/')) {
        url = '/' + url;
      }
      
      const fullUrl = `${environment.baseUrl}${url}`;
      console.log('🖼️ Interceptor - Original URL:', req.url);
      console.log('🖼️ Interceptor - Full URL:', fullUrl);
      
      const apiReq = req.clone({
        url: fullUrl
      });
      return next.handle(apiReq);
    }
    
    return next.handle(req);
  }
}