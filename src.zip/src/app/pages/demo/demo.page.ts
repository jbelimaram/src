import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';
import { TranslationService } from '../../services/translation.service';
import { WeatherService, WeatherData } from '../../services/weather.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { Subscription, interval } from 'rxjs';

// Interfaces locales pour la démo
interface DemoParcelle {
  id: string;
  name: string;
  cropName: string;
  area: number;
  soilType: string;
  soilTypeLabel: string;
}

interface DemoMetrics {
  soilMoisture: number;
  temperature: number;
  airHumidity: number;
}

interface DemoIrrigationDecision {
  active: boolean;
  confidence: number;
  explanation: string;
}

interface DemoDisease {
  id: number;
  name: string;
  plant: string;
  description: string;
  symptoms: string[];
  treatment: string;
  severity: 'faible' | 'moyenne' | 'haute';
}

interface DemoDiseaseAnalysis {
  disease: string;
  plant: string;
  probability: number;
  treatment: string;
  severity: string;
  symptoms: string[];
}

// Interface alignée sur rendement.page.ts
interface DemoYieldParams {
  crop: string;               // cotton, rice, barley, soybean, wheat, maize
  region: string;             // nord, sud, est, ouest
  soilType: string;           // argileux, limoneux, sableux, limon
  area: number;               // superficie en hectares
  rainfall: number;           // précipitations (mm)
  temperature: number;        // température (°C)
  fertilizerUsed: string;     // 'oui' ou 'non'
  irrigation: boolean;        // true/false
  weatherCondition: string;   // ensoleille, pluvieux, nuageux
  daysToHarvest: number;      // 60-150
}

interface DemoYieldPrediction {
  yieldValue: number;         // kg/ha
  totalYield: number;         // kg
  potential: number;          // pourcentage
  confidence: number;         // fiabilité
  yieldUnit: string;          // 'kg/ha'
  explanation: string;
}

@Component({
  selector: 'app-demo',
  templateUrl: './demo.page.html',
  styleUrls: ['./demo.page.scss'],
  standalone: false
})
export class DemoPage implements OnInit, OnDestroy {
  // Langue et affichage
  currentLang: string = 'fr';
  currentYear: number = new Date().getFullYear();
  activeRoute: string = 'demo';

  // Drawers et notifications
  navDrawerOpen: boolean = false;
  notificationsPanelOpen: boolean = false;
  notifications: Notification[] = [];
  unreadNotifications: number = 0;

  // Météo
  weatherData: WeatherData | null = null;
  weatherLoading: boolean = false;
  weatherError: boolean = false;

  // Onglet actif
  selectedTab: string = 'irrigation';

  // Données irrigation
  parcelles: DemoParcelle[] = [];
  selectedParcelleId: string = '';
  currentMetrics: DemoMetrics = { soilMoisture: 68, temperature: 24, airHumidity: 62 };
  irrigationDecision: DemoIrrigationDecision = { active: false, confidence: 92, explanation: '' };
  private metricsInterval: Subscription | null = null;

  // Données santé
  diseases: DemoDisease[] = [];
  analyzing = false;
  analysisResult: DemoDiseaseAnalysis | null = null;

  // Données rendement - initialisation corrigée
  yieldParams: DemoYieldParams = {
    crop: 'wheat',
    region: 'nord',
    soilType: 'limoneux',
    area: 1.0,
    rainfall: 600,
    temperature: 22,
    fertilizerUsed: 'oui',
    irrigation: true,
    weatherCondition: 'ensoleille',
    daysToHarvest: 120
  };
  yieldResult: DemoYieldPrediction | null = null;
  isPredicting = false;

  constructor(
    private alertController: AlertController,
    private router: Router,
    private translationService: TranslationService,
    private cdr: ChangeDetectorRef,
    private weatherService: WeatherService,
    private notificationService: NotificationService
  ) {
    this.currentLang = this.translationService.getCurrentLang();
  }

  ngOnInit() {
    this.loadWeather();
    this.loadNotifications();
    this.initDemoData();
    this.startMetricsSimulation();
    document.addEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  ngOnDestroy() {
    if (this.metricsInterval) this.metricsInterval.unsubscribe();
    document.removeEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  // ========== GESTION MÉTÉO ==========
  private loadWeather() {
    this.weatherLoading = true;
    this.weatherService.getWeatherFallback().subscribe({
      next: (data) => {
        this.weatherData = data;
        this.weatherLoading = false;
        this.weatherError = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.weatherError = true;
        this.weatherLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  retryWeather() { this.loadWeather(); }

  // ========== NOTIFICATIONS ==========
  private async loadNotifications() {
    try {
      this.notifications = await this.notificationService.getNotifications().toPromise() || [];
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
    } catch (error) {
      console.error('Erreur chargement notifications:', error);
    }
  }

  // ========== DRAWERS ==========
  toggleNavDrawer() { this.navDrawerOpen = !this.navDrawerOpen; }
  closeNavDrawer() { this.navDrawerOpen = false; }
  toggleNotificationsPanel() { this.notificationsPanelOpen = !this.notificationsPanelOpen; }
  closeNotificationsPanel() { this.notificationsPanelOpen = false; }
  handleEscapeKey(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      if (this.navDrawerOpen) this.closeNavDrawer();
      if (this.notificationsPanelOpen) this.closeNotificationsPanel();
    }
  }

  // ========== LANGUE ==========
  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.cdr.detectChanges();
  }

  // ========== DONNÉES SIMULÉES ==========
  private initDemoData() {
    // Parcelles
    this.parcelles = [
      { id: '1', name: 'Parcelle Nord', cropName: 'Blé', area: 2.5, soilType: 'limoneux', soilTypeLabel: 'Limoneux' },
      { id: '2', name: 'Parcelle Sud', cropName: 'Maïs', area: 3.0, soilType: 'argileux', soilTypeLabel: 'Argileux' },
      { id: '3', name: 'Parcelle Est', cropName: 'Tomate', area: 1.8, soilType: 'sableux', soilTypeLabel: 'Sableux' }
    ];
    this.selectedParcelleId = this.parcelles[0].id;
    this.updateIrrigationDecision();

    // Maladies
    this.diseases = [
      { id: 1, name: 'Mildiou', plant: 'Tomate', description: 'Maladie fongique due à l\'humidité', symptoms: ['Taches brunes', 'Flétrissement'], treatment: 'Bouillie bordelaise', severity: 'haute' },
      { id: 2, name: 'Rouille', plant: 'Blé', description: 'Maladie fongique à pustules orangées', symptoms: ['Pustules', 'Jaunissement'], treatment: 'Fongicide à base de soufre', severity: 'moyenne' },
      { id: 3, name: 'Oïdium', plant: 'Vigne', description: 'Maladie cryptogamique blanchâtre', symptoms: ['Poudre blanche', 'Déformation'], treatment: 'Soufre micronisé', severity: 'moyenne' }
    ];
  }

  private startMetricsSimulation() {
    this.metricsInterval = interval(5000).subscribe(() => {
      this.currentMetrics = {
        soilMoisture: Math.min(100, Math.max(20, this.currentMetrics.soilMoisture + (Math.random() - 0.5) * 5)),
        temperature: Math.min(45, Math.max(10, this.currentMetrics.temperature + (Math.random() - 0.5) * 2)),
        airHumidity: Math.min(90, Math.max(30, this.currentMetrics.airHumidity + (Math.random() - 0.5) * 4))
      };
      this.updateIrrigationDecision();
      this.cdr.detectChanges();
    });
  }

  onParcelleChange() {
    this.updateIrrigationDecision();
  }

  private updateIrrigationDecision() {
    const parcelle = this.parcelles.find(p => p.id === this.selectedParcelleId);
    if (!parcelle) return;
    const moisture = this.currentMetrics.soilMoisture;
    const seuil = parcelle.soilType === 'sableux' ? 40 : (parcelle.soilType === 'argileux' ? 65 : 55);
    const active = moisture < seuil;
    const confidence = Math.round(70 + Math.random() * 25);
    let explanation = '';
    if (active) {
      explanation = `Humidité du sol trop faible (${Math.round(moisture)}%). Arrosage nécessaire.`;
    } else {
      explanation = `Humidité du sol suffisante (${Math.round(moisture)}%). Pas besoin d'irrigation.`;
    }
    this.irrigationDecision = { active, confidence, explanation };
  }

  // ========== SANTÉ ==========
  simulateDiseaseAnalysis() {
    this.analyzing = true;
    this.analysisResult = null;
    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * this.diseases.length);
      const disease = this.diseases[randomIndex];
      this.analysisResult = {
        disease: disease.name,
        plant: disease.plant,
        probability: Math.floor(70 + Math.random() * 25),
        treatment: disease.treatment,
        severity: disease.severity,
        symptoms: disease.symptoms
      };
      this.analyzing = false;
      this.cdr.detectChanges();
    }, 2000);
  }

  resetAnalysis() {
    this.analysisResult = null;
  }

  async showDiseaseDetails(disease: DemoDisease) {
    const alert = await this.alertController.create({
      header: disease.name,
      subHeader: disease.plant,
      message: `
        <div style="text-align: left">
          <p><strong>Description:</strong> ${disease.description}</p>
          <p><strong>Symptômes:</strong> ${disease.symptoms.join(', ')}</p>
          <p><strong>Traitement:</strong> ${disease.treatment}</p>
        </div>
      `,
      buttons: ['OK']
    });
    await alert.present();
  }

  getSeverityColor(severity: string): string {
    switch (severity) {
      case 'haute': return '#ef4444';
      case 'moyenne': return '#f59e0b';
      default: return '#10b981';
    }
  }

  // ========== RENDEMENT (simulation alignée sur rendement.page.ts) ==========
  simulateYieldPrediction() {
    this.isPredicting = true;
    setTimeout(() => {
      let baseYield = 0;
      switch (this.yieldParams.crop) {
        case 'cotton': baseYield = 5000; break;
        case 'rice': baseYield = 8000; break;
        case 'barley': baseYield = 6000; break;
        case 'soybean': baseYield = 4000; break;
        case 'wheat': baseYield = 7000; break;
        case 'maize': baseYield = 10000; break;
        default: baseYield = 5000;
      }

      let impact = 1.0;
      const positiveFactors: string[] = [];
      const negativeFactors: string[] = [];

      // Région
      if (this.yieldParams.region === 'nord') { impact *= 1.10; positiveFactors.push('Région Nord favorable (+10%)'); }
      else if (this.yieldParams.region === 'sud') { impact *= 0.90; negativeFactors.push('Région Sud moins favorable (-10%)'); }
      else if (this.yieldParams.region === 'est') { impact *= 1.05; positiveFactors.push('Région Est favorable (+5%)'); }
      else if (this.yieldParams.region === 'ouest') { impact *= 0.95; negativeFactors.push('Région Ouest moins favorable (-5%)'); }

      // Sol
      if (this.yieldParams.soilType === 'limoneux') { impact *= 1.15; positiveFactors.push('Sol limoneux idéal (+15%)'); }
      else if (this.yieldParams.soilType === 'argileux') { impact *= 1.08; positiveFactors.push('Sol argileux (bonne rétention) (+8%)'); }
      else if (this.yieldParams.soilType === 'sableux') { impact *= 0.85; negativeFactors.push('Sol sableux (faible rétention) (-15%)'); }
      else if (this.yieldParams.soilType === 'limon') { impact *= 1.10; positiveFactors.push('Sol limoneux équilibré (+10%)'); }

      // Précipitations
      if (this.yieldParams.rainfall >= 500 && this.yieldParams.rainfall <= 800) { impact *= 1.10; positiveFactors.push('Précipitations optimales (+10%)'); }
      else if (this.yieldParams.rainfall < 300) { impact *= 0.80; negativeFactors.push('Précipitations insuffisantes (-20%)'); }
      else if (this.yieldParams.rainfall > 1200) { impact *= 0.85; negativeFactors.push('Excès de précipitations (-15%)'); }

      // Température
      if (this.yieldParams.temperature >= 20 && this.yieldParams.temperature <= 25) { impact *= 1.10; positiveFactors.push('Température idéale (+10%)'); }
      else if (this.yieldParams.temperature < 15 || this.yieldParams.temperature > 30) { impact *= 0.85; negativeFactors.push('Température stressante (-15%)'); }

      // Engrais
      if (this.yieldParams.fertilizerUsed === 'oui') { impact *= 1.20; positiveFactors.push('Utilisation d\'engrais (+20%)'); }
      else { impact *= 0.80; negativeFactors.push('Pas d\'engrais (-20%)'); }

      // Irrigation
      if (this.yieldParams.irrigation) { impact *= 1.20; positiveFactors.push('Irrigation utilisée (+20%)'); }
      else { impact *= 0.75; negativeFactors.push('Absence d\'irrigation (-25%)'); }

      // Condition météo
      if (this.yieldParams.weatherCondition === 'ensoleille') { impact *= 1.10; positiveFactors.push('Conditions ensoleillées (+10%)'); }
      else if (this.yieldParams.weatherCondition === 'pluvieux') { impact *= 0.90; negativeFactors.push('Conditions pluvieuses (-10%)'); }
      else if (this.yieldParams.weatherCondition === 'nuageux') { impact *= 1.05; positiveFactors.push('Conditions nuageuses modérées (+5%)'); }

      // Jours avant récolte
      if (this.yieldParams.daysToHarvest > 150) { impact *= 1.10; positiveFactors.push('Cycle long favorable (+10%)'); }
      else if (this.yieldParams.daysToHarvest < 90) { impact *= 0.90; negativeFactors.push('Cycle trop court (-10%)'); }

      let finalYield = Math.round(baseYield * impact);
      finalYield = Math.round(finalYield * (0.95 + Math.random() * 0.1));
      const totalYield = Math.round(finalYield * this.yieldParams.area);
      const potential = Math.min(100, Math.round((impact - 0.5) * 100));
      const confidence = Math.floor(70 + Math.random() * 20);

      let explanation = '';
      if (positiveFactors.length > 0 && negativeFactors.length === 0) {
        explanation = `✅ Conditions excellentes : ${positiveFactors.join(', ')}.`;
      } else if (positiveFactors.length > negativeFactors.length) {
        explanation = `👍 Bon potentiel. Points forts : ${positiveFactors.slice(0,2).join(', ')}. Améliorer : ${negativeFactors.slice(0,2).join(', ')}.`;
      } else if (positiveFactors.length === negativeFactors.length) {
        explanation = `⚖️ Potentiel moyen. Optimisez les facteurs négatifs : ${negativeFactors.join(', ')}.`;
      } else {
        explanation = `⚠️ Potentiel limité. Principaux freins : ${negativeFactors.slice(0,3).join(', ')}. Revoir les pratiques.`;
      }

      this.yieldResult = {
        yieldValue: finalYield,
        totalYield: totalYield,
        potential: potential,
        confidence: confidence,
        yieldUnit: 'kg/ha',
        explanation: explanation
      };
      this.isPredicting = false;
      this.cdr.detectChanges();
    }, 1500);
  }

  // ========== NAVIGATION ==========
  goToAccueil() {
    this.router.navigate(['/accueil']);
  }

  logout() {
    this.router.navigate(['/login']);
  }
}