import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FarmSetupPage } from './farm-setup.page';

const routes: Routes = [
  {
    path: '',
    component: FarmSetupPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FarmSetupPageRoutingModule {}
