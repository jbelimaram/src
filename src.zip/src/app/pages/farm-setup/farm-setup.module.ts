import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { FarmSetupPageRoutingModule } from './farm-setup-routing.module';
import { FarmSetupPage } from './farm-setup.page';

// ===== IMPORT DU SHARED MODULE =====
import { SharedModule } from '../../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FarmSetupPageRoutingModule,
    SharedModule  // ← AJOUTÉ ICI !
  ],
  declarations: [FarmSetupPage]
})
export class FarmSetupPageModule {}