import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController, LoadingController } from '@ionic/angular';
import { Geolocation } from '@capacitor/geolocation';
import { TranslationService } from '../../services/translation.service';
import { TranslateService } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
declare var L: any;

interface LoginResponse {
  email: string;
  username: string;
  hasFarm: boolean;
  token?: string;
}

interface RegisterResponse {
  message: string;
  email: string;
}

interface FarmResponse {
  message: string;
  farmId?: string;
}

@Component({
  selector: 'app-farm-setup',
  templateUrl: './farm-setup.page.html',
  styleUrls: ['./farm-setup.page.scss'],
  standalone: false
})
export class FarmSetupPage implements OnInit, AfterViewInit {
  @ViewChild('mapContainer') mapContainer!: ElementRef;

  currentLang: string = 'fr';

  currentStep = 1;
  totalSteps = 5;
  progressWidth = '20%';
  acceptedTerms = false;
  isSatelliteView = false;

  parcels: any[] = [
    { id: 'P1', name: '', area: null, soilType: '', irrigationType: '', crop: '' }
  ];
  maxParcels = 4;

  farmData = {
    name: '',
    size: null as number | null,
    region: ''
  };

  farmCoordinates: { lat: number; lng: number } | null = null;
  farmAddress: string = '';

  tunisianRegions = [
    { value: 'tunis', name: 'Tunis' },
    { value: 'ariana', name: 'Ariana' },
    { value: 'ben_arous', name: 'Ben Arous' },
    { value: 'manouba', name: 'Manouba' },
    { value: 'nabeul', name: 'Nabeul' },
    { value: 'zaghouan', name: 'Zaghouan' },
    { value: 'bizerte', name: 'Bizerte' },
    { value: 'beja', name: 'Béja' },
    { value: 'jendouba', name: 'Jendouba' },
    { value: 'kef', name: 'Le Kef' },
    { value: 'siliana', name: 'Siliana' },
    { value: 'sousse', name: 'Sousse' },
    { value: 'monastir', name: 'Monastir' },
    { value: 'mahdia', name: 'Mahdia' },
    { value: 'sfax', name: 'Sfax' },
    { value: 'kairouan', name: 'Kairouan' },
    { value: 'kasserine', name: 'Kasserine' },
    { value: 'sidi_bouzid', name: 'Sidi Bouzid' },
    { value: 'gabes', name: 'Gabès' },
    { value: 'medenine', name: 'Médenine' },
    { value: 'tataouine', name: 'Tataouine' },
    { value: 'gafsa', name: 'Gafsa' },
    { value: 'tozeur', name: 'Tozeur' },
    { value: 'kebili', name: 'Kébili' }
  ];

  // SEULE CETTE PARTIE A ÉTÉ MODIFIÉE
  cropList = [
    { value: 'tomate', label: 'Tomate', image: 'tomate.jpg' },
    { value: 'pommeDeTerre', label: 'Pomme de terre', image: 'potato.jpg' },
    { value: 'olive', label: 'Olivier', image: 'olive.jpg' },
    { value: 'epinard', label: 'Épinard', image: 'Épinard.jpg' },
    { value: 'salade', label: 'Salade', image: 'Salade.jpg' }
  ];

  private map: any;
  private isMapInitialized = false;
  private currentMarker: any;
  private baseLayer: any;
  private satelliteLayer: any;
  mapCenter = { lat: 36.8, lng: 10.17 };
  locationAddress: string = '';

  private apiUrl = environment.apiUrl;
  userEmail: string | null = null;

  constructor(
    private router: Router,
    private toastController: ToastController,
    private loadingController: LoadingController,
    private translationService: TranslationService,
    private translate: TranslateService,
    private cdr: ChangeDetectorRef,
    private http: HttpClient
  ) {
    this.currentLang = this.translationService.getCurrentLang();
  }

  ngOnInit() {
    const tempData = sessionStorage.getItem('temp_registration');
    if (tempData) {
      const parsed = JSON.parse(tempData);
      this.userEmail = parsed.email;
    } else {
      this.userEmail = sessionStorage.getItem('current_user_email');
    }
    
    if (!this.userEmail && !tempData) {
      this.showNotification('FARM_SETUP.ERRORS.LOGIN_REQUIRED', 'error');
      this.router.navigate(['/accueil']);
      return;
    }
    
    if (this.userEmail) {
      const farmConfig = sessionStorage.getItem('farm_' + this.userEmail) || 
                        sessionStorage.getItem('farmConfiguration');
      if (farmConfig) {
        this.router.navigate(['/dashboard']);
        return;
      }
    }
    
    this.updateProgressBar();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.initMap();
    }, 800);
  }

  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.cdr.detectChanges();
  }

  getCurrentLang(): string {
    return this.currentLang;
  }

  nextStep() {
    if (this.validateStep(this.currentStep)) {
      this.currentStep++;
      this.updateForm();
    }
  }

  prevStep() {
    this.currentStep--;
    this.updateForm();
  }

  updateForm() {
    this.updateProgressBar();
    if (this.currentStep === this.totalSteps) {
      this.prepareSummary();
    }
  }

  updateProgressBar() {
    const progress = ((this.currentStep - 1) / (this.totalSteps - 1)) * 100;
    this.progressWidth = `${progress}%`;
  }

  validateStep(step: number): boolean {
    let isValid = true;
    let errorKey = '';
    
    switch(step) {
      case 1:
        if (!this.farmData.name?.trim()) {
          errorKey = 'FARM_SETUP.ERRORS.NAME_REQUIRED';
          isValid = false;
        } else if (this.farmData.size === null || this.farmData.size === undefined) {
          errorKey = 'FARM_SETUP.ERRORS.SIZE_REQUIRED';
          isValid = false;
        } else if (this.farmData.size <= 0) {
          errorKey = 'FARM_SETUP.ERRORS.SIZE_POSITIVE';
          isValid = false;
        }
        break;
      case 2:
        if (!this.farmData.region) {
          errorKey = 'FARM_SETUP.ERRORS.REGION_REQUIRED';
          isValid = false;
        }
        break;
      case 3:
        errorKey = this.validateAllParcels();
        if (errorKey) isValid = false;
        break;
      case 4:
        errorKey = this.validateCropsForAllParcels();
        if (errorKey) isValid = false;
        break;
      case 5:
        if (!this.acceptedTerms) {
          errorKey = 'FARM_SETUP.ERRORS.TERMS_REQUIRED';
          isValid = false;
        }
        break;
    }
    
    if (!isValid && errorKey) {
      this.showNotification(errorKey, 'error');
    }
    
    return isValid;
  }

  validateAllParcels(): string {
    if (!this.parcels[0].name?.trim()) return 'FARM_SETUP.ERRORS.PARCEL1_NAME_REQUIRED';
    if (this.parcels[0].area === null || this.parcels[0].area === undefined) return 'FARM_SETUP.ERRORS.PARCEL1_AREA_REQUIRED';
    if (this.parcels[0].area <= 0) return 'FARM_SETUP.ERRORS.PARCEL1_AREA_POSITIVE';
    if (!this.parcels[0].soilType) return 'FARM_SETUP.ERRORS.PARCEL1_SOIL_REQUIRED';
    if (!this.parcels[0].irrigationType) return 'FARM_SETUP.ERRORS.PARCEL1_IRRIGATION_REQUIRED';
    
    for (let i = 1; i < this.parcels.length; i++) {
      const parcel = this.parcels[i];
      const hasName = parcel.name?.trim();
      const hasArea = parcel.area !== null && parcel.area !== undefined;
      const hasSoil = parcel.soilType !== '';
      const hasIrrigation = parcel.irrigationType !== '';
      
      if (hasName || hasArea || hasSoil || hasIrrigation) {
        if (!hasName) return `FARM_SETUP.ERRORS.PARCEL${i+1}_NAME_MISSING`;
        if (!hasArea) return `FARM_SETUP.ERRORS.PARCEL${i+1}_AREA_MISSING`;
        if (parcel.area <= 0) return `FARM_SETUP.ERRORS.PARCEL${i+1}_AREA_POSITIVE`;
        if (!hasSoil) return `FARM_SETUP.ERRORS.PARCEL${i+1}_SOIL_REQUIRED`;
        if (!hasIrrigation) return `FARM_SETUP.ERRORS.PARCEL${i+1}_IRRIGATION_REQUIRED`;
      }
    }
    return '';
  }

  validateCropsForAllParcels(): string {
    for (let i = 0; i < this.parcels.length; i++) {
      if (this.isParcelConfigured(i) && !this.parcels[i].crop) {
        return 'FARM_SETUP.ERRORS.CROP_REQUIRED';
      }
    }
    return '';
  }

  isParcelConfigured(index: number): boolean {
    const parcel = this.parcels[index];
    return !!parcel.name?.trim() && 
           parcel.area !== null && 
           parcel.area !== undefined && 
           parcel.area > 0 &&
           !!parcel.soilType &&
           !!parcel.irrigationType;
  }

  addParcel() {
    if (this.parcels.length < this.maxParcels) {
      const newId = `P${this.parcels.length + 1}`;
      this.parcels.push({ id: newId, name: '', area: null, soilType: '', irrigationType: '', crop: '' });
    }
  }

  removeParcel(index: number) {
    if (index > 0) {
      this.parcels.splice(index, 1);
    }
  }

  selectCropForParcel(parcelIndex: number, crop: string) {
    this.parcels[parcelIndex].crop = crop;
  }

  initMap() {
    if (typeof L === 'undefined') {
      this.loadLeaflet();
      return;
    }

    if (!L.Icon.Default.prototype._getIconUrl) {
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'assets/leaflet/marker-icon-2x.png',
        iconUrl: 'assets/leaflet/marker-icon.png',
        shadowUrl: 'assets/leaflet/marker-shadow.png',
      });
    }

    setTimeout(() => {
      const mapElement = document.getElementById('farm-map');
      if (!mapElement) return;

      mapElement.style.height = '400px';
      mapElement.style.width = '100%';
      mapElement.style.minHeight = '400px';

      try {
        this.map = L.map('farm-map', {
          center: [this.mapCenter.lat, this.mapCenter.lng],
          zoom: 7,
          zoomControl: true
        });

        this.baseLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '© OpenStreetMap',
          maxZoom: 19
        }).addTo(this.map);

        this.satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
          attribution: 'Esri, DigitalGlobe, GeoEye',
          maxZoom: 19
        });

        this.isMapInitialized = true;

        this.currentMarker = L.marker([this.mapCenter.lat, this.mapCenter.lng])
          .addTo(this.map)
          .bindPopup(this.translate.instant('FARM_SETUP.LOCATION.DEFAULT_POSITION'))
          .openPopup();

        this.map.on('click', (e: any) => this.onMapClick(e));

        setTimeout(() => {
          this.map.invalidateSize();
        }, 300);

      } catch (error) {
        console.error('Erreur carte:', error);
      }
    }, 100);
  }

  loadLeaflet() {
    if (!document.querySelector('link[href*="leaflet"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(link);
    }
    
    if (!document.querySelector('script[src*="leaflet"]')) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
      script.onload = () => setTimeout(() => this.initMap(), 500);
      document.head.appendChild(script);
    }
  }

  async onMapClick(event: any) {
    const latlng = event.latlng;
    this.mapCenter = { lat: latlng.lat, lng: latlng.lng };
    this.farmCoordinates = { lat: latlng.lat, lng: latlng.lng };
    
    if (this.currentMarker) {
      this.map.removeLayer(this.currentMarker);
    }
    this.currentMarker = L.marker([latlng.lat, latlng.lng]).addTo(this.map)
      .bindPopup('Position sélectionnée').openPopup();
    
    await this.reverseGeocode(latlng.lat, latlng.lng);
    this.farmAddress = this.locationAddress;
  }

  async reverseGeocode(lat: number, lng: number) {
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
      const data = await response.json();
      this.locationAddress = data.display_name;
      this.farmAddress = this.locationAddress;
    } catch (error) {
      console.error('Erreur de géocodage inverse', error);
      this.locationAddress = '';
      this.farmAddress = '';
    }
  }

  async locateMe() {
    try {
      const loadingMessage = this.translate.instant('FARM_SETUP.LOCATION.LOCATING');
      const loading = await this.loadingController.create({
        message: loadingMessage,
        duration: 3000
      });
      await loading.present();
      
      const coordinates = await Geolocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 10000
      });
      
      await loading.dismiss();
      
      const lat = coordinates.coords.latitude;
      const lng = coordinates.coords.longitude;
      this.mapCenter = { lat, lng };
      this.farmCoordinates = { lat, lng };
      
      if (this.map) {
        this.map.setView([lat, lng], 15);
        
        if (this.currentMarker) {
          this.map.removeLayer(this.currentMarker);
        }
        
        this.currentMarker = L.marker([lat, lng])
          .addTo(this.map)
          .bindPopup('<b>' + this.translate.instant('FARM_SETUP.LOCATION.YOUR_POSITION') + '</b>')
          .openPopup();
        
        await this.reverseGeocode(lat, lng);
        this.farmAddress = this.locationAddress;
        this.showNotification('FARM_SETUP.SUCCESS.LOCATION_FOUND', 'success');
      }
      
    } catch (error: any) {
      this.showNotification('FARM_SETUP.ERRORS.LOCATION_FAILED', 'error');
      
      if (this.map) {
        this.map.setView([36.8, 10.17], 10);
      }
    }
  }

  async searchCity(query: string) {
    if (!query.trim()) return;

    const loading = await this.loadingController.create({
      message: this.translate.instant('FARM_SETUP.LOCATION.SEARCHING'),
    });
    await loading.present();

    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1&countrycodes=tn`
      );
      const data = await response.json();

      if (data && data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lon = parseFloat(data[0].lon);
        this.mapCenter = { lat, lng: lon };
        this.farmCoordinates = { lat, lng: lon };

        if (this.map) {
          this.map.setView([lat, lon], 13);
          if (this.currentMarker) {
            this.map.removeLayer(this.currentMarker);
          }
          this.currentMarker = L.marker([lat, lon]).addTo(this.map)
            .bindPopup(data[0].display_name)
            .openPopup();
          this.locationAddress = data[0].display_name;
          this.farmAddress = data[0].display_name;
        }
        this.showNotification('FARM_SETUP.LOCATION.FOUND', 'success');
      } else {
        this.showNotification('FARM_SETUP.LOCATION.NOT_FOUND', 'warning');
      }
    } catch (error) {
      console.error('Erreur de recherche', error);
      this.showNotification('FARM_SETUP.LOCATION.SEARCH_ERROR', 'error');
    } finally {
      loading.dismiss();
    }
  }

  toggleSatellite() {
    if (!this.map || !this.isMapInitialized) return;
    
    this.isSatelliteView = !this.isSatelliteView;
    
    if (this.isSatelliteView) {
      this.map.removeLayer(this.baseLayer);
      this.satelliteLayer.addTo(this.map);
    } else {
      this.map.removeLayer(this.satelliteLayer);
      this.baseLayer.addTo(this.map);
    }
    
    setTimeout(() => {
      this.map.invalidateSize();
    }, 100);
  }

  async submitForm() {
    if (!this.validateStep(this.currentStep)) return;

    const loading = await this.loadingController.create({
      message: this.translate.instant('FARM_SETUP.CONFIGURING'),
      duration: 3000
    });
    await loading.present();

    try {
      if (!this.userEmail) {
        throw new Error('Utilisateur non connecté');
      }

      const activeParcels = this.parcels.filter((p, i) => this.isParcelConfigured(i));

      const farmPayload = {
        user_email: this.userEmail,
        name: this.farmData.name,
        size: this.farmData.size,
        region: this.farmData.region,
        parcels: activeParcels.map(p => ({
          id: p.id,
          name: p.name,
          area: p.area,
          soilType: p.soilType,
          irrigationType: p.irrigationType,
          crop: p.crop
        })),
        latitude: this.farmCoordinates?.lat ?? null,
        longitude: this.farmCoordinates?.lng ?? null,
        address: this.farmAddress || null
      };

      const tempDataJson = sessionStorage.getItem('temp_registration');
      
      if (tempDataJson) {
        const userData = JSON.parse(tempDataJson);
        console.log('📤 Envoi au /register...');
        
        await firstValueFrom(
          this.http.post<RegisterResponse>(`${this.apiUrl}/register`, userData)
        );
        console.log('✅ Utilisateur créé');
        
        console.log('🔄 Auto-login après inscription...');
        const loginResponse = await firstValueFrom(
          this.http.post<LoginResponse>(`${this.apiUrl}/login`, {
            email: userData.email,
            password: userData.password
          })
        );
        
        if (loginResponse && loginResponse.email && loginResponse.username) {
          const user = {
            email: loginResponse.email,
            username: loginResponse.username,
            hasFarm: true,
            role: 'agriculteur'
          };
          
          sessionStorage.setItem('current_user', JSON.stringify(user));
          sessionStorage.setItem('current_user_email', user.email);
          sessionStorage.setItem('farm_configured', 'true');
          sessionStorage.setItem('user_role', 'agriculteur');
          
          console.log('✅ Auto-login réussi:', user);
        } else {
          console.error('❌ Réponse de login invalide:', loginResponse);
        }
        
        sessionStorage.removeItem('temp_registration');
        
      } else {
        console.log('ℹ️ Utilisateur déjà existant, envoi direct de la ferme');
        
        const userStr = sessionStorage.getItem('current_user');
        if (userStr) {
          const user = JSON.parse(userStr);
          user.hasFarm = true;
          if (!user.role) {
            user.role = 'agriculteur';
          }
          sessionStorage.setItem('current_user', JSON.stringify(user));
          sessionStorage.setItem('farm_configured', 'true');
          sessionStorage.setItem('user_role', user.role || 'agriculteur');
        }
      }

      console.log('📤 Envoi au /farm/save avec localisation...');
      const farmResponse = await firstValueFrom(
        this.http.post<FarmResponse>(`${this.apiUrl}/farm/save`, farmPayload)
      );
      console.log('✅ Ferme configurée', farmResponse);

      if (this.farmCoordinates) {
        const coordinatesKey = `farm_coordinates_${this.userEmail}`;
        sessionStorage.setItem(coordinatesKey, JSON.stringify({
          lat: this.farmCoordinates.lat,
          lng: this.farmCoordinates.lng,
          address: this.farmAddress
        }));
      }

      await loading.dismiss();
      this.showNotification('FARM_SETUP.SUCCESS.CONFIGURED', 'success');
      
      setTimeout(() => {
        this.router.navigate(['/dashboard']);
      }, 500);

    } catch (error: any) {
      console.error('❌ Erreur lors de la configuration:', error);
      await loading.dismiss();
      
      let errorMessage = 'FARM_SETUP.ERRORS.CONFIGURATION_FAILED';
      if (error.error?.detail) {
        errorMessage = error.error.detail;
      }
      this.showNotification(errorMessage, 'error');
      
      if (error.message?.includes('non connecté')) {
        this.router.navigate(['/accueil']);
      }
    }
  }

  prepareSummary() {}

  getRegionName(regionValue: string): string {
    const region = this.tunisianRegions.find(r => r.value === regionValue);
    return region ? region.name : regionValue;
  }

  getSoilTypeText(soilType: string): string {
    const soilKeys: {[key: string]: string} = {
      'clay': 'FARM_SETUP.SOIL_TYPES.CLAY',
      'sandy': 'FARM_SETUP.SOIL_TYPES.SANDY',
      'loamy': 'FARM_SETUP.SOIL_TYPES.LOAMY',
      'peaty': 'FARM_SETUP.SOIL_TYPES.PEATY'
    };
    return soilKeys[soilType] || soilType;
  }

  getIrrigationTypeText(irrigationType: string): string {
    const irrigationKeys: {[key: string]: string} = {
      'drip': 'FARM_SETUP.IRRIGATION_TYPES.DRIP',
      'sprinkler': 'FARM_SETUP.IRRIGATION_TYPES.SPRINKLER',
      'surface': 'FARM_SETUP.IRRIGATION_TYPES.SURFACE'
    };
    return irrigationKeys[irrigationType] || irrigationType;
  }

  getCropName(crop: string | undefined): string {
    if (!crop) return '';
    const found = this.cropList.find(c => c.value === crop);
    return found ? found.label : crop;
  }

  async showNotification(key: string, type: 'success' | 'error' | 'warning' | 'info' = 'success') {
    const message = this.translate.instant(key);
    const toast = await this.toastController.create({
      message: message,
      duration: 3000,
      position: 'top',
      color: type === 'success' ? 'success' : 
             type === 'error' ? 'danger' : 
             type === 'warning' ? 'warning' : 'primary',
      buttons: [{ text: this.translate.instant('COMMON.OK'), role: 'cancel' }]
    });
    await toast.present();
  }
}