import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FarmSetupPage } from './farm-setup.page';

describe('FarmSetupPage', () => {
  let component: FarmSetupPage;
  let fixture: ComponentFixture<FarmSetupPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(FarmSetupPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
