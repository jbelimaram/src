import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { IrrigationPage } from './irrigation.page';
import { IrrigationPageRoutingModule } from './irrigation-routing.module';
import { SharedModule } from '../../shared/shared.module';

// ===== IMPORT DU CHATBOT MODAL =====
import { ChatbotModalModule } from '../../components/chatbot-modal/chatbot-modal.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    IrrigationPageRoutingModule,
    SharedModule,        
    ChatbotModalModule
  ],
  declarations: [IrrigationPage]  
})
export class IrrigationPageModule {}