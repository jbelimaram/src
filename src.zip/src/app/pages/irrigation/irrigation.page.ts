import { Component, OnInit, ViewChild, ElementRef, OnDestroy, ChangeDetectorRef, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, registerables } from 'chart.js';
import { WeatherService, WeatherData, ForecastDay } from '../../services/weather.service';
import { TranslationService } from '../../services/translation.service';
import { TranslateService } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../services/auth.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { OverlayService } from '../../services/overlay.service';
import { firstValueFrom } from 'rxjs';
import { Subscription } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface FarmData {
  user_email: string;
  name: string;
  size: number;
  region: string;
  parcels: any[];
  latitude?: number;
  longitude?: number;
}

export interface Parcelle {
  id: string;
  name: string;
  cropName: string;
  area: number;
  soilType?: string;
}

@Component({
  selector: 'app-irrigation',
  templateUrl: './irrigation.page.html',
  styleUrls: ['./irrigation.page.scss'],
  standalone: false
})
export class IrrigationPage implements OnInit, OnDestroy {
  @ViewChild('soilMoistureChart') soilMoistureChartRef!: ElementRef;
  @ViewChild('temperatureChart') temperatureChartRef!: ElementRef;
  @ViewChild('airHumidityChart') airHumidityChartRef!: ElementRef;
  @ViewChild('lightIntensityChart') lightIntensityChartRef!: ElementRef;

  private soilMoistureChart!: Chart;
  private temperatureChart!: Chart;
  private airHumidityChart!: Chart;
  private lightIntensityChart!: Chart;

  // Langue et affichage
  currentLang: string = 'fr';
  currentYear: number = new Date().getFullYear();
  activePage: string = 'irrigation';
  displayName: string = '';
  userEmail: string = '';
  isAdmin: boolean = false;

  // Drawers
  navDrawerOpen: boolean = false;
  notificationsPanelOpen: boolean = false;
  notifications: Notification[] = [];
  unreadNotifications: number = 0;

  // Parcelles
  parcelles: Parcelle[] = [];
  selectedParcelle: Parcelle | null = null;

  // Capteurs
  soilMoistureValue: number | null = null;
  temperatureValue: number | null = null;
  airHumidityValue: number | null = null;
  lightIntensityValue: number | null = null;

  // Historique
  soilMoistureHistory: number[] = [];
  temperatureHistory: number[] = [];
  airHumidityHistory: number[] = [];
  lightIntensityHistory: number[] = [];

  // IA
  irrigationDecision: boolean | null = null;
  aiConfidence: number | null = null;
  lastDecisionTime: Date | null = null;

  // Alertes
  alerts: any[] = [];

  // Météo
  weatherData: WeatherData | null = null;
  forecastData: ForecastDay[] | null = null;
  weatherLoading: boolean = false;
  weatherError: boolean = false;

  // Chatbot
  chatbotOpen: boolean = false;

  // Données ferme
  farmData: FarmData | null = null;
  farmCoordinates: { lat: number; lng: number } | null = null;
  farmRegion: string = '';

  // Gestion des requêtes
  private currentRequestId: number = 0;
  sensorsLoading: boolean = false;

  private dayKeys: string[] = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  private pollingInterval: any;
  private currentUserEmail: string = '';
  private overlaySubscription: Subscription;

  constructor(
    private router: Router,
    private weatherService: WeatherService,
    private translationService: TranslationService,
    private translate: TranslateService,
    private cdr: ChangeDetectorRef,
    private http: HttpClient,
    private authService: AuthService,
    private notificationService: NotificationService,
    private overlayService: OverlayService,
    private ngZone: NgZone
  ) {
    Chart.register(...registerables);
    this.currentLang = this.translationService.getCurrentLang();
    this.overlaySubscription = this.overlayService.overlayState$.subscribe(state => {
      this.ngZone.run(() => {
        if (this.navDrawerOpen !== state.navDrawerOpen) {
          this.navDrawerOpen = state.navDrawerOpen;
        }
        if (this.notificationsPanelOpen !== state.notificationsPanelOpen) {
          this.notificationsPanelOpen = state.notificationsPanelOpen;
        }
        if (this.chatbotOpen !== state.chatbotOpen) {
          this.chatbotOpen = state.chatbotOpen;
        }
        this.cdr.detectChanges();
      });
    });
  }

  ngOnInit() {
    this.loadUserData();
    this.currentUserEmail = this.authService.getCurrentUserEmail() || '';
    if (!this.currentUserEmail) {
      console.error('Aucun email utilisateur trouvé. Redirection vers login.');
      this.router.navigate(['/login']);
      return;
    }
    this.loadFarmData();
    this.loadNotifications();
    document.addEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  ngOnDestroy() {
    if (this.pollingInterval) clearInterval(this.pollingInterval);
    if (this.soilMoistureChart) this.soilMoistureChart.destroy();
    if (this.temperatureChart) this.temperatureChart.destroy();
    if (this.airHumidityChart) this.airHumidityChart.destroy();
    if (this.lightIntensityChart) this.lightIntensityChart.destroy();
    document.removeEventListener('keydown', this.handleEscapeKey.bind(this));
    if (this.overlaySubscription) this.overlaySubscription.unsubscribe();
  }

  handleEscapeKey(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      this.overlayService.closeAllOverlays();
    }
  }

  // ========== GESTION UTILISATEUR ==========
  private loadUserData() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.displayName = user.username || user.name || 'Agriculteur';
      this.userEmail = user.email;
      this.isAdmin = user.role === 'admin';
    }
  }

  // ========== NOTIFICATIONS ==========
  private async loadNotifications() {
    try {
      this.notifications = await firstValueFrom(this.notificationService.getNotifications());
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur chargement notifications:', error);
    }
  }

  async markNotificationAsRead(notificationId: string) {
    try {
      await firstValueFrom(this.notificationService.markAsRead(notificationId));
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) notif.read = true;
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  async markAllNotificationsAsRead() {
    try {
      await firstValueFrom(this.notificationService.markAllAsRead());
      this.notifications.forEach(n => n.read = true);
      this.unreadNotifications = 0;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  // ========== DRAWERS ==========
  toggleNavDrawer() { this.overlayService.setNavDrawerOpen(!this.navDrawerOpen); }
  closeNavDrawer() { this.overlayService.setNavDrawerOpen(false); }
  toggleNotificationsPanel() { this.overlayService.setNotificationsPanelOpen(!this.notificationsPanelOpen); }
  closeNotificationsPanel() { this.overlayService.setNotificationsPanelOpen(false); }
  toggleChatbot(): void { this.overlayService.setChatbotOpen(!this.chatbotOpen); }
  onChatbotClose(): void { this.overlayService.setChatbotOpen(false); }

  // ========== FERME ET PARCELLES ==========
  private async loadFarmData(): Promise<void> {
    try {
      const response = await firstValueFrom(
        this.http.get<FarmData>(`${environment.apiUrl}/farm/${this.currentUserEmail}`)
      );
      if (response) {
        this.farmData = response;
        this.farmRegion = response.region;
        if (response.latitude && response.longitude) {
          this.farmCoordinates = { lat: response.latitude, lng: response.longitude };
        } else {
          const storedCoords = sessionStorage.getItem(`farm_coordinates_${this.currentUserEmail}`);
          if (storedCoords) {
            const coords = JSON.parse(storedCoords);
            this.farmCoordinates = { lat: coords.lat, lng: coords.lng };
          }
        }
        if (response.parcels && response.parcels.length > 0) {
          this.parcelles = response.parcels.map(p => ({
            id: p._id || p.id,
            name: p.name,
            cropName: p.crop,
            area: p.area,
            soilType: p.soilType
          }));
          this.selectedParcelle = this.parcelles[0];
        }
        this.loadWeatherFromFarm();
        this.initSensorData();
      } else {
        this.loadWeatherFallback();
        this.initSensorData();
      }
    } catch (error) {
      console.error('Erreur chargement ferme:', error);
      this.loadWeatherFallback();
      this.initSensorData();
    }
  }

  // ========== MÉTÉO ==========
  private loadWeatherFromFarm(): void {
    if (this.farmCoordinates) {
      this.loadWeatherByCoords(this.farmCoordinates.lat, this.farmCoordinates.lng);
      this.loadForecastByCoords(this.farmCoordinates.lat, this.farmCoordinates.lng);
    } else if (this.farmRegion) {
      this.loadWeatherByCity(this.farmRegion);
      this.loadForecastByCity(this.farmRegion);
    } else {
      this.loadWeatherFallback();
      this.loadForecastFallback();
    }
  }

  private loadWeatherByCoords(lat: number, lon: number) {
    this.weatherLoading = true;
    this.weatherError = false;
    this.weatherService.getWeatherByCoords(lat, lon).subscribe({
      next: (data) => { this.weatherData = data; this.weatherLoading = false; },
      error: () => { this.weatherError = true; this.weatherLoading = false; this.loadWeatherFallback(); }
    });
  }

  private loadWeatherByCity(city: string) {
    this.weatherLoading = true;
    this.weatherError = false;
    this.weatherService.getWeatherByCity(city).subscribe({
      next: (data) => { this.weatherData = data; this.weatherLoading = false; },
      error: () => { this.weatherError = true; this.weatherLoading = false; this.loadWeatherFallback(); }
    });
  }

  private loadWeatherFallback() {
    this.weatherLoading = true;
    this.weatherService.getWeatherFallback().subscribe({
      next: (data) => { this.weatherData = data; this.weatherLoading = false; this.weatherError = false; },
      error: () => { this.weatherError = true; this.weatherLoading = false; }
    });
  }

  private loadForecastByCoords(lat: number, lon: number) {
    this.weatherService.getForecastByCoords(lat, lon).subscribe({
      next: (data) => { this.forecastData = data; },
      error: () => this.loadForecastFallback()
    });
  }

  private loadForecastByCity(city: string) {
    this.weatherService.getForecastByCity(city).subscribe({
      next: (data) => { this.forecastData = data; },
      error: () => this.loadForecastFallback()
    });
  }

  private loadForecastFallback() {
    this.weatherService.getForecastFallback().subscribe({
      next: (data) => { this.forecastData = data; }
    });
  }

  retryWeather() {
    if (this.farmCoordinates) {
      this.loadWeatherByCoords(this.farmCoordinates.lat, this.farmCoordinates.lng);
      this.loadForecastByCoords(this.farmCoordinates.lat, this.farmCoordinates.lng);
    } else if (this.farmRegion) {
      this.loadWeatherByCity(this.farmRegion);
      this.loadForecastByCity(this.farmRegion);
    } else {
      this.loadWeatherFallback();
      this.loadForecastFallback();
    }
  }

  // ========== CAPTEURS ==========
  private async initSensorData() {
    await this.loadHistoricalData();
    await this.loadLatestSensorData();
    this.startPolling();
  }

  private async loadHistoricalData(): Promise<void> {
    if (!this.currentUserEmail) return;
    const parcelleId = this.selectedParcelle?.id;
    let url = `${environment.apiUrl}/api/sensors/history/${this.currentUserEmail}`;
    if (parcelleId) url += `?parcelle_id=${parcelleId}`;
    try {
      const response = await firstValueFrom(this.http.get<any[]>(url));
      this.ngZone.run(() => {
        if (response && response.length) {
          const sorted = response.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
          const last24 = sorted.slice(-24);
          this.soilMoistureHistory = last24.map(d => d.soil_moisture);
          this.temperatureHistory = last24.map(d => d.temperature);
          this.airHumidityHistory = last24.map(d => d.air_humidity);
          this.lightIntensityHistory = last24.map(d => d.light_intensity || 0);
        } else {
          this.soilMoistureHistory = [];
          this.temperatureHistory = [];
          this.airHumidityHistory = [];
          this.lightIntensityHistory = [];
        }
        this.createOrUpdateCharts();
      });
    } catch (error) {
      console.error('Erreur chargement historique', error);
      this.ngZone.run(() => this.createOrUpdateCharts());
    }
  }

  private loadLatestSensorData() {
    if (!this.currentUserEmail) return;
    
    // Incrémenter l'ID de requête pour ignorer les réponses obsolètes
    const requestId = ++this.currentRequestId;
    this.sensorsLoading = true;
    
    const parcelleId = this.selectedParcelle?.id;
    let url = `${environment.apiUrl}/api/sensors/latest/${this.currentUserEmail}`;
    if (parcelleId) url += `?parcelle_id=${parcelleId}`;
    
    this.http.get<any>(url).subscribe({
      next: (data) => {
        // Ignorer si une requête plus récente a été lancée
        if (requestId !== this.currentRequestId) return;
        
        this.ngZone.run(() => {
          if (data.message === "No data") {
            this.sensorsLoading = false;
            return;
          }
          this.temperatureValue = data.temperature;
          this.airHumidityValue = data.air_humidity;
          this.soilMoistureValue = data.soil_moisture;
          this.lightIntensityValue = data.light_intensity || 0;
          this.irrigationDecision = data.irrigation_decision;
          
          if (data.ai_confidence !== undefined && data.ai_confidence !== null) {
            this.aiConfidence = data.ai_confidence;
          } else {
            const diffFromOptimal = Math.abs(data.soil_moisture - 50);
            this.aiConfidence = Math.max(0, Math.min(100, 100 - diffFromOptimal));
          }
          
          this.lastDecisionTime = data.timestamp ? new Date(data.timestamp) : null;
          this.sensorsLoading = false;
          this.cdr.detectChanges();
          
          const last = this.soilMoistureHistory[this.soilMoistureHistory.length - 1];
          if (this.soilMoistureHistory.length === 0 || last !== data.soil_moisture) {
            this.soilMoistureHistory.push(data.soil_moisture);
            this.temperatureHistory.push(data.temperature);
            this.airHumidityHistory.push(data.air_humidity);
            this.lightIntensityHistory.push(data.light_intensity || 0);
            if (this.soilMoistureHistory.length > 24) {
              this.soilMoistureHistory.shift();
              this.temperatureHistory.shift();
              this.airHumidityHistory.shift();
              this.lightIntensityHistory.shift();
            }
            this.updateCharts();
          }
        });
      },
      error: (err) => {
        if (requestId !== this.currentRequestId) return;
        console.error("Erreur chargement capteur", err);
        this.ngZone.run(() => {
          this.sensorsLoading = false;
          this.cdr.detectChanges();
        });
      }
    });
  }

  private startPolling() {
    if (this.pollingInterval) clearInterval(this.pollingInterval);
    this.pollingInterval = setInterval(() => {
      this.loadLatestSensorData();
    }, 30000);
  }

  // ========== GRAPHIQUES ==========
  private createOrUpdateCharts() {
    this.ngZone.runOutsideAngular(() => {
      const labels = this.generateTimeLabels();
      if (this.soilMoistureChartRef?.nativeElement) {
        if (this.soilMoistureChart) this.soilMoistureChart.destroy();
        this.soilMoistureChart = new Chart(this.soilMoistureChartRef.nativeElement, {
          type: 'line',
          data: { labels, datasets: [{ data: this.soilMoistureHistory, borderColor: '#4caf50', backgroundColor: 'transparent', borderWidth: 2, pointRadius: 0, tension: 0.4, fill: false }] },
          options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { enabled: true } }, scales: { x: { display: true, title: { display: true, text: this.translate.instant('IRRIGATION.CHART.HOUR') } }, y: { display: true, title: { display: true, text: '%' } } } }
        });
      }
      if (this.temperatureChartRef?.nativeElement) {
        if (this.temperatureChart) this.temperatureChart.destroy();
        this.temperatureChart = new Chart(this.temperatureChartRef.nativeElement, {
          type: 'line',
          data: { labels, datasets: [{ data: this.temperatureHistory, borderColor: '#ff9800', backgroundColor: 'transparent', borderWidth: 2, pointRadius: 0, tension: 0.4, fill: false }] },
          options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { enabled: true } }, scales: { x: { display: true, title: { display: true, text: this.translate.instant('IRRIGATION.CHART.HOUR') } }, y: { display: true, title: { display: true, text: '°C' } } } }
        });
      }
      if (this.airHumidityChartRef?.nativeElement) {
        if (this.airHumidityChart) this.airHumidityChart.destroy();
        this.airHumidityChart = new Chart(this.airHumidityChartRef.nativeElement, {
          type: 'line',
          data: { labels, datasets: [{ data: this.airHumidityHistory, borderColor: '#2196f3', backgroundColor: 'transparent', borderWidth: 2, pointRadius: 0, tension: 0.4, fill: false }] },
          options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { enabled: true } }, scales: { x: { display: true, title: { display: true, text: this.translate.instant('IRRIGATION.CHART.HOUR') } }, y: { display: true, title: { display: true, text: '%' } } } }
        });
      }
      if (this.lightIntensityChartRef?.nativeElement) {
        if (this.lightIntensityChart) this.lightIntensityChart.destroy();
        this.lightIntensityChart = new Chart(this.lightIntensityChartRef.nativeElement, {
          type: 'line',
          data: { labels, datasets: [{ data: this.lightIntensityHistory, borderColor: '#f59e0b', backgroundColor: 'transparent', borderWidth: 2, pointRadius: 0, tension: 0.4, fill: false }] },
          options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { enabled: true } }, scales: { x: { display: true, title: { display: true, text: this.translate.instant('IRRIGATION.CHART.HOUR') } }, y: { display: true, title: { display: true, text: 'lx' } } } }
        });
      }
    });
  }

  private updateCharts() {
    this.ngZone.runOutsideAngular(() => {
      const labels = this.generateTimeLabels();
      if (this.soilMoistureChart) {
        this.soilMoistureChart.data.labels = labels;
        this.soilMoistureChart.data.datasets[0].data = this.soilMoistureHistory;
        this.soilMoistureChart.update();
      }
      if (this.temperatureChart) {
        this.temperatureChart.data.labels = labels;
        this.temperatureChart.data.datasets[0].data = this.temperatureHistory;
        this.temperatureChart.update();
      }
      if (this.airHumidityChart) {
        this.airHumidityChart.data.labels = labels;
        this.airHumidityChart.data.datasets[0].data = this.airHumidityHistory;
        this.airHumidityChart.update();
      }
      if (this.lightIntensityChart) {
        this.lightIntensityChart.data.labels = labels;
        this.lightIntensityChart.data.datasets[0].data = this.lightIntensityHistory;
        this.lightIntensityChart.update();
      }
    });
  }

  // ========== ÉVÉNEMENTS ==========
  async onParcelleChange() {
    console.log('Parcelle changée:', this.selectedParcelle);
    
    // Réinitialiser les valeurs affichées
    this.sensorsLoading = true;
    this.soilMoistureValue = null;
    this.temperatureValue = null;
    this.airHumidityValue = null;
    this.lightIntensityValue = null;
    this.irrigationDecision = null;
    this.aiConfidence = null;
    this.lastDecisionTime = null;
    
    // Réinitialiser les historiques
    this.soilMoistureHistory = [];
    this.temperatureHistory = [];
    this.airHumidityHistory = [];
    this.lightIntensityHistory = [];
    
    // Mettre à jour les graphiques (les vider)
    this.updateCharts();
    
    // Forcer la détection des changements
    this.cdr.detectChanges();
    
    try {
      // Recharger les données pour la nouvelle parcelle
      await this.loadHistoricalData();
      await this.loadLatestSensorData();
    } catch (error) {
      console.error('Erreur lors du changement de parcelle:', error);
    } finally {
      this.sensorsLoading = false;
      this.cdr.detectChanges();
    }
  }

  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.cdr.detectChanges();
  }

  getTranslatedDay(date: any): string {
    try {
      let d: Date;
      if (date instanceof Date) d = date;
      else if (typeof date === 'string') d = new Date(date);
      else if (typeof date === 'number') d = new Date(date);
      else if (date && typeof date === 'object' && date.dt) d = new Date(date.dt * 1000);
      else return '';
      if (isNaN(d.getTime())) return '';
      const dayIndex = d.getDay();
      return this.translate.instant('WEATHER.DAYS.' + this.dayKeys[dayIndex]);
    } catch { return ''; }
  }

  isActive(page: string): boolean { return this.activePage === page; }

  getIrrigationStateText(): string {
    if (this.irrigationDecision === null) return this.translate.instant('IRRIGATION.AI.WAITING');
    return this.irrigationDecision ? this.translate.instant('IRRIGATION.AI.ACTIVE') : this.translate.instant('IRRIGATION.AI.INACTIVE');
  }

  getDecisionExplanation(): string {
    const crop = this.selectedParcelle?.cropName || 'vos cultures';
    const moisture = this.soilMoistureValue;
    const confidence = this.aiConfidence;
    
    if (this.irrigationDecision === null) {
      return this.translate.instant('IRRIGATION.AI.NO_DATA');
    }
    
    if (this.irrigationDecision) {
      return `L'IA recommande l'arrosage avec ${confidence}% de confiance. L'humidité du sol est de ${moisture}%, ce qui est insuffisant pour ${crop}.`;
    } else {
      return `L'IA ne recommande pas l'arrosage (confiance ${confidence}%). L'humidité du sol (${moisture}%) est suffisante pour ${crop}.`;
    }
  }

  getAlertIcon(priority: string): string {
    switch(priority) {
      case 'danger': return 'fa-exclamation-circle';
      case 'warning': return 'fa-exclamation-triangle';
      case 'info': return 'fa-info-circle';
      default: return 'fa-info-circle';
    }
  }

  logout(event?: Event) {
    if (event) event.preventDefault();
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  private generateTimeLabels(): string[] {
    const labels = [];
    const now = new Date();
    for (let i = 23; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 3600000);
      labels.push(d.getHours() + 'h');
    }
    return labels;
  }
}