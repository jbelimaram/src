// forgot-password.page.ts
import { Component, OnInit, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastController, LoadingController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { TranslationService } from '../../services/translation.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.page.html',
  styleUrls: ['./forgot-password.page.scss'],
  standalone: false
})
export class ForgotPasswordPage implements OnInit {
  emailForm: FormGroup;
  submitted = false;
  isLoading = false;
  currentLang: string = 'fr';

  private apiUrl = environment.apiUrl;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private toastController: ToastController,
    private loadingController: LoadingController,
    private translate: TranslateService,
    private translationService: TranslationService,
    private cdr: ChangeDetectorRef,
    private renderer: Renderer2
  ) {
    this.emailForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
    
    this.currentLang = this.translationService.getCurrentLang();
    this.translate.use(this.currentLang);
    
    // Set document direction based on language
    this.setDocumentDirection(this.currentLang);
  }

  ngOnInit() {}

  /**
   * Set document direction based on language
   */
  private setDocumentDirection(lang: string): void {
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    this.renderer.setAttribute(document.documentElement, 'dir', dir);
    this.renderer.setAttribute(document.documentElement, 'lang', lang);
  }

  /**
   * Change language
   */
  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.setDocumentDirection(lang);
    this.cdr.detectChanges();
  }

  /**
   * Handle image loading error (show default image)
   */
  handleImageError(event: any): void {
    const img = event.target as HTMLImageElement;
    img.src = 'assets/photos/logo-default.png';
  }

  async onSubmit() {
    if (this.emailForm.invalid) return;

    this.isLoading = true;
    const loading = await this.loadingController.create({
      message: this.translate.instant('FORGOT_PASSWORD.SENDING')
    });
    await loading.present();

    try {
      await firstValueFrom(
        this.http.post(`${this.apiUrl}/forgot-password`, {
          email: this.emailForm.value.email
        })
      );

      await loading.dismiss();
      this.submitted = true;

    } catch (error: any) {
      console.error('Erreur forgot password:', error);
      await loading.dismiss();
      const message = error.error?.detail || this.translate.instant('FORGOT_PASSWORD.ERROR');
      const toast = await this.toastController.create({
        message,
        duration: 3000,
        color: 'danger',
        position: 'top'
      });
      await toast.present();
    } finally {
      this.isLoading = false;
    }
  }
}