// login.page.ts
import { Component, OnInit, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController, ToastController, LoadingController } from '@ionic/angular';
import { AuthService } from '../../services/auth.service';
import { TranslationService } from '../../services/translation.service';
import { TranslateService } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false
})
export class LoginPage implements OnInit {
  loginForm: FormGroup;
  showPassword = false;
  isLoading = false;
  currentLang: string = 'fr';
  formError: string = '';
  
  // CAPTCHA
  captchaCode: string = '';
  captchaInput: string = '';

  private apiUrl = environment.apiUrl

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private alertController: AlertController,
    private toastController: ToastController,
    private loadingController: LoadingController,
    private translationService: TranslationService,
    private translate: TranslateService,
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private renderer: Renderer2
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      captcha: ['', [Validators.required]]
    });
    
    this.currentLang = this.translationService.getCurrentLang();
    this.translate.use(this.currentLang);
    
    // Set document direction based on language
    this.setDocumentDirection(this.currentLang);
  }

  ngOnInit() {
    this.refreshCaptcha();
  }

  /**
   * Set document direction based on language
   */
  private setDocumentDirection(lang: string): void {
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    this.renderer.setAttribute(document.documentElement, 'dir', dir);
    this.renderer.setAttribute(document.documentElement, 'lang', lang);
  }

  /**
   * Change language
   */
  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.setDocumentDirection(lang);
    this.cdr.detectChanges();
  }

  /**
   * Handle image loading error (show default image)
   */
  handleImageError(event: any): void {
    const img = event.target as HTMLImageElement;
    img.src = 'assets/photos/logo-default.png';
  }

  get emailInvalid(): boolean {
    const control = this.loginForm.get('email');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }

  get emailError(): string {
    const control = this.loginForm.get('email');
    if (control?.errors?.['required']) {
      return this.translate.instant('LOGIN.ERRORS.EMAIL_REQUIRED');
    }
    if (control?.errors?.['email']) {
      return this.translate.instant('LOGIN.ERRORS.EMAIL_INVALID');
    }
    return '';
  }

  get passwordInvalid(): boolean {
    const control = this.loginForm.get('password');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }

  get passwordError(): string {
    const control = this.loginForm.get('password');
    if (control?.errors?.['required']) {
      return this.translate.instant('LOGIN.ERRORS.PASSWORD_REQUIRED');
    }
    return '';
  }

  get captchaInvalid(): boolean {
    const control = this.loginForm.get('captcha');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }

  get captchaError(): string {
    const control = this.loginForm.get('captcha');
    if (control?.errors?.['required']) {
      return this.translate.instant('LOGIN.ERRORS.CAPTCHA_REQUIRED');
    }
    return '';
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  refreshCaptcha(): void {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    this.captchaCode = result;
    this.loginForm.get('captcha')?.reset();
  }

  async onSubmit(): Promise<void> {
    if (this.loginForm.invalid) {
      this.markFormGroupTouched(this.loginForm);
      return;
    }

    const captchaValue = this.loginForm.get('captcha')?.value;
    if (captchaValue !== this.captchaCode) {
      this.formError = this.translate.instant('LOGIN.ERRORS.CAPTCHA_INVALID');
      this.refreshCaptcha();
      return;
    }

    this.isLoading = true;
    this.formError = '';

    try {
      const formValues = this.loginForm.value;
      const user = await this.authService.login(formValues.email, formValues.password);
      
      if (user) {
        const toast = await this.toastController.create({
          message: this.translate.instant('LOGIN.SUCCESS'),
          duration: 2000,
          color: 'success',
          position: 'top'
        });
        await toast.present();
        
        if (!user.hasFarm) {
          this.router.navigate(['/farm-setup']);
        } else {
          this.router.navigate(['/dashboard']);
        }
      }
    } catch (error: any) {
      console.error('Erreur login:', error);
      this.formError = error.error?.detail || this.translate.instant('LOGIN.ERRORS.INVALID_CREDENTIALS');
    } finally {
      this.isLoading = false;
    }
  }

  async signInWithGoogle(): Promise<void> {
    this.isLoading = true;
    try {
      window.location.href = `${this.apiUrl}/login/google`;
    } catch (error) {
      console.error('Erreur Google login:', error);
      const toast = await this.toastController.create({
        message: this.translate.instant('LOGIN.ERRORS.GOOGLE_ERROR'),
        duration: 3000,
        color: 'danger',
        position: 'top'
      });
      await toast.present();
    } finally {
      this.isLoading = false;
    }
  }

  goToRegister(): void {
    this.router.navigate(['/register']);
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}