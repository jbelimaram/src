import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { ToastController, Platform } from '@ionic/angular';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { Subscription } from 'rxjs';
import { TranslationService } from '../../services/translation.service';
import { HistoryService, HistoryEntry } from '../../services/history.service';
import { AuthService } from '../../services/auth.service';
import { DiseasesService } from '../../services/diseases.service';
import { WeatherService, WeatherData } from '../../services/weather.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { OverlayService } from '../../services/overlay.service';
import { environment } from '../../../environments/environment';
interface Disease {
  id: string;
  name: string;
  plants: string[];
  description: string;
  symptoms: string[];
  treatment: string;
  prevention: string;
  images: string[];
  severity: string;
}

@Component({
  selector: 'app-diseases',
  templateUrl: './diseases.page.html',
  styleUrls: ['./diseases.page.scss'],
  standalone: false
})
export class DiseasesPage implements OnInit, OnDestroy {
  @ViewChild('fileInput') fileInput!: ElementRef;
  @ViewChild('cameraFeed') cameraFeed!: ElementRef;
  @ViewChild('searchInput') searchInput!: ElementRef;

  private recommendations: { [key: string]: string } = {
    'Apple___Apple_scab': 'Appliquer un fongicide à base de cuivre (bouillie bordelaise) en prévention. En traitement curatif, utiliser un fongicide spécifique comme le difénoconazole et éliminer les feuilles infectées.',
    'Apple___Black_rot': 'Tailler et brûler les branches et fruits infectés. Appliquer un fongicide comme le mancozèbe au printemps et éviter les blessures sur les fruits.',
    'Apple___Cedar_apple_rust': 'Éliminer les genévriers proches qui servent d\'hôte alternatif. Pulvériser un fongicide comme le myclobutanil dès l\'apparition des symptômes.',
    'Apple___healthy': 'La plante est saine. Continuer les bonnes pratiques agricoles et surveiller régulièrement.',
    'Blueberry___healthy': 'La plante est saine. Maintenir une bonne gestion de l\'irrigation et surveiller régulièrement.',
    'Cherry_(including_sour)___Powdery_mildew': 'Pulvériser du soufre ou un fongicide à base de bicarbonate de potassium. Assurer une bonne aération des arbres.',
    'Cherry_(including_sour)___healthy': 'La plante est saine. Maintenir une bonne irrigation et surveiller régulièrement.',
    'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot': 'Utiliser des semences traitées et pratiquer la rotation des cultures. Appliquer un fongicide comme l\'azoxystrobine pendant la croissance.',
    'Corn_(maize)___Common_rust_': 'Appliquer un fongicide comme le tébuconazole dès les premiers symptômes et privilégier des variétés résistantes.',
    'Corn_(maize)___Northern_Leaf_Blight': 'Labourer les résidus de culture après la récolte et utiliser des fongicides préventifs comme la pyraclostrobine.',
    'Corn_(maize)___healthy': 'La plante est saine. Continuer la surveillance et maintenir une fertilisation équilibrée.',
    'Grape___Black_rot': 'Supprimer les grappes et feuilles infectées et appliquer un fongicide comme le mancozèbe avant et après la floraison.',
    'Grape___Esca_(Black_Measles)': 'Aucun traitement curatif efficace. Tailler les parties atteintes et désinfecter les outils. Dans les cas graves, arracher les ceps infectés.',
    'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)': 'Pulvériser un fongicide comme le folpel à la chute des feuilles et au débourrement. Maintenir un bon drainage du sol.',
    'Grape___healthy': 'La plante est saine. Maintenir une taille régulière et surveiller les symptômes.',
    'Orange___Haunglongbing_(Citrus_greening)': 'Aucun traitement curatif. Arracher les arbres infectés et lutter contre les psylles vecteurs avec des insecticides adaptés.',
    'Peach___Bacterial_spot': 'Appliquer des traitements à base de cuivre à l\'automne et au printemps et éviter les excès d\'azote.',
    'Peach___healthy': 'La plante est saine. Maintenir une bonne irrigation et surveiller les maladies.',
    'Pepper,_bell___Bacterial_spot': 'Utiliser des semences saines et pulvériser des traitements à base de cuivre ou des bactéricides. Pratiquer la rotation des cultures.',
    'Pepper,_bell___healthy': 'La plante est saine. Maintenir de bonnes pratiques culturales.',
    'Potato___Early_blight': 'Appliquer des fongicides préventifs comme le chlorothalonil et butter les plants pour protéger les tubercules.',
    'Potato___Late_blight': 'Pulvériser de la bouillie bordelaise en prévention ou utiliser des fongicides systémiques comme le métalaxyl. Détruire les plants fortement atteints.',
    'Potato___healthy': 'La plante est saine. Maintenir une bonne gestion de l\'irrigation et surveiller régulièrement.',
    'Raspberry___healthy': 'La plante est saine. Maintenir une bonne fertilisation et surveiller les parasites.',
    'Soybean___healthy': 'La plante est saine. Continuer la surveillance et pratiquer la rotation des cultures.',
    'Squash___Powdery_mildew': 'Pulvériser du soufre ou du bicarbonate de soude et arroser au pied pour éviter de mouiller le feuillage.',
    'Strawberry___Leaf_scorch': 'Éliminer les feuilles malades et appliquer un fongicide comme le captane après la récolte.',
    'Strawberry___healthy': 'La plante est saine. Maintenir une bonne aération des plants.',
    'Tomato___Bacterial_spot': 'Utiliser des semences certifiées et traiter avec des produits à base de cuivre. Pratiquer la rotation des cultures.',
    'Tomato___Early_blight': 'Pulvériser des fongicides comme le mancozèbe tous les 7 à 10 jours et utiliser du paillage pour éviter les projections de sol.',
    'Tomato___Late_blight': 'Appliquer de la bouillie bordelaise en prévention et utiliser des fongicides curatifs comme le cymoxanil en cas d\'infection.',
    'Tomato___Leaf_Mold': 'Améliorer la ventilation dans la culture et pulvériser un fongicide comme le chlorothalonil.',
    'Tomato___Septoria_leaf_spot': 'Éliminer les feuilles infectées et traiter avec un fongicide comme le difénoconazole. Éviter l\'humidité sur le feuillage.',
    'Tomato___Spider_mites Two-spotted_spider_mite': 'Utiliser un acaricide comme l\'abamectine ou introduire des acariens prédateurs. Maintenir une bonne humidité.',
    'Tomato___Target_Spot': 'Appliquer un fongicide comme l\'azoxystrobine en alternance avec du mancozèbe et réduire l\'humidité.',
    'Tomato___Tomato_Yellow_Leaf_Curl_Virus': 'Lutter contre les aleurodes vecteurs avec des insecticides et arracher les plants infectés.',
    'Tomato___Tomato_mosaic_virus': 'Désinfecter les outils et les mains, utiliser des variétés résistantes et éliminer les plants infectés.',
    'Tomato___healthy': 'La plante est saine. Continuer les bonnes pratiques culturales et surveiller régulièrement.'
  };

  // ========== LANGUE ET AFFICHAGE ==========
  currentLang: string = 'fr';
  currentYear: number = new Date().getFullYear();
  activePage: string = 'diseases';
  displayName: string = '';
  userEmail: string = '';
  isAdmin: boolean = false;

  // ========== DRAWERS ET NOTIFICATIONS ==========
  navDrawerOpen: boolean = false;
  notificationsPanelOpen: boolean = false;
  notifications: Notification[] = [];
  unreadNotifications: number = 0;

  // ========== MÉTÉO ==========
  weatherData: WeatherData | null = null;
  weatherLoading: boolean = false;
  weatherError: boolean = false;

  // ========== ANALYSE IMAGE ==========
  cameraModalOpen = false;
  diseaseModalOpen = false;
  chatbotOpen: boolean = false;
  selectedDisease: Disease | null = null;
  selectedImage: string | null = null;
  selectedFile: File | null = null;
  analyzing = false;
  analysisResult: any = null;
  progressValue: number = 0;
  currentProgressStep: number = 0;
  progressMessages = [
    'Téléchargement de l\'image...',
    'Analyse des caractéristiques...',
    'Comparaison avec la base de données...',
    'Génération des résultats...'
  ];
  currentPage = 1;
  itemsPerPage = 6;
  totalPages = 1;
  isDragging = false;
  private stream: MediaStream | null = null;
  private facingMode: 'user' | 'environment' = 'environment';

  // ========== BASE DE CONNAISSANCES ==========
  searchTerm: string = '';
  diseasesDatabase: Disease[] = [];
  filteredDiseases: Disease[] = [];
  selectedPlant = '';

  // ========== SUBSCRIPTIONS ==========
  private overlaySubscription: Subscription;

  constructor(
    private toastController: ToastController,
    private platform: Platform,
    private router: Router,
    private translationService: TranslationService,
    private cdr: ChangeDetectorRef,
    private historyService: HistoryService,
    private authService: AuthService,
    private http: HttpClient,
    private diseasesService: DiseasesService,
    private weatherService: WeatherService,
    private notificationService: NotificationService,
    private overlayService: OverlayService
  ) {
    this.currentLang = this.translationService.getCurrentLang();
    this.overlaySubscription = this.overlayService.overlayState$.subscribe(state => {
      if (this.navDrawerOpen !== state.navDrawerOpen) {
        this.navDrawerOpen = state.navDrawerOpen;
      }
      if (this.notificationsPanelOpen !== state.notificationsPanelOpen) {
        this.notificationsPanelOpen = state.notificationsPanelOpen;
      }
      if (this.chatbotOpen !== state.chatbotOpen) {
        this.chatbotOpen = state.chatbotOpen;
      }
      this.cdr.detectChanges();
    });
  }

  ngOnInit() {
    console.log('Page maladies initialisée avec succès');
    this.loadUserData();
    this.loadWeather();
    this.loadDiseasesFromBackend();
    this.loadNotifications();
    document.addEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  ngOnDestroy() {
    document.removeEventListener('keydown', this.handleEscapeKey.bind(this));
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
    }
    if (this.overlaySubscription) this.overlaySubscription.unsubscribe();
  }

  // ========== GESTION UTILISATEUR ==========
  private loadUserData() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.displayName = user.username || user.name || 'Agriculteur';
      this.userEmail = user.email;
      this.isAdmin = user.role === 'admin';
    }
  }

  // ========== MÉTÉO ==========
  private loadWeather() {
    this.weatherLoading = true;
    this.weatherService.getWeatherFallback().subscribe({
      next: (data) => {
        this.weatherData = data;
        this.weatherLoading = false;
        this.weatherError = false;
      },
      error: () => {
        this.weatherError = true;
        this.weatherLoading = false;
      }
    });
  }

  retryWeather() { this.loadWeather(); }

  // ========== NOTIFICATIONS ==========
  private async loadNotifications() {
    try {
      this.notifications = await firstValueFrom(this.notificationService.getNotifications());
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur chargement notifications:', error);
    }
  }

  async markNotificationAsRead(notificationId: string) {
    try {
      await firstValueFrom(this.notificationService.markAsRead(notificationId));
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) notif.read = true;
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  async markAllNotificationsAsRead() {
    try {
      await firstValueFrom(this.notificationService.markAllAsRead());
      this.notifications.forEach(n => n.read = true);
      this.unreadNotifications = 0;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  // ========== DRAWERS ==========
  toggleNavDrawer() { this.overlayService.setNavDrawerOpen(!this.navDrawerOpen); }
  closeNavDrawer() { this.overlayService.setNavDrawerOpen(false); }
  toggleNotificationsPanel() { this.overlayService.setNotificationsPanelOpen(!this.notificationsPanelOpen); }
  closeNotificationsPanel() { this.overlayService.setNotificationsPanelOpen(false); }
  toggleChatbot(): void { this.overlayService.setChatbotOpen(!this.chatbotOpen); }
  onChatbotClose(): void { this.overlayService.setChatbotOpen(false); }

  handleEscapeKey(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      this.overlayService.closeAllOverlays();
    }
  }

  // ========== MALADIES : BASE DE CONNAISSANCES ==========
  async loadDiseasesFromBackend() {
    try {
      const diseases = await firstValueFrom(this.diseasesService.getAllDiseases());
      this.diseasesDatabase = diseases;
      this.filteredDiseases = [...this.diseasesDatabase];
      this.updatePagination();
      this.applyFilters();
    } catch (error) {
      console.error('Erreur chargement maladies:', error);
      this.showNotification('Erreur de chargement des maladies', 'error');
    }
  }

  getFirstPlant(disease: Disease | null): string {
    return disease?.plants && disease.plants.length ? disease.plants[0] : '';
  }

  getFirstImage(disease: Disease): string {
    const API_URL = environment.apiUrl;
    if (disease?.images && disease.images.length > 0 && disease.images[0]) {
      const imgUrl = disease.images[0];
      if (imgUrl.startsWith('http://') || imgUrl.startsWith('https://')) {
        return imgUrl;
      }
      if (imgUrl.startsWith('/uploads/')) {
        return `${API_URL}${imgUrl}`;
      }
      if (imgUrl.startsWith('uploads/')) {
        return `${API_URL}/${imgUrl}`;
      }
      if (!imgUrl.includes('/')) {
        return `${API_URL}/uploads/diseases/${imgUrl}`;
      }
      return imgUrl;
    }
    return 'assets/default-disease.jpg';
  }

  onSearch() { this.applyFilters(); }
  onFilterChange() { this.applyFilters(); }

  applyFilters() {
    let filtered = this.diseasesDatabase;
    if (this.selectedPlant) {
      filtered = filtered.filter(d => d.plants.includes(this.selectedPlant));
    }
    if (this.searchTerm.trim() !== '') {
      const term = this.searchTerm.toLowerCase().trim();
      filtered = filtered.filter(d =>
        d.name.toLowerCase().includes(term) ||
        d.plants.some(p => p.toLowerCase().includes(term)) ||
        d.description.toLowerCase().includes(term) ||
        d.symptoms.some(s => s.toLowerCase().includes(term))
      );
    }
    this.filteredDiseases = filtered;
    this.currentPage = 1;
    this.updatePagination();
  }

  clearSearch() {
    this.searchTerm = '';
    this.selectedPlant = '';
    this.applyFilters();
    if (this.searchInput?.nativeElement) this.searchInput.nativeElement.focus();
  }

  get paginatedDiseases() {
    const start = (this.currentPage - 1) * this.itemsPerPage;
    return this.filteredDiseases.slice(start, start + this.itemsPerPage);
  }

  updatePagination() {
    this.totalPages = Math.ceil(this.filteredDiseases.length / this.itemsPerPage);
    if (this.currentPage > this.totalPages && this.totalPages > 0) this.currentPage = this.totalPages;
  }

  previousPage() { if (this.currentPage > 1) this.currentPage--; }
  nextPage() { if (this.currentPage < this.totalPages) this.currentPage++; }

  showDiseaseDetails(disease: Disease) {
    this.selectedDisease = disease;
    this.diseaseModalOpen = true;
  }

  closeDiseaseModal() {
    this.diseaseModalOpen = false;
    this.selectedDisease = null;
  }

  // ========== ANALYSE D'IMAGE ==========
  triggerFileInput() { this.fileInput.nativeElement.click(); }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file && file.type.match('image.*')) {
      this.selectedFile = file;
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.selectedImage = e.target.result;
        this.analysisResult = null;
      };
      reader.readAsDataURL(file);
    } else {
      this.showNotification('Veuillez sélectionner une image valide', 'error');
    }
  }

  onDragEnter(event: DragEvent) { event.preventDefault(); this.isDragging = true; }
  onDragOver(event: DragEvent) { event.preventDefault(); }
  onDragLeave(event: DragEvent) { event.preventDefault(); this.isDragging = false; }
  onDrop(event: DragEvent) {
    event.preventDefault();
    this.isDragging = false;
    const files = event.dataTransfer?.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type.match('image.*')) {
        this.selectedFile = file;
        const reader = new FileReader();
        reader.onload = (e: any) => {
          this.selectedImage = e.target.result;
          this.analysisResult = null;
        };
        reader.readAsDataURL(file);
      } else {
        this.showNotification('Veuillez déposer une image valide', 'error');
      }
    }
  }

  openCamera() {
    this.cameraModalOpen = true;
    setTimeout(() => this.startCamera(), 100);
  }

  async startCamera() {
    try {
      const constraints = { video: { facingMode: this.facingMode }, audio: false };
      this.stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (this.cameraFeed?.nativeElement) this.cameraFeed.nativeElement.srcObject = this.stream;
    } catch (error) {
      console.error('Erreur caméra:', error);
      this.showNotification('Impossible d\'accéder à la caméra', 'error');
      this.closeCamera();
    }
  }

  capturePhoto() {
    if (this.cameraFeed?.nativeElement) {
      const video = this.cameraFeed.nativeElement;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], "camera_photo.jpg", { type: "image/jpeg" });
            this.selectedFile = file;
            this.selectedImage = canvas.toDataURL('image/jpeg');
            this.analysisResult = null;
            this.closeCamera();
          }
        }, 'image/jpeg');
      }
    }
  }

  switchCamera() {
    this.facingMode = this.facingMode === 'user' ? 'environment' : 'user';
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    setTimeout(() => this.startCamera(), 100);
  }

  closeCamera() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    this.cameraModalOpen = false;
  }

  private async callBackendPrediction(file: File): Promise<{ class: string; confidence: number }> {
    const token = this.authService.getToken();
    if (!token) throw new Error('Non authentifié');

    const formData = new FormData();
    formData.append('file', file);

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });

    try {
      const response = await firstValueFrom(
        this.http.post<{ class: string; confidence: number }>(
          `${environment.apiUrl}/disease/predict`,
          formData,
          { headers }
        )
      );
      return response;
    } catch (error) {
      console.error('Erreur appel backend maladie:', error);
      throw error;
    }
  }

  async analyzeImage() {
  if (!this.selectedFile) {
    this.showNotification("Veuillez d'abord sélectionner une photo", 'warning');
    return;
  }

  this.analyzing = true;
  this.progressValue = 0;
  this.currentProgressStep = 0;

  // Simulation de progression pendant l'appel asynchrone
  const progressInterval = setInterval(() => {
    if (this.progressValue < 90) {
      this.progressValue += 10;
      this.currentProgressStep = Math.floor(this.progressValue / 25);
    }
  }, 500);

  try {
    const result = await this.callBackendPrediction(this.selectedFile);
    clearInterval(progressInterval);
    this.progressValue = 100;
    this.currentProgressStep = 3;

    if (result.class === 'No leaf detected!') {
      this.analysisResult = {
        disease: 'Aucune feuille détectée',
        plant: 'Inconnue',
        probability: '0',
        treatment: 'Veuillez prendre une photo où une feuille est clairement visible.',
        classLabel: result.class
      };
      this.showNotification('Aucune feuille détectée dans l\'image', 'warning');
      return;
    }

    const classLabel = result.class;
    const parts = classLabel.split('___');
    const plant = parts[0] || 'Plante';
    const diseaseRaw = parts[1] ? parts[1].replace(/_/g, ' ') : 'Inconnue';
    const treatment = this.recommendations[classLabel] || 'Traitement non spécifié. Consultez un expert agricole.';

    this.analysisResult = {
      disease: diseaseRaw,
      plant: plant,
      probability: (Number(result.confidence) * 100).toFixed(1),
      treatment: treatment,
      classLabel: classLabel
    };

    const currentUser = this.authService.getCurrentUser();
    if (currentUser && currentUser.email) {
      const historyEntry: HistoryEntry = {
        user_email: currentUser.email,
        operation_type: 'disease_detection',
        operation_key: 'DISEASES.IMAGE_ANALYSIS.RESULTS.DISEASE',
        details: {
          disease: this.analysisResult.disease,
          plant: this.analysisResult.plant,
          probability: this.analysisResult.probability + '%',
          treatment: this.analysisResult.treatment
        },
        status: 'success'
      };
      this.historyService.addHistory(historyEntry).subscribe();
    }

    this.showNotification('Analyse terminée avec succès', 'success');
  } catch (error) {
    clearInterval(progressInterval);
    console.error('Erreur lors de l\'analyse:', error);
    this.showNotification('Erreur de connexion avec le service d\'analyse.', 'error');
    this.cancelAnalysis();
  } finally {
    this.analyzing = false;
  }
}

  cancelAnalysis() {
    this.selectedImage = null;
    this.selectedFile = null;
    this.analysisResult = null;
    this.analyzing = false;
    this.progressValue = 0;
    this.currentProgressStep = 0;
  }

  showMoreInfo() {
    if (this.analysisResult && this.analysisResult.classLabel !== 'No leaf detected!') {
      const disease = this.diseasesDatabase.find(d =>
        this.analysisResult.disease.toLowerCase().includes(d.name.toLowerCase()) ||
        d.name.toLowerCase().includes(this.analysisResult.disease.toLowerCase())
      );
      if (disease) {
        this.selectedDisease = disease;
        this.diseaseModalOpen = true;
      } else {
        this.showNotification('Information détaillée non disponible dans la base de données', 'warning');
      }
    }
  }

  // ========== UTILITAIRES ==========
  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.cdr.detectChanges();
  }

  onImageError(event: any) {
    event.target.src = 'assets/default-disease.jpg';
  }

  handleImageError(event: any) { event.target.src = 'https://ui-avatars.com/api/?name=AgriTunisie&background=4CAF50&color=fff&size=128'; }

  isActive(route: string): boolean { return this.activePage === route; }

  async showNotification(message: string, type: 'success' | 'error' | 'warning' | 'info' = 'success') {
    const toast = await this.toastController.create({
      message, duration: 3000, position: 'top',
      color: type === 'success' ? 'success' : type === 'error' ? 'danger' : type === 'warning' ? 'warning' : 'primary'
    });
    await toast.present();
  }

  logout(event?: Event) {
    if (event) event.preventDefault();
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}