import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DiseasesPageRoutingModule } from './diseases-routing.module';

import { DiseasesPage } from './diseases.page';
import { SharedModule } from '../../shared/shared.module';

// ===== IMPORT DU CHATBOT MODAL =====
import { ChatbotModalModule } from '../../components/chatbot-modal/chatbot-modal.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DiseasesPageRoutingModule,
    SharedModule,
    ChatbotModalModule
  ],
  declarations: [
    DiseasesPage
  ]
})
export class DiseasesPageModule {}