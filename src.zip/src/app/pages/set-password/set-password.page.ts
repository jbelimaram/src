import { Component, OnInit, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastController, LoadingController } from '@ionic/angular';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from '../../services/auth.service';
import { TranslateService } from '@ngx-translate/core';
import { TranslationService } from '../../services/translation.service'; // adjust path if needed
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-set-password',
  templateUrl: './set-password.page.html',
  styleUrls: ['./set-password.page.scss'],
  standalone: false
})
export class SetPasswordPage implements OnInit {
  passwordForm: FormGroup;
  isLoading = false;
  showPassword = false;
  showConfirmPassword = false;
  currentLang: string = 'fr';   // default language

  private apiUrl = environment.apiUrl;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient,
    private authService: AuthService,
    private toastController: ToastController,
    private loadingController: LoadingController,
    private translate: TranslateService,
    private translationService: TranslationService,
    private cdr: ChangeDetectorRef,
    private renderer: Renderer2
  ) {
    this.passwordForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });

    // Initialize language and direction
    this.currentLang = this.translationService.getCurrentLang();
    this.translate.use(this.currentLang);
    this.setDocumentDirection(this.currentLang);
  }

  ngOnInit() {
    // Redirect if already has a password (guard should prevent, but just in case)
    const user = this.authService.getCurrentUser();
    if (user && user.hasPassword) {
      this.router.navigate(['/dashboard']);
    }
  }

  /**
   * Sets the document direction based on language (RTL for Arabic, LTR otherwise)
   */
  private setDocumentDirection(lang: string): void {
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    this.renderer.setAttribute(document.documentElement, 'dir', dir);
    this.renderer.setAttribute(document.documentElement, 'lang', lang);
  }

  /**
   * Optional: Change language and update direction
   */
  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.setDocumentDirection(lang);
    this.cdr.detectChanges();
  }

  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('newPassword')?.value;
    const confirm = control.get('confirmPassword')?.value;
    if (password && confirm && password !== confirm) {
      return { passwordMismatch: true };
    }
    return null;
  }

  get newPassword() { return this.passwordForm.get('newPassword')!; }
  get confirmPassword() { return this.passwordForm.get('confirmPassword')!; }

  togglePassword() { this.showPassword = !this.showPassword; }
  toggleConfirmPassword() { this.showConfirmPassword = !this.showConfirmPassword; }

  async onSubmit() {
    if (this.passwordForm.invalid) return;

    this.isLoading = true;
    const loading = await this.loadingController.create({
      message: this.translate.instant('SET_PASSWORD.UPDATING')
    });
    await loading.present();

    const token = this.authService.getToken(); // you need a getToken method in AuthService
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    try {
      await this.http.post(`${this.apiUrl}/set-password`, 
        { password: this.newPassword.value },
        { headers }
      ).toPromise();

      // Update user in session storage to mark hasPassword as true
      const user = this.authService.getCurrentUser();
      if (user) {
        user.hasPassword = true;
        sessionStorage.setItem('current_user', JSON.stringify(user));
        sessionStorage.setItem('has_password', 'true');
      }

      await loading.dismiss();
      const toast = await this.toastController.create({
        message: this.translate.instant('SET_PASSWORD.SUCCESS'),
        duration: 3000,
        color: 'success',
        position: 'top'
      });
      await toast.present();

      // Redirect to farm-setup or dashboard
      if (!user.hasFarm) {
        this.router.navigate(['/farm-setup']);
      } else {
        this.router.navigate(['/dashboard']);
      }

    } catch (error: any) {
      await loading.dismiss();
      const message = error.error?.detail || this.translate.instant('SET_PASSWORD.ERROR');
      const toast = await this.toastController.create({
        message,
        duration: 3000,
        color: 'danger',
        position: 'top'
      });
      await toast.present();
    } finally {
      this.isLoading = false;
    }
  }

  handleImageError(event: any): void {
    const img = event.target as HTMLImageElement;
    img.src = 'assets/photos/logo-default.png';
  }
}