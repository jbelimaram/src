import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ToastController } from '@ionic/angular';
import { Storage } from '@ionic/storage-angular';
import { TranslationService } from '../../services/translation.service';
import { TranslateService } from '@ngx-translate/core';
import { HistoryService, HistoryEntry } from '../../services/history.service';
import { AuthService } from '../../services/auth.service';
import { WeatherService, WeatherData } from '../../services/weather.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';

interface PredictionData {
  id: string;
  name: string;
  crop: string;
  area: number;
  soilType: string;
  ph: number;
  organicMatter: number;
  nitrogen: number;
  phosphorus: number;
  potassium: number;
  rainfall: number;
  temperature: number;
  humidity: number;
  sunlight: number;
  plantingDensity: number;
  irrigationType: string;
  pesticideUse: string;
  rotation: string;
  yield: number;
  totalYield: number;
  date: string;
}

interface ExplanationFactor {
  text: string;
  impact: number;
}

interface ExplanationData {
  positive: { text: string; impact: number }[];
  negative: { text: string; impact: number }[];
  summary: string;
}

@Component({
  selector: 'app-rendement',
  templateUrl: './rendement.page.html',
  styleUrls: ['./rendement.page.scss'],
  standalone: false
})
export class RendementPage implements OnInit {
  // ========== LANGUE ET AFFICHAGE ==========
  currentLang: string = 'fr';
  currentYear: number = new Date().getFullYear();
  activePage: string = 'rendement';
  chatbotOpen: boolean = false;
  displayName: string = '';
  userEmail: string = '';
  isAdmin: boolean = false;

  // ========== DRAWERS ET NOTIFICATIONS ==========
  navDrawerOpen: boolean = false;
  notificationsPanelOpen: boolean = false;
  notifications: Notification[] = [];
  unreadNotifications: number = 0;

  // ========== MÉTÉO ==========
  weatherData: WeatherData | null = null;
  weatherLoading: boolean = false;
  weatherError: boolean = false;

  // ========== PARAMÈTRES DE PRÉDICTION ==========
  region: string = 'nord';
  selectedCrop: string = '';
  area: number = 1.0;
  soilType: string = 'limoneux';
  rainfall: number = 600;
  temperature: number = 22;
  fertilizerUsed: string = 'oui';
  irrigation: boolean = true;
  weatherCondition: string = 'ensoleille';
  daysToHarvest: number = 120;

  cropError: string = '';
  areaError: string = '';

  showResults: boolean = false;
  isLoading: boolean = false;
  currentPrediction: PredictionData | null = null;
  maxYieldValue: number = 5000;
  predictionName: string = '';

  confidenceLevel: number = 0;
  yieldPercentage: number = 0;
  explanationFactors: ExplanationData | null = null;

  // Précision du modèle (fixe)
  private readonly MODEL_ACCURACY = 91;

  constructor(
    private router: Router,
    private alertController: AlertController,
    private toastController: ToastController,
    private storage: Storage,
    private translationService: TranslationService,
    private translate: TranslateService,
    private historyService: HistoryService,
    private authService: AuthService,
    private weatherService: WeatherService,
    private notificationService: NotificationService,
    private http: HttpClient,
    private cdr: ChangeDetectorRef
  ) {
    this.currentLang = this.translationService.getCurrentLang();
  }

  async ngOnInit() {
    await this.storage.create();
    this.loadUserData();
    this.loadWeather();
    this.loadNotifications();
    document.addEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  ngOnDestroy() {
    document.removeEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  // ========== GESTION UTILISATEUR ==========
  private loadUserData() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.displayName = user.username || user.name || 'Agriculteur';
      this.userEmail = user.email;
      this.isAdmin = user.role === 'admin';
    }
  }

  // ========== MÉTÉO ==========
  private loadWeather() {
    this.weatherLoading = true;
    this.weatherService.getWeatherFallback().subscribe({
      next: (data) => {
        this.weatherData = data;
        this.weatherLoading = false;
        this.weatherError = false;
      },
      error: () => {
        this.weatherError = true;
        this.weatherLoading = false;
      }
    });
  }

  retryWeather() {
    this.loadWeather();
  }

  // ========== NOTIFICATIONS ==========
  private async loadNotifications() {
    try {
      this.notifications = await firstValueFrom(this.notificationService.getNotifications());
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur chargement notifications:', error);
    }
  }

  async markNotificationAsRead(notificationId: string) {
    try {
      await firstValueFrom(this.notificationService.markAsRead(notificationId));
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) notif.read = true;
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  async markAllNotificationsAsRead() {
    try {
      await firstValueFrom(this.notificationService.markAllAsRead());
      this.notifications.forEach(n => n.read = true);
      this.unreadNotifications = 0;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  // ========== DRAWERS ==========
  toggleNavDrawer() { this.navDrawerOpen = !this.navDrawerOpen; }
  closeNavDrawer() { this.navDrawerOpen = false; }
  toggleNotificationsPanel() { this.notificationsPanelOpen = !this.notificationsPanelOpen; }
  closeNotificationsPanel() { this.notificationsPanelOpen = false; }

  handleEscapeKey(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      if (this.navDrawerOpen) this.closeNavDrawer();
      if (this.notificationsPanelOpen) this.closeNotificationsPanel();
    }
  }

  // ========== CHATBOT ==========
  toggleChatbot(): void {
    this.chatbotOpen = !this.chatbotOpen;
  }
  onChatbotClose(): void {
    this.chatbotOpen = false;
  }

  // ========== LANGUE ==========
  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.cdr.detectChanges();
  }

  getCurrentLang(): string {
    return this.currentLang;
  }

  // ========== NAVIGATION (ancienne, conservée pour compatibilité) ==========
  navigateTo(page: string) {
    this.activePage = page;
    this.router.navigate([`/${page}`]);
  }

  isActive(page: string): boolean {
    return this.activePage === page;
  }

  logout(event?: Event) {
    if (event) event.preventDefault();
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  handleImageError(event: any) {
    event.target.src = 'assets/photos/logo-default.png';
  }

  // ========== LOGIQUE MÉTIER ==========
  selectCrop(crop: string) {
    this.selectedCrop = crop;
    this.cropError = '';
    this.updateYieldScale();
  }

  validateArea() {
    if (this.area <= 0) {
      this.areaError = 'La superficie doit être supérieure à 0';
    } else {
      this.areaError = '';
    }
  }

  async showInfo(titleKey: string, messageKey: string) {
    const title = this.translate.instant(titleKey);
    const message = this.translate.instant(messageKey);
    const alert = await this.alertController.create({
      header: title,
      message: message,
      buttons: ['OK']
    });
    await alert.present();
  }

  validateDaysToHarvest() {
    if (this.daysToHarvest < 60) {
      this.daysToHarvest = 60;
      this.showToastMessage('Les jours avant récolte ont été ajustés à 60 (minimum requis)', 'warning');
    } else if (this.daysToHarvest > 150) {
      this.daysToHarvest = 150;
      this.showToastMessage('Les jours avant récolte ont été ajustés à 150 (maximum autorisé)', 'warning');
    }
  }

  // ========== APPEL AU BACKEND (PROXY) ==========
  private async callPredictionAPI(): Promise<number> {
  const token = this.authService.getToken();
  if (!token) {
    throw new Error('Non authentifié');
  }

  // Mappage des valeurs françaises vers l'API Gradio (backend proxy)
  const regionMap: { [key: string]: string } = {
    nord: 'North', sud: 'South', est: 'East', ouest: 'West'
  };
  const soilMap: { [key: string]: string } = {
    argileux: 'Clay', limoneux: 'Loam', sableux: 'Sandy', limon: 'Silt'
  };
  const cropMap: { [key: string]: string } = {
    cotton: 'Cotton', rice: 'Rice', barley: 'Barley',
    soybean: 'Soybean', wheat: 'Wheat', maize: 'Maize'
  };
  const weatherMap: { [key: string]: string } = {
    ensoleille: 'Sunny', pluvieux: 'Rainy', nuageux: 'Cloudy'
  };

  // Type d'irrigation (par défaut Drip si irrigation activée, sinon Surface)
  const irrigationType = this.irrigation ? 'Drip' : 'Surface';

  const payload = {
    region: regionMap[this.region],
    soil_type: soilMap[this.soilType],
    crop: cropMap[this.selectedCrop],
    rainfall: this.rainfall,
    temperature: this.temperature,
    fertilizer_used: this.fertilizerUsed === 'oui',
    irrigation_used: irrigationType,
    weather_condition: weatherMap[this.weatherCondition],
    days_to_harvest: this.daysToHarvest
  };

  const headers = new HttpHeaders({
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  });

  try {
    // ✅ CORRECTED: Use backticks, not single quotes
    const response = await firstValueFrom(
      this.http.post<{ yield_tonnes_per_ha: number }>(
        `${environment.apiUrl}/rendement/predict`,
        payload,
        { headers }
      )
    );
    // Convertir tonnes/ha → kg/ha
    return response.yield_tonnes_per_ha * 1000;
  } catch (error) {
    console.error('Erreur appel backend rendement:', error);
    throw error;
  }
}
  async predictYield() {
    if (!this.selectedCrop) {
      this.cropError = 'Veuillez sélectionner une culture';
      await this.showToastMessage('Veuillez sélectionner une culture', 'warning');
      return;
    }
    if (this.area <= 0) {
      this.areaError = 'La superficie doit être supérieure à 0';
      await this.showToastMessage('La superficie doit être supérieure à 0', 'warning');
      return;
    }

    this.validateDaysToHarvest();

    this.isLoading = true;
    this.showResults = false;

    try {
      const predictionKgPerHa = await this.callPredictionAPI();
      this.generatePredictionResults(predictionKgPerHa);
      this.generateExplanation();
      this.showResults = true;

      const currentUser = this.authService.getCurrentUser();
      if (currentUser && currentUser.email && this.currentPrediction) {
        const historyEntry: HistoryEntry = {
          user_email: currentUser.email,
          operation_type: 'yield_prediction',
          operation_key: 'RENDEMENT.RESULTS.ESTIMATED_YIELD',
          details: {
            crop: this.selectedCrop,
            area: this.area,
            yield: this.currentPrediction.yield,
            totalYield: this.currentPrediction.totalYield,
            region: this.region,
            soilType: this.soilType,
            rainfall: this.rainfall,
            temperature: this.temperature,
            irrigation: this.irrigation,
            weatherCondition: this.weatherCondition,
            daysToHarvest: this.daysToHarvest
          },
          status: 'success'
        };
        this.historyService.addHistory(historyEntry).subscribe({
          next: () => console.log('Historique enregistré (rendement)'),
          error: (err) => console.error('Erreur historique', err)
        });
      }

      await this.showToastMessage('Prédiction réalisée avec succès!', 'success');
    } catch (error) {
      console.error('Erreur API:', error);
      await this.showToastMessage('Erreur lors de la prédiction. Veuillez réessayer.', 'danger');
      this.showResults = false;
    } finally {
      this.isLoading = false;
    }

    if (this.showResults) {
      setTimeout(() => {
        const resultsSection = document.querySelector('.results-section');
        if (resultsSection) resultsSection.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }

  private generatePredictionResults(predictedKgPerHa: number) {
    this.updateYieldScale();
    this.yieldPercentage = Math.min(Math.round((predictedKgPerHa / this.maxYieldValue) * 100), 100);
    this.confidenceLevel = this.MODEL_ACCURACY;
    const totalYield = predictedKgPerHa * this.area;
    this.currentPrediction = {
      id: Date.now().toString(),
      name: '',
      crop: this.selectedCrop,
      area: this.area,
      soilType: this.soilType,
      ph: 0,
      organicMatter: 0,
      nitrogen: 0,
      phosphorus: 0,
      potassium: 0,
      rainfall: this.rainfall,
      temperature: this.temperature,
      humidity: 0,
      sunlight: 0,
      plantingDensity: 0,
      irrigationType: this.irrigation ? 'oui' : 'non',
      pesticideUse: '',
      rotation: '',
      yield: Math.round(predictedKgPerHa),
      totalYield: Math.round(totalYield),
      date: new Date().toISOString()
    };
  }

  generateExplanation() {
    const positiveFactors: { text: string; impact: number }[] = [];
    const negativeFactors: { text: string; impact: number }[] = [];

    if (this.region === 'nord') positiveFactors.push({ text: "Région Nord favorable", impact: 10 });
    else if (this.region === 'sud') negativeFactors.push({ text: "Région Sud moins favorable", impact: -10 });
    else if (this.region === 'est') positiveFactors.push({ text: "Région Est favorable", impact: 5 });
    else if (this.region === 'ouest') negativeFactors.push({ text: "Région Ouest moins favorable", impact: -5 });

    if (this.soilType === 'limoneux') positiveFactors.push({ text: "Sol limoneux idéal", impact: 15 });
    else if (this.soilType === 'argileux') positiveFactors.push({ text: "Sol argileux (bonne rétention)", impact: 8 });
    else if (this.soilType === 'sableux') negativeFactors.push({ text: "Sol sableux (faible rétention)", impact: -15 });
    else if (this.soilType === 'limon') positiveFactors.push({ text: "Sol limoneux équilibré", impact: 10 });

    if (this.rainfall >= 500 && this.rainfall <= 800) positiveFactors.push({ text: "Précipitations optimales", impact: 10 });
    else if (this.rainfall < 300) negativeFactors.push({ text: "Précipitations insuffisantes", impact: -20 });
    else if (this.rainfall > 1200) negativeFactors.push({ text: "Excès de précipitations", impact: -15 });

    if (this.temperature >= 20 && this.temperature <= 25) positiveFactors.push({ text: "Température idéale", impact: 10 });
    else if (this.temperature < 15 || this.temperature > 30) negativeFactors.push({ text: "Température stressante", impact: -15 });

    if (this.fertilizerUsed === 'oui') positiveFactors.push({ text: "Utilisation d'engrais", impact: 20 });
    else negativeFactors.push({ text: "Pas d'engrais", impact: -20 });

    if (this.irrigation === true) positiveFactors.push({ text: "Irrigation utilisée", impact: 20 });
    else negativeFactors.push({ text: "Absence d'irrigation", impact: -25 });

    if (this.weatherCondition === 'ensoleille') positiveFactors.push({ text: "Conditions ensoleillées", impact: 10 });
    else if (this.weatherCondition === 'pluvieux') negativeFactors.push({ text: "Conditions pluvieuses", impact: -10 });
    else if (this.weatherCondition === 'nuageux') positiveFactors.push({ text: "Conditions nuageuses modérées", impact: 5 });

    if (this.daysToHarvest > 150) positiveFactors.push({ text: "Cycle long favorable", impact: 10 });
    else if (this.daysToHarvest < 90) negativeFactors.push({ text: "Cycle trop court", impact: -10 });

    const topPositive = positiveFactors.slice(0, 4);
    const topNegative = negativeFactors.slice(0, 3);
    const totalPositiveImpact = topPositive.reduce((sum, f) => sum + f.impact, 0);
    const totalNegativeImpact = topNegative.reduce((sum, f) => sum + Math.abs(f.impact), 0);

    let summary = "";
    if (totalPositiveImpact > totalNegativeImpact + 15) summary = "✅ Excellent potentiel ! Les conditions sont très favorables.";
    else if (totalPositiveImpact > totalNegativeImpact) summary = "👍 Bon potentiel. Optimisez les points faibles pour améliorer.";
    else if (totalPositiveImpact === totalNegativeImpact) summary = "⚖️ Potentiel moyen. Des ajustements sont possibles.";
    else summary = "⚠️ Potentiel limité. Revoir les pratiques (irrigation, engrais, choix de la région).";

    this.explanationFactors = { positive: topPositive, negative: topNegative, summary: summary };
  }

  updateYieldScale() {
    if (!this.selectedCrop) return;
    switch (this.selectedCrop) {
      case 'cotton':   this.maxYieldValue = 5000; break;
      case 'rice':     this.maxYieldValue = 8000; break;
      case 'barley':   this.maxYieldValue = 6000; break;
      case 'soybean':  this.maxYieldValue = 4000; break;
      case 'wheat':    this.maxYieldValue = 7000; break;
      case 'maize':    this.maxYieldValue = 10000; break;
      default:         this.maxYieldValue = 5000;
    }
  }

  getCropName(cropCode: string): string {
    const names: { [key: string]: string } = { cotton: 'Coton', rice: 'Riz', barley: 'Orge', soybean: 'Soja', wheat: 'Blé', maize: 'Maïs' };
    return names[cropCode] || cropCode;
  }
  getSoilTypeName(soilType: string): string {
    const names: { [key: string]: string } = { argileux: 'Argileux', limoneux: 'Limoneux', sableux: 'Sableux', limon: 'Limon' };
    return names[soilType] || soilType;
  }
  getWeatherConditionName(condition: string): string {
    const names: { [key: string]: string } = { ensoleille: 'Ensoleillé', pluvieux: 'Pluvieux', nuageux: 'Nuageux' };
    return names[condition] || condition;
  }
  getFertilizerName(used: string): string {
    return used === 'oui' ? 'Oui' : 'Non';
  }
  getRegionName(regionCode: string): string {
    const names: { [key: string]: string } = { nord: 'Nord', sud: 'Sud', est: 'Est', ouest: 'Ouest' };
    return names[regionCode] || regionCode;
  }

  getFormattedTotalYield(): string {
    if (!this.currentPrediction) return '0';
    return this.formatNumber(this.currentPrediction.totalYield) + ' kg';
  }

  async savePrediction() {
    if (!this.currentPrediction) {
      await this.showToastMessage('Veuillez d\'abord effectuer une prédiction', 'warning');
      return;
    }
    if (!this.predictionName.trim()) {
      const alert = await this.alertController.create({
        header: 'Nom de la prédiction',
        message: 'Veuillez donner un nom à cette prédiction',
        inputs: [ { name: 'name', type: 'text', placeholder: 'Ex: Champ Nord 2025', value: this.predictionName } ],
        buttons: [
          { text: 'Annuler', role: 'cancel' },
          { text: 'Sauvegarder', handler: async (data) => {
              if (data.name && data.name.trim()) {
                this.predictionName = data.name.trim();
                this.currentPrediction!.name = this.predictionName;
                await this.saveToStorage();
              }
            }
          }
        ]
      });
      await alert.present();
      return;
    }
    this.currentPrediction.name = this.predictionName;
    await this.saveToStorage();
  }

  async saveToStorage() {
    if (!this.currentPrediction) return;
    try {
      const existingPredictions = await this.storage.get('yieldPredictions') || [];
      const updatedPredictions = [this.currentPrediction, ...existingPredictions];
      await this.storage.set('yieldPredictions', updatedPredictions);
      await this.storage.set('currentYieldPrediction', this.currentPrediction);
      await this.showToastMessage('Prédiction enregistrée avec succès!', 'success');
      this.predictionName = '';
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
      await this.showToastMessage('Erreur lors de la sauvegarde', 'danger');
    }
  }

  async exportCsv() {
    if (!this.currentPrediction) {
      await this.showToastMessage('Aucune donnée à exporter', 'warning');
      return;
    }

    const rows = [
      ['RAPPORT DE PRÉDICTION DE RENDEMENT AGRICOLE'],
      [`Généré le ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}`],
      [],
      ['INFORMATIONS GÉNÉRALES'],
      ['Paramètre', 'Valeur', 'Unité'],
      ['Culture', this.getCropName(this.currentPrediction.crop), '-'],
      ['Superficie', this.currentPrediction.area.toString().replace('.', ','), 'ha'],
      ['Type de sol', this.getSoilTypeName(this.currentPrediction.soilType), '-'],
      ['Région', this.getRegionName(this.region), '-'],
      [],
      ['CONDITIONS CLIMATIQUES'],
      ['Paramètre', 'Valeur', 'Unité'],
      ['Précipitations', this.currentPrediction.rainfall.toString().replace('.', ','), 'mm'],
      ['Température', this.currentPrediction.temperature.toString().replace('.', ','), '°C'],
      ['Condition météo', this.getWeatherConditionName(this.weatherCondition), '-'],
      ['Jours jusqu\'à récolte', this.daysToHarvest.toString(), 'jours'],
      [],
      ['PRATIQUES CULTURALES'],
      ['Paramètre', 'Valeur', 'Unité'],
      ['Engrais utilisé', this.getFertilizerName(this.fertilizerUsed), '-'],
      ['Irrigation', this.irrigation ? 'Oui' : 'Non', '-'],
      [],
      ['RÉSULTATS DE LA PRÉDICTION'],
      ['Paramètre', 'Valeur', 'Unité'],
      ['Rendement estimé', this.currentPrediction.yield.toString().replace('.', ','), 'kg/ha'],
      ['Rendement total', this.currentPrediction.totalYield.toString().replace('.', ','), 'kg'],
      ['Fiabilité du modèle', this.MODEL_ACCURACY.toString(), '%'],
      [],
      ['INFORMATIONS COMPLÉMENTAIRES'],
      ['ID de prédiction', this.currentPrediction.id, '-'],
      ['Date de la prédiction', new Date(this.currentPrediction.date).toLocaleDateString('fr-FR'), '-'],
      ['Heure de la prédiction', new Date(this.currentPrediction.date).toLocaleTimeString('fr-FR'), '-'],
      [],
      ['ANALYSE DES FACTEURS'],
      ['Type', 'Facteur', 'Impact']
    ];

    if (this.explanationFactors?.positive) {
      this.explanationFactors.positive.forEach(factor => rows.push(['Positif', factor.text, `+${factor.impact}%`]));
    }
    if (this.explanationFactors?.negative) {
      this.explanationFactors.negative.forEach(factor => rows.push(['Négatif', factor.text, `${factor.impact}%`]));
    }
    if (this.explanationFactors?.summary) {
      rows.push([]);
      rows.push(['RÉSUMÉ']);
      rows.push([this.explanationFactors.summary]);
    }

    rows.push([]);
    rows.push(['-- FIN DU RAPPORT --']);

    const csvContent = rows.map(row => row.join(';')).join('\n');
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const dateStr = new Date().toISOString().slice(0, 10);
    const cropName = this.getCropName(this.currentPrediction.crop).toLowerCase();
    link.setAttribute('href', url);
    link.setAttribute('download', `prediction_${cropName}_${dateStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    await this.showToastMessage(`Rapport exporté avec succès`, 'success');
  }

  async showToastMessage(message: string, color: 'success' | 'warning' | 'danger' | 'primary' = 'primary') {
    const toast = await this.toastController.create({ message, duration: 3000, color, position: 'top' });
    await toast.present();
  }

  calculateBarHeight(value: number, maxValue: number): number {
    return (value / maxValue) * 100;
  }

  formatNumber(value: number): string {
    return value.toLocaleString('fr-FR');
  }
}