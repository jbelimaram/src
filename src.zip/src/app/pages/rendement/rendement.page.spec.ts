import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RendementPage } from './rendement.page';

describe('RendementPage', () => {
  let component: RendementPage;
  let fixture: ComponentFixture<RendementPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(RendementPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
