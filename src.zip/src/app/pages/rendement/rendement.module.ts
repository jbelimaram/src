import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage-angular';

import { RendementPageRoutingModule } from './rendement-routing.module';
import { RendementPage } from './rendement.page';
import { SharedModule } from '../../shared/shared.module';

// ===== IMPORT DU CHATBOT MODAL =====
import { ChatbotModalModule } from '../../components/chatbot-modal/chatbot-modal.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RendementPageRoutingModule,
    IonicStorageModule.forRoot(),
    SharedModule,        
    ChatbotModalModule
  ],
  declarations: [RendementPage]  
})
export class RendementPageModule {}