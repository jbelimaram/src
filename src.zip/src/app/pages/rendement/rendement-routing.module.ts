import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RendementPage } from './rendement.page';

const routes: Routes = [
  {
    path: '',
    component: RendementPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RendementPageRoutingModule {}
