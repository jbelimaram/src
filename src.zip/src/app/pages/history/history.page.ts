import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Storage } from '@ionic/storage-angular';
import { TranslationService } from '../../services/translation.service';
import { TranslateService } from '@ngx-translate/core';
import { HistoryService, HistoryEntry } from '../../services/history.service';
import { AuthService } from '../../services/auth.service';
import { OverlayService } from '../../services/overlay.service';
import { firstValueFrom } from 'rxjs';
import { Subscription } from 'rxjs';
import { WeatherService, WeatherData } from '../../services/weather.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-history',
  templateUrl: './history.page.html',
  styleUrls: ['./history.page.scss'],
  standalone: false
})
export class HistoryPage implements OnInit, OnDestroy {
  // ========== LANGUE ET AFFICHAGE ==========
  currentLang: string = 'fr';
  currentYear: number = new Date().getFullYear();
  activeRoute: string = 'history';
  displayName: string = '';
  userEmail: string = '';
  isAdmin: boolean = false;

  // ========== DRAWERS ET NOTIFICATIONS ==========
  navDrawerOpen: boolean = false;
  notificationsPanelOpen: boolean = false;
  notifications: Notification[] = [];
  unreadNotifications: number = 0;

  // ========== MÉTÉO ==========
  weatherData: WeatherData | null = null;
  weatherLoading: boolean = false;
  weatherError: boolean = false;

  // ========== DONNÉES HISTORIQUE ==========
  historyData: HistoryEntry[] = [];
  filteredData: HistoryEntry[] = [];
  paginatedData: HistoryEntry[] = [];
  totalItems: number = 0;

  // ========== FILTRES ET RECHERCHE ==========
  selectedType: string = 'all';
  selectedDate: string = 'all';
  currentPage: number = 1;
  rowsPerPage: number = 10;
  totalPages: number = 0;
  searchQuery: string = '';
  searchInProgress: boolean = false;

  // ========== TRI ==========
  sortColumn: string = 'created_at';
  sortDirection: 'asc' | 'desc' = 'desc';

  // ========== MODALE ==========
  detailsModalOpen: boolean = false;
  selectedItem: HistoryEntry | null = null;

  // ========== CHATBOT ==========
  chatbotOpen: boolean = false;

  // ========== SUBSCRIPTIONS ==========
  private overlaySubscription: Subscription;

  constructor(
    private router: Router,
    private alertController: AlertController,
    private storage: Storage,
    private translationService: TranslationService,
    private translate: TranslateService,
    private cdr: ChangeDetectorRef,
    private historyService: HistoryService,
    private authService: AuthService,
    private weatherService: WeatherService,
    private notificationService: NotificationService,
    private overlayService: OverlayService
  ) {
    this.currentLang = this.translationService.getCurrentLang();
    this.router.events.subscribe(() => {
      this.setActiveRouteFromUrl(this.router.url);
    });
    this.overlaySubscription = this.overlayService.overlayState$.subscribe(state => {
      if (this.navDrawerOpen !== state.navDrawerOpen) {
        this.navDrawerOpen = state.navDrawerOpen;
      }
      if (this.notificationsPanelOpen !== state.notificationsPanelOpen) {
        this.notificationsPanelOpen = state.notificationsPanelOpen;
      }
      if (this.chatbotOpen !== state.chatbotOpen) {
        this.chatbotOpen = state.chatbotOpen;
      }
      this.cdr.detectChanges();
    });
  }

  async ngOnInit() {
    await this.storage.create();
    this.loadUserData();
    this.loadWeather();
    this.loadNotifications();
    this.loadHistory();
    this.setActiveRouteFromUrl(this.router.url);
    document.addEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  ngOnDestroy() {
    document.removeEventListener('keydown', this.handleEscapeKey.bind(this));
    if (this.overlaySubscription) this.overlaySubscription.unsubscribe();
  }

  // ========== GESTION UTILISATEUR ==========
  private loadUserData() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.displayName = user.username || user.name || 'Agriculteur';
      this.userEmail = user.email;
      this.isAdmin = user.role === 'admin';
    }
  }

  // ========== MÉTÉO ==========
  private loadWeather() {
    this.weatherLoading = true;
    this.weatherService.getWeatherFallback().subscribe({
      next: (data) => {
        this.weatherData = data;
        this.weatherLoading = false;
        this.weatherError = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.weatherError = true;
        this.weatherLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  retryWeather() {
    this.loadWeather();
  }

  // ========== NOTIFICATIONS ==========
  private async loadNotifications() {
    try {
      this.notifications = await firstValueFrom(this.notificationService.getNotifications());
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur chargement notifications:', error);
    }
  }

  async markNotificationAsRead(notificationId: string) {
    try {
      await firstValueFrom(this.notificationService.markAsRead(notificationId));
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) notif.read = true;
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  async markAllNotificationsAsRead() {
    try {
      await firstValueFrom(this.notificationService.markAllAsRead());
      this.notifications.forEach(n => n.read = true);
      this.unreadNotifications = 0;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  // ========== DRAWERS ==========
  toggleNavDrawer() { this.overlayService.setNavDrawerOpen(!this.navDrawerOpen); }
  closeNavDrawer() { this.overlayService.setNavDrawerOpen(false); }
  toggleNotificationsPanel() { this.overlayService.setNotificationsPanelOpen(!this.notificationsPanelOpen); }
  closeNotificationsPanel() { this.overlayService.setNotificationsPanelOpen(false); }
  toggleChatbot(): void { this.overlayService.setChatbotOpen(!this.chatbotOpen); }
  onChatbotClose(): void { this.overlayService.setChatbotOpen(false); }

  handleEscapeKey(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      this.overlayService.closeAllOverlays();
    }
  }

  // ========== LANGUE ==========
  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.cdr.detectChanges();
  }

  getCurrentLang(): string {
    return this.currentLang;
  }

  // ========== NAVIGATION ==========
  setActiveRouteFromUrl(url: string) {
    if (url.includes('/dashboard')) this.activeRoute = 'dashboard';
    else if (url.includes('/irrigation')) this.activeRoute = 'irrigation';
    else if (url.includes('/diseases')) this.activeRoute = 'maladies';
    else if (url.includes('/history')) this.activeRoute = 'history';
    else if (url.includes('/rendement')) this.activeRoute = 'rendement';
    else if (url.includes('/forum')) this.activeRoute = 'forum';
  }

  // ========== CHARGEMENT HISTORIQUE ==========
  async loadHistory() {
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser || !currentUser.email) {
      console.error('Utilisateur non connecté');
      return;
    }

    try {
      const response = await firstValueFrom(this.historyService.getHistory(currentUser.email));
      this.historyData = response.entries;
      this.totalItems = response.total;
      this.applyFilters();
    } catch (err) {
      console.error('Erreur chargement historique', err);
      this.showNotification('Erreur lors du chargement de l\'historique', 'error');
    }
  }

  // ========== RECHERCHE ET FILTRES ==========
  performSearch() {
    this.searchInProgress = true;
    this.applyFilters();
    setTimeout(() => {
      this.searchInProgress = false;
    }, 300);
  }

  clearSearch() {
    this.searchQuery = '';
    this.searchInProgress = false;
    this.applyFilters();
  }

  applyFilters() {
    this.filteredData = this.historyData.filter(item => {
      if (this.selectedType !== 'all' && item.operation_type !== this.selectedType) {
        return false;
      }
      if (this.selectedDate !== 'all') {
        const itemDate = item.created_at ? new Date(item.created_at) : new Date();
        const now = new Date();
        if (this.selectedDate === 'today') {
          return itemDate.toDateString() === now.toDateString();
        } else if (this.selectedDate === 'week') {
          const weekStart = new Date(now);
          weekStart.setDate(now.getDate() - now.getDay());
          weekStart.setHours(0, 0, 0, 0);
          const weekEnd = new Date(weekStart);
          weekEnd.setDate(weekStart.getDate() + 6);
          weekEnd.setHours(23, 59, 59, 999);
          return itemDate >= weekStart && itemDate <= weekEnd;
        } else if (this.selectedDate === 'month') {
          return itemDate.getMonth() === now.getMonth() && itemDate.getFullYear() === now.getFullYear();
        }
      }
      return true;
    });

    if (this.searchQuery.trim()) {
      const query = this.searchQuery.toLowerCase();
      this.filteredData = this.filteredData.filter(item => {
        const searchFields = [
          this.translate.instant(this.getTypeText(item.operation_type)).toLowerCase(),
          this.translate.instant(this.getStatusText(item.status)).toLowerCase(),
          this.getDateString(item).toLowerCase(),
          this.formatDetails(item).toLowerCase()
        ];
        return searchFields.some(field => field.includes(query));
      });
    }

    this.sortData(this.sortColumn, this.sortDirection);
    this.currentPage = 1;
    this.updatePagination();
  }

  // ========== PAGINATION ==========
  updatePagination() {
    this.totalPages = Math.ceil(this.filteredData.length / this.rowsPerPage);
    if (this.currentPage > this.totalPages && this.totalPages > 0) {
      this.currentPage = this.totalPages;
    }
    this.renderTable();
  }

  renderTable() {
    const start = (this.currentPage - 1) * this.rowsPerPage;
    const end = start + this.rowsPerPage;
    this.paginatedData = this.filteredData.slice(start, end);
  }

  getStartIndex(): number {
    return (this.currentPage - 1) * this.rowsPerPage + 1;
  }

  getEndIndex(): number {
    return Math.min(this.currentPage * this.rowsPerPage, this.filteredData.length);
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.renderTable();
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.renderTable();
    }
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.renderTable();
    }
  }

  getPageNumbers(): number[] {
    const pages = [];
    const total = this.totalPages;
    const current = this.currentPage;
    if (total <= 5) {
      for (let i = 1; i <= total; i++) pages.push(i);
    } else {
      if (current <= 3) {
        pages.push(1, 2, 3, 4, 5);
      } else if (current >= total - 2) {
        for (let i = total - 4; i <= total; i++) pages.push(i);
      } else {
        for (let i = current - 2; i <= current + 2; i++) pages.push(i);
      }
    }
    return pages;
  }

  // ========== TRI ==========
  sortData(column: string, direction: 'asc' | 'desc') {
    this.sortColumn = column;
    this.sortDirection = direction;
    this.filteredData.sort((a, b) => {
      let valueA: any;
      let valueB: any;
      switch(column) {
        case 'created_at':
          valueA = a.created_at ? new Date(a.created_at).getTime() : 0;
          valueB = b.created_at ? new Date(b.created_at).getTime() : 0;
          break;
        case 'operation_type':
          valueA = this.translate.instant(this.getTypeText(a.operation_type));
          valueB = this.translate.instant(this.getTypeText(b.operation_type));
          break;
        case 'status':
          valueA = this.translate.instant(this.getStatusText(a.status));
          valueB = this.translate.instant(this.getStatusText(b.status));
          break;
        default:
          valueA = a.operation_key;
          valueB = b.operation_key;
      }
      if (valueA < valueB) return direction === 'asc' ? -1 : 1;
      if (valueA > valueB) return direction === 'asc' ? 1 : -1;
      return 0;
    });
    this.renderTable();
  }

  toggleSort(column: string) {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'desc';
    }
    this.sortData(this.sortColumn, this.sortDirection);
  }

  getSortIcon(column: string): string {
    if (this.sortColumn !== column) return 'fa-sort';
    return this.sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down';
  }

  // ========== UTILITAIRES D'AFFICHAGE ==========
  getTypeText(type: string): string {
    const typeMap: { [key: string]: string } = {
      'disease_detection': 'HISTORY.TYPES.DISEASE',
      'yield_prediction': 'HISTORY.TYPES.YIELD',
      'irrigation_decision': 'HISTORY.TYPES.IRRIGATION'
    };
    return typeMap[type] || type;
  }

  getStatusText(status: string): string {
    const statusMap: { [key: string]: string } = {
      'success': 'HISTORY.STATUS.SUCCESS',
      'warning': 'HISTORY.STATUS.WARNING',
      'error': 'HISTORY.STATUS.ERROR',
      'info': 'HISTORY.STATUS.INFO'
    };
    return statusMap[status] || status;
  }

  formatDetails(item: HistoryEntry): string {
    if (item.operation_type === 'disease_detection') {
      return `Maladie: ${item.details.disease} (${item.details.plant}) - Confiance: ${item.details.probability}%`;
    } else if (item.operation_type === 'yield_prediction') {
      return `Rendement: ${this.formatNumber(item.details.yield)} kg/ha - Total: ${this.formatNumber(item.details.totalYield)} kg (${item.details.crop})`;
    } else if (item.operation_type === 'irrigation_decision') {
      return `Décision: ${item.details.decision ? 'Arrosage recommandé' : 'Pas d\'arrosage nécessaire'} (Humidité sol: ${item.details.soil_moisture}%)`;
    }
    return JSON.stringify(item.details);
  }

  getDateString(item: HistoryEntry): string {
    return item.created_at ? new Date(item.created_at).toLocaleString('fr-FR') : '';
  }

  private formatNumber(value: number): string {
    return value.toLocaleString('fr-FR');
  }

  // ========== MODALE DÉTAILS ==========
  openDetailsModal(item: HistoryEntry) {
    this.selectedItem = item;
    this.detailsModalOpen = true;
  }

  closeDetailsModal() {
    this.detailsModalOpen = false;
    this.selectedItem = null;
  }

  // ========== SUPPRESSION ==========
  async confirmDeleteItem(item: HistoryEntry) {
    const alert = await this.alertController.create({
      header: this.translate.instant('HISTORY.DELETE_ITEM.TITLE'),
      message: this.translate.instant('HISTORY.DELETE_ITEM.CONFIRM', { date: this.getDateString(item) }),
      buttons: [
        { text: this.translate.instant('COMMON.CANCEL'), role: 'cancel' },
        { 
          text: this.translate.instant('COMMON.DELETE'),
          handler: () => this.deleteItem(item)
        }
      ]
    });
    await alert.present();
  }

  async deleteItem(item: HistoryEntry) {
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser?.email) return;
    try {
      await firstValueFrom(this.historyService.deleteHistoryEntry(item._id!, currentUser.email));
      await this.loadHistory();
      this.showNotification(this.translate.instant('HISTORY.DELETE_ITEM.SUCCESS'), 'success');
    } catch (error) {
      console.error(error);
      this.showNotification(this.translate.instant('HISTORY.DELETE_ITEM.ERROR'), 'error');
    }
  }

  // ========== SUPPRESSION TOUT ==========
  async confirmClearAll() {
    const alert = await this.alertController.create({
      header: this.translate.instant('HISTORY.DELETE_ALL.TITLE'),
      message: this.translate.instant('HISTORY.DELETE_ALL.CONFIRM', { count: this.filteredData.length }),
      buttons: [
        { text: this.translate.instant('COMMON.CANCEL'), role: 'cancel' },
        { 
          text: this.translate.instant('COMMON.DELETE_ALL'),
          handler: () => this.clearAllHistory()
        }
      ]
    });
    await alert.present();
  }

  async clearAllHistory() {
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser?.email) return;
    try {
      await firstValueFrom(this.historyService.clearAllHistory(currentUser.email));
      await this.loadHistory();
      this.showNotification(this.translate.instant('HISTORY.DELETE_ALL.SUCCESS'), 'success');
    } catch (error) {
      console.error(error);
      this.showNotification(this.translate.instant('HISTORY.DELETE_ALL.ERROR'), 'error');
    }
  }

  // ========== EXPORT ==========
  async exportData() {
    if (this.filteredData.length === 0) {
      const alert = await this.alertController.create({
        header: this.translate.instant('HISTORY.EXPORT.TITLE'),
        message: this.translate.instant('HISTORY.EXPORT.NO_DATA'),
        buttons: [this.translate.instant('COMMON.OK')]
      });
      await alert.present();
      return;
    }

    const headers = [
      this.translate.instant('HISTORY.TABLE.DATE'),
      this.translate.instant('HISTORY.TABLE.TYPE'),
      this.translate.instant('HISTORY.TABLE.OPERATION'),
      this.translate.instant('HISTORY.TABLE.DETAILS'),
      this.translate.instant('HISTORY.TABLE.STATUS')
    ];

    const rows = this.filteredData.map(item => {
      const typeKey = this.getTypeText(item.operation_type);
      let typeText = '';
      const translatedType = this.translate.instant(typeKey);
      typeText = (typeof translatedType === 'string') ? translatedType : typeKey;

      const statusKey = this.getStatusText(item.status);
      let statusText = '';
      const translatedStatus = this.translate.instant(statusKey);
      statusText = (typeof translatedStatus === 'string') ? translatedStatus : statusKey;

      let operationText = '';
      const translatedOp = this.translate.instant(item.operation_key);
      operationText = (typeof translatedOp === 'string') ? translatedOp : item.operation_key;

      return [
        this.getDateString(item),
        typeText,
        operationText,
        this.formatDetails(item),
        statusText
      ];
    });

    const separator = ';';
    const lineBreak = '\r\n';
    const csvLines = [];

    csvLines.push('Rapport historique - AgriTunisie');
    csvLines.push(`Généré le : ${new Date().toLocaleString('fr-FR')}`);
    csvLines.push(`Nombre d'entrées : ${this.filteredData.length}`);
    csvLines.push('');

    csvLines.push(headers.join(separator));

    for (const row of rows) {
      const escapedRow = row.map(cell => {
        const cellStr = String(cell);
        if (cellStr.includes(separator) || cellStr.includes('"')) {
          return `"${cellStr.replace(/"/g, '""')}"`;
        }
        return cellStr;
      });
      csvLines.push(escapedRow.join(separator));
    }

    const csvContent = csvLines.join(lineBreak);
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const fileName = `historique_agritunisie_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.csv`;
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    const successAlert = await this.alertController.create({
      header: this.translate.instant('HISTORY.EXPORT.SUCCESS_TITLE'),
      message: this.translate.instant('HISTORY.EXPORT.SUCCESS_MESSAGE', { count: this.filteredData.length }),
      buttons: [this.translate.instant('COMMON.OK')]
    });
    await successAlert.present();
  }

  // ========== NOTIFICATIONS TOAST ==========
  async showNotification(message: string, type: 'success' | 'error' | 'warning' | 'info' = 'success') {
    const alert = await this.alertController.create({
      header: type === 'error' ? 'Erreur' : type === 'warning' ? 'Attention' : 'Information',
      message: message,
      buttons: ['OK']
    });
    await alert.present();
  }

  // ========== DÉCONNEXION ==========
  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  // ========== GESTION DES ERREURS IMAGES ==========
  onImageError(event: any, name: string) {
    const img = event.target as HTMLImageElement;
    img.src = `https://ui-avatars.com/api/?name=${name}&background=4CAF50&color=fff&size=128`;
  }
}