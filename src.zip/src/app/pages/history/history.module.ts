import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage-angular';

import { HistoryPageRoutingModule } from './history-routing.module';
import { HistoryPage } from './history.page';
import { SharedModule } from '../../shared/shared.module';


// ===== IMPORT DU CHATBOT MODAL =====
import { ChatbotModalModule } from '../../components/chatbot-modal/chatbot-modal.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HistoryPageRoutingModule,
    IonicStorageModule.forRoot(),
    SharedModule,
    ChatbotModalModule
  ],
  declarations: [
    HistoryPage
  ]
})
export class HistoryPageModule {}