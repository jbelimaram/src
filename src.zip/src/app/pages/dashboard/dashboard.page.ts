import { Component, OnInit, OnDestroy, AfterViewInit, ChangeDetectorRef, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { TranslationService } from '../../services/translation.service';
import { WeatherService, WeatherData } from '../../services/weather.service';
import { AuthService } from '../../services/auth.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { OverlayService } from '../../services/overlay.service';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import * as L from 'leaflet';
import { Subscription } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface Parcelle {
  id: string;
  name: string;
  crop: string;
  area: number;
  soilType?: string;
}

export interface FarmData {
  user_email: string;
  name: string;
  size: number;
  region: string;
  parcels: Parcelle[];
  latitude?: number;
  longitude?: number;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
  standalone: false
})
export class DashboardPage implements OnInit, AfterViewInit, OnDestroy {
  // ========== PROPRIÉTÉS ==========
  currentLang: string = 'fr';
  userName: string = '';
  displayName: string = '';
  userEmail: string = '';
  notificationsPanelOpen: boolean = false;
  navDrawerOpen: boolean = false;
  
  // ========== PROPRIÉTÉS ADMIN ==========
  isAdmin: boolean = false;
  
  // ========== DONNÉES DE LA FERME ==========
  farmData: FarmData | null = null;
  selectedParcelle: Parcelle | null = null;
  farmName: string = '';
  farmRegion: string = '';
  farmSize: number = 0;
  
  // Météo
  weatherData: WeatherData | null = null;
  weatherLoading: boolean = false;
  weatherError: boolean = false;
  
  // Métriques
  soilMoisture: number = 0;
  temperature: number = 0;
  airHumidity: number = 0;
  lightIntensity: number = 0;
  lastUpdate: Date = new Date();
  
  // Irrigation IA
  irrigationDecision: boolean = false;
  aiConfidence: number = 0;
  lastDecisionTime: Date = new Date();
  
  // Notifications
  unreadNotifications: number = 0;
  notifications: Notification[] = [];
  
  // Santé des plantes
  diseaseAnalysesCount: number = 0;
  diseasesDetectedCount: number = 0;
  healthyPlantsCount: number = 0;
  totalPlantsCount: number = 0;
  
  // Dates
  lastHarvestDate: Date = new Date();
  currentDate: Date = new Date();

  // ========== CHATBOT ==========
  chatbotOpen: boolean = false;

  // ========== GESTION ERREUR GÉOLOCALISATION ==========
  locationPermissionBlocked: boolean = false;
  locationErrorMessage: string = '';

  // ========== ÉTAT DE CHARGEMENT ==========
  loading: boolean = true;
  farmNotFound: boolean = false;
  sensorsLoading: boolean = false;   // ← NOUVEAU : indicateur de chargement des capteurs

  // ========== CARTE ==========
  private map: L.Map | null = null;
  farmCoordinates: { lat: number; lng: number } | null = null;
  mapLoaded: boolean = false;
  geocodingError: string = '';

  // ========== SUBSCRIPTIONS ==========
  private overlaySubscription: Subscription;
  private weatherInterval: any;
  private pollingInterval: any;
  soilMoistureHistory: number[] = [];
  temperatureHistory: number[] = [];
  airHumidityHistory: number[] = [];

  constructor(
    private router: Router,
    private translationService: TranslationService,
    private weatherService: WeatherService,
    private authService: AuthService,
    private notificationService: NotificationService,
    private overlayService: OverlayService,
    private http: HttpClient,
    private cdr: ChangeDetectorRef,
    private ngZone: NgZone
  ) {
    this.currentLang = this.translationService.getCurrentLang();
    this.overlaySubscription = this.overlayService.overlayState$.subscribe(state => {
      this.ngZone.run(() => {
        if (this.navDrawerOpen !== state.navDrawerOpen) {
          this.navDrawerOpen = state.navDrawerOpen;
        }
        if (this.notificationsPanelOpen !== state.notificationsPanelOpen) {
          this.notificationsPanelOpen = state.notificationsPanelOpen;
        }
        if (this.chatbotOpen !== state.chatbotOpen) {
          this.chatbotOpen = state.chatbotOpen;
        }
        this.cdr.detectChanges();
      });
    });
  }

  ngOnInit(): void {
    this.loadUserData();
    document.addEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  ngAfterViewInit(): void { }

  ngOnDestroy(): void {
    if (this.weatherInterval) clearInterval(this.weatherInterval);
    if (this.pollingInterval) clearInterval(this.pollingInterval);
    if (this.map) this.map.remove();
    document.removeEventListener('keydown', this.handleEscapeKey.bind(this));
    if (this.overlaySubscription) this.overlaySubscription.unsubscribe();
  }

  toggleNavDrawer(): void {
    this.overlayService.setNavDrawerOpen(!this.navDrawerOpen);
  }

  closeNavDrawer(): void {
    this.overlayService.setNavDrawerOpen(false);
  }

  toggleNotificationsPanel(): void {
    this.overlayService.setNotificationsPanelOpen(!this.notificationsPanelOpen);
  }

  closeNotificationsPanel(): void {
    this.overlayService.setNotificationsPanelOpen(false);
  }

  toggleChatbot(): void {
    this.overlayService.setChatbotOpen(!this.chatbotOpen);
  }

  onChatbotClose(): void {
    this.overlayService.setChatbotOpen(false);
  }

  handleEscapeKey(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      this.overlayService.closeAllOverlays();
    }
  }

  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
  }

  private async loadUserData(): Promise<void> {
    this.loading = true;
    try {
      const userData = sessionStorage.getItem('current_user');
      if (!userData) {
        this.router.navigate(['/login']);
        return;
      }
      const user = JSON.parse(userData);
      this.userEmail = user.email;
      
      if (user.name) {
        this.userName = user.name;
        this.displayName = this.cleanName(user.name);
      } else if (user.username) {
        this.userName = user.username;
        this.displayName = this.cleanName(user.username);
      } else if (this.userEmail) {
        const emailParts = this.userEmail.split('@');
        if (emailParts.length > 0) {
          let nameFromEmail = emailParts[0].replace(/[0-9]/g, '');
          nameFromEmail = nameFromEmail.replace(/[._]/g, ' ');
          nameFromEmail = nameFromEmail.replace(/\s+/g, ' ').trim();
          if (nameFromEmail.length > 0) {
            this.displayName = nameFromEmail.split(' ')
              .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
              .join(' ');
          } else {
            this.displayName = 'Agriculteur';
          }
          this.userName = this.displayName;
        }
      } else {
        this.userName = 'Agriculteur';
        this.displayName = 'Agriculteur';
      }

      await this.loadFarmData();
      this.checkAdminStatus(user);
      await this.loadNotifications();
      
    } catch (error) {
      console.error('Erreur lors du chargement des données:', error);
    } finally {
      this.loading = false;
    }
  }

  private async loadFarmData(): Promise<void> {
    try {
      const response = await firstValueFrom(
        this.http.get<FarmData>(`${environment.apiUrl}/farm/${this.userEmail}`)
      );
      
      if (response) {
        if (response.parcels && Array.isArray(response.parcels)) {
          response.parcels = response.parcels.map((p: any) => ({
            ...p,
            id: p._id || p.id,
          }));
        }

        this.farmData = response;
        this.farmName = response.name;
        this.farmRegion = response.region;
        this.farmSize = response.size;
        
        if (response.latitude && response.longitude) {
          this.farmCoordinates = { lat: response.latitude, lng: response.longitude };
        } else {
          const storedCoords = sessionStorage.getItem(`farm_coordinates_${this.userEmail}`);
          if (storedCoords) {
            const coords = JSON.parse(storedCoords);
            this.farmCoordinates = { lat: coords.lat, lng: coords.lng };
            this.geocodingError = '';
          } else {
            await this.geocodeFarmLocation();
          }
        }
        
        this.loadActiveParcelle();
        if (!this.selectedParcelle && response.parcels && response.parcels.length > 0) {
          this.selectedParcelle = response.parcels[0];
          sessionStorage.setItem('active_parcelle', JSON.stringify(this.selectedParcelle));
        }
        
        this.farmNotFound = false;
        this.initSensorData();
        
        if (this.farmCoordinates) {
          this.loadWeatherForFarm(this.farmCoordinates.lat, this.farmCoordinates.lng);
          this.startWeatherUpdates();
        } else if (this.farmRegion) {
          this.loadWeatherByRegion();
          this.startWeatherUpdates();
        } else {
          this.loadWeatherFallback();
        }
        
        setTimeout(() => {
          if (this.farmCoordinates) this.initMapWithRetry();
        }, 100);
      } else {
        this.farmNotFound = true;
      }
    } catch (error) {
      console.error('Erreur chargement ferme:', error);
      this.farmNotFound = true;
    }
  }

  private async geocodeFarmLocation(): Promise<void> {
    if (!this.farmRegion) {
      this.geocodingError = 'Région non définie';
      return;
    }
    const query = `${this.farmRegion}, Tunisie`;
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`;
    try {
      const results = await firstValueFrom(this.http.get<any[]>(url));
      if (results && results.length > 0) {
        this.farmCoordinates = {
          lat: parseFloat(results[0].lat),
          lng: parseFloat(results[0].lon)
        };
        this.geocodingError = '';
      } else {
        this.geocodingError = 'Emplacement non trouvé';
      }
    } catch (error) {
      console.error('Erreur géocodage:', error);
      this.geocodingError = 'Erreur de géocodage';
    }
  }

  private initMapWithRetry(retries = 5, delay = 200): void {
    const mapElement = document.getElementById('farm-map');
    if (mapElement && this.farmCoordinates) {
      this.initMap();
    } else if (retries > 0) {
      setTimeout(() => this.initMapWithRetry(retries - 1, delay), delay);
    }
  }

  private initMap(): void {
    const coords = this.farmCoordinates;
    if (!coords) return;
    setTimeout(() => {
      const mapContainer = document.getElementById('farm-map');
      if (!mapContainer) return;
      if (this.map) this.map.remove();
      this.map = L.map('farm-map').setView([coords.lat, coords.lng], 12);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(this.map);
      L.marker([coords.lat, coords.lng])
        .addTo(this.map)
        .bindPopup(`<b>${this.farmName || 'Ma ferme'}</b><br>${this.farmRegion}`)
        .openPopup();
      this.mapLoaded = true;
    }, 100);
  }

  private loadWeatherForFarm(lat: number, lng: number): void {
    this.weatherLoading = true;
    this.weatherError = false;
    this.weatherService.getWeatherByCoords(lat, lng).subscribe({
      next: (data) => { this.weatherData = data; this.weatherLoading = false; },
      error: () => { this.weatherError = true; this.weatherLoading = false; this.loadWeatherFallback(); }
    });
  }

  private loadWeatherByRegion(): void {
    if (this.farmRegion) {
      this.weatherLoading = true;
      this.weatherService.getWeatherByCity(this.farmRegion).subscribe({
        next: (data) => { this.weatherData = data; this.weatherLoading = false; },
        error: () => { this.weatherError = true; this.weatherLoading = false; this.loadWeatherFallback(); }
      });
    } else {
      this.loadWeatherFallback();
    }
  }

  private loadWeatherFallback(): void {
    this.weatherLoading = true;
    this.weatherService.getWeatherFallback().subscribe({
      next: (data) => { this.weatherData = data; this.weatherLoading = false; this.weatherError = false; },
      error: () => { this.weatherError = true; this.weatherLoading = false; }
    });
  }

  private startWeatherUpdates(): void {
    if (this.weatherInterval) clearInterval(this.weatherInterval);
    this.weatherInterval = setInterval(() => {
      if (this.farmCoordinates) this.loadWeatherForFarm(this.farmCoordinates.lat, this.farmCoordinates.lng);
      else if (this.farmRegion) this.loadWeatherByRegion();
      else this.loadWeatherFallback();
    }, 600000);
  }

  retryWeather(): void {
    if (this.farmCoordinates) this.loadWeatherForFarm(this.farmCoordinates.lat, this.farmCoordinates.lng);
    else if (this.farmRegion) this.loadWeatherByRegion();
    else this.loadWeatherFallback();
  }

  private loadActiveParcelle(): void {
    const savedParcelle = sessionStorage.getItem('active_parcelle');
    if (savedParcelle && this.farmData) {
      const parsed = JSON.parse(savedParcelle);
      const exists = this.farmData.parcels?.some(p => p.id === parsed.id);
      if (exists) this.selectedParcelle = parsed;
      else if (this.farmData.parcels?.length) this.selectedParcelle = this.farmData.parcels[0];
    } else if (this.farmData?.parcels?.length) {
      this.selectedParcelle = this.farmData.parcels[0];
    }
  }

  private checkAdminStatus(user: any): void {
    this.isAdmin = user.email === 'admin@example.com' || user.role === 'admin';
  }

  private initSensorData(): void {
    this.loadLatestSensorData();
    this.loadHistoricalData();
    this.startPolling();
  }

  private async loadLatestSensorData(): Promise<void> {
    if (!this.userEmail) return;
    const parcelleId = this.selectedParcelle?.id;
    let url = `${environment.apiUrl}/api/sensors/latest/${this.userEmail}`;
    if (parcelleId) url += `?parcelle_id=${parcelleId}`;

    try {
      const data = await firstValueFrom(this.http.get<any>(url));
      if (data.message === "No data") return;

      this.ngZone.run(() => {
        this.soilMoisture = data.soil_moisture;
        this.temperature = data.temperature;
        this.airHumidity = data.air_humidity;
        this.lightIntensity = data.light_intensity || 0;
        this.irrigationDecision = data.irrigation_decision;

        if (data.ai_confidence !== undefined && data.ai_confidence !== null) {
          this.aiConfidence = data.ai_confidence;
        } else {
          const diffFromOptimal = Math.abs(data.soil_moisture - 50);
          this.aiConfidence = Math.max(0, Math.min(100, 100 - diffFromOptimal));
        }

        this.lastDecisionTime = data.timestamp ? new Date(data.timestamp) : new Date();

        this.soilMoistureHistory.push(data.soil_moisture);
        this.temperatureHistory.push(data.temperature);
        this.airHumidityHistory.push(data.air_humidity);
        if (this.soilMoistureHistory.length > 24) {
          this.soilMoistureHistory.shift();
          this.temperatureHistory.shift();
          this.airHumidityHistory.shift();
        }

        this.cdr.detectChanges();
      });
    } catch (error) {
      console.error("Erreur chargement capteur", error);
    }
  }

  private async loadHistoricalData(): Promise<void> {
    if (!this.userEmail) return;
    const parcelleId = this.selectedParcelle?.id;
    let url = `${environment.apiUrl}/api/sensors/history/${this.userEmail}`;
    if (parcelleId) url += `?parcelle_id=${parcelleId}`;

    try {
      const response = await firstValueFrom(this.http.get<any[]>(url));
      this.ngZone.run(() => {
        if (response && response.length) {
          const sorted = response.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
          const last24 = sorted.slice(-24);
          this.soilMoistureHistory = last24.map(d => d.soil_moisture);
          this.temperatureHistory = last24.map(d => d.temperature);
          this.airHumidityHistory = last24.map(d => d.air_humidity);
        } else {
          this.soilMoistureHistory = [];
          this.temperatureHistory = [];
          this.airHumidityHistory = [];
        }
        this.cdr.detectChanges();
      });
    } catch (error) {
      console.error('Erreur historique', error);
    }
  }

  private startPolling(): void {
    if (this.pollingInterval) clearInterval(this.pollingInterval);
    this.pollingInterval = setInterval(() => {
      this.loadLatestSensorData();
    }, 30000);
  }

  private cleanName(name: string): string {
    return name.replace(/[0-9]/g, '');
  }

  // ========== NOTIFICATIONS ==========
  private async loadNotifications(): Promise<void> {
    const token = this.authService.getToken();
    if (!token) return;
    try {
      this.notifications = await firstValueFrom(this.notificationService.getNotifications());
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur chargement notifications:', error);
    }
  }

  async markNotificationAsRead(notificationId: string): Promise<void> {
    try {
      await firstValueFrom(this.notificationService.markAsRead(notificationId));
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) notif.read = true;
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  async markAllNotificationsAsRead(): Promise<void> {
    try {
      await firstValueFrom(this.notificationService.markAllAsRead());
      this.notifications.forEach(n => n.read = true);
      this.unreadNotifications = 0;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  // ========== MÉTHODES D'AFFICHAGE ==========
  getIrrigationIcon(): string {
    return this.irrigationDecision ? 'fas fa-toggle-on' : 'fas fa-toggle-off';
  }

  get hasMultipleParcelles(): boolean {
    return this.farmData?.parcels ? this.farmData.parcels.length > 1 : false;
  }

  getTranslatedSoilType(soilType: string): string {
    const types: any = { clay: 'Argileux', sandy: 'Sableux', loamy: 'Limoneux', silty: 'Limoneux fin', peaty: 'Tourbeux', chalky: 'Calcaire', rocky: 'Rocheux' };
    return types[soilType] || soilType;
  }

  getIrrigationStateText(): string {
    return this.irrigationDecision ? 'Arrosage recommandé' : 'Pas d\'arrosage nécessaire';
  }

  getDecisionExplanation(): string {
    const crop = this.selectedParcelle?.crop || 'vos cultures';
    const moisture = this.soilMoisture;
    const confidence = this.aiConfidence;
    if (this.irrigationDecision) {
      return `L'IA recommande l'arrosage avec ${confidence}% de confiance. L'humidité du sol est de ${moisture}%, ce qui est insuffisant pour ${crop}.`;
    } else {
      return `L'IA ne recommande pas l'arrosage (confiance ${confidence}%). L'humidité du sol (${moisture}%) est suffisante pour ${crop}.`;
    }
  }

  getMoistureStatus(): string {
    if (this.soilMoisture < 30) return 'warning';
    if (this.soilMoisture < 50) return 'medium';
    if (this.soilMoisture < 70) return 'good';
    return 'excellent';
  }

  getTemperatureStatus(): string {
    if (this.temperature < 5) return 'freezing';
    if (this.temperature < 15) return 'cold';
    if (this.temperature < 25) return 'moderate';
    if (this.temperature < 35) return 'warm';
    return 'hot';
  }

  // ========== LUMINOSITÉ ==========
  getLightStatus(): string {
    if (this.lightIntensity < 500) return 'low-light';
    if (this.lightIntensity < 2000) return 'medium-light';
    if (this.lightIntensity < 5000) return 'good-light';
    return 'high-light';
  }

  getLightStatusText(): string {
    const map: any = {
      'low-light': 'Faible luminosité',
      'medium-light': 'Luminosité modérée',
      'good-light': 'Luminosité optimale',
      'high-light': 'Luminosité élevée'
    };
    return map[this.getLightStatus()] || '';
  }

  // ========== CHANGEMENT DE PARCELLE (MODIFIÉ) ==========
  async changeParcelle(parcelle: Parcelle): Promise<void> {
    if (this.selectedParcelle?.id === parcelle.id) return;
    
    // Afficher l'indicateur de chargement
    this.sensorsLoading = true;
    
    // Réinitialiser les valeurs affichées (optionnel)
    this.soilMoisture = 0;
    this.temperature = 0;
    this.airHumidity = 0;
    this.lightIntensity = 0;
    this.irrigationDecision = false;
    this.aiConfidence = 0;
    
    this.selectedParcelle = parcelle;
    sessionStorage.setItem('active_parcelle', JSON.stringify(parcelle));
    
    try {
      // Charger les nouvelles données
      await this.loadLatestSensorData();
      await this.loadHistoricalData();
    } catch (error) {
      console.error('Erreur lors du changement de parcelle', error);
    } finally {
      this.sensorsLoading = false;
      this.closeNavDrawer();
      this.cdr.detectChanges();
    }
  }

  // ========== NAVIGATION ==========
  goToIrrigation(): void { this.router.navigate(['/irrigation']); }
  goToDiseases(): void { this.router.navigate(['/diseases']); }
  goToRendement(): void { this.router.navigate(['/rendement']); }
  viewAllAlerts(): void { this.router.navigate(['/alerts']); }
  goToFarmSetup(): void { this.router.navigate(['/farm-setup']); }
  logout(): void { this.authService.logout(); }
}