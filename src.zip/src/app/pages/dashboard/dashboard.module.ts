import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

import { DashboardPage } from './dashboard.page';
import { DashboardPageRoutingModule } from './dashboard-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { ChatbotModalModule } from '../../components/chatbot-modal/chatbot-modal.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule,
    TranslateModule,
    DashboardPageRoutingModule,
    SharedModule,
    ChatbotModalModule,
    TranslateModule
  ],
  declarations: [DashboardPage],
  providers: [DatePipe]
})
export class DashboardPageModule {}