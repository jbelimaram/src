import { Component, OnInit, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastController, LoadingController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { TranslationService } from '../../services/translation.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.page.html',
  styleUrls: ['./reset-password.page.scss'],
  standalone: false
})
export class ResetPasswordPage implements OnInit {
  resetForm: FormGroup;
  token: string = '';
  tokenValid: boolean = true;
  isLoading = false;
  showPassword = false;
  showConfirmPassword = false;
  currentLang: string = 'fr';

  passwordCriteria = {
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    special: false
  };

  private apiUrl = environment.apiUrl;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private toastController: ToastController,
    private loadingController: LoadingController,
    private translate: TranslateService,
    private translationService: TranslationService,
    private cdr: ChangeDetectorRef,
    private renderer: Renderer2
  ) {
    this.resetForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });
    
    this.currentLang = this.translationService.getCurrentLang();
    this.translate.use(this.currentLang);
    this.setDocumentDirection(this.currentLang);
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.token = params['token'];
      if (!this.token) {
        this.tokenValid = false;
        return;
      }

      // Verify token with backend
      this.http.get(`${this.apiUrl}/verify-reset-token`, { params: { token: this.token } })
        .subscribe({
          next: () => {
            this.tokenValid = true;
            // Only start listening to password changes after token is confirmed valid
            this.resetForm.get('newPassword')?.valueChanges.subscribe(value => {
              this.checkPasswordCriteria(value || '');
            });
          },
          error: (err) => {
            console.error('Token verification failed', err);
            this.tokenValid = false;
          }
        });
    });
  }

  private setDocumentDirection(lang: string): void {
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    this.renderer.setAttribute(document.documentElement, 'dir', dir);
    this.renderer.setAttribute(document.documentElement, 'lang', lang);
  }

  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.setDocumentDirection(lang);
    this.cdr.detectChanges();
  }

  handleImageError(event: any): void {
    const img = event.target as HTMLImageElement;
    img.src = 'assets/photos/logo-default.png';
  }

  getCurrentLang(): string {
    return this.currentLang;
  }

  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('newPassword')?.value;
    const confirm = control.get('confirmPassword')?.value;
    if (password && confirm && password !== confirm) {
      return { passwordMismatch: true };
    }
    return null;
  }

  get newPassword() { return this.resetForm.get('newPassword')!; }
  get confirmPassword() { return this.resetForm.get('confirmPassword')!; }

  togglePassword() { this.showPassword = !this.showPassword; }
  toggleConfirmPassword() { this.showConfirmPassword = !this.showConfirmPassword; }

  checkPasswordCriteria(password: string): void {
    this.passwordCriteria = {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[^A-Za-z0-9]/.test(password)
    };
  }

  onPasswordChange(): void {
    const password = this.resetForm.get('newPassword')?.value || '';
    this.checkPasswordCriteria(password);
  }

  async onSubmit() {
    if (this.resetForm.invalid) return;

    this.isLoading = true;
    const loading = await this.loadingController.create({
      message: this.translate.instant('RESET_PASSWORD.UPDATING')
    });
    await loading.present();

    try {
      await firstValueFrom(
        this.http.post(`${this.apiUrl}/reset-password/confirm`, {
          token: this.token,
          new_password: this.newPassword.value
        })
      );

      await loading.dismiss();
      const toast = await this.toastController.create({
        message: this.translate.instant('RESET_PASSWORD.SUCCESS'),
        duration: 3000,
        color: 'success',
        position: 'top'
      });
      await toast.present();
      this.router.navigate(['/accueil']);

    } catch (error: any) {
      console.error('Erreur reset:', error);
      await loading.dismiss();
      const message = error.error?.detail || this.translate.instant('RESET_PASSWORD.ERROR');
      const toast = await this.toastController.create({
        message,
        duration: 3000,
        color: 'danger',
        position: 'top'
      });
      await toast.present();

      if (error.status === 400) {
        this.tokenValid = false;
      }
    } finally {
      this.isLoading = false;
    }
  }
}