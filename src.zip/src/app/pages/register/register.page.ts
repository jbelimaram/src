import { Component, OnInit, ChangeDetectorRef, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors, AsyncValidatorFn } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AuthService } from '../../services/auth.service';
import { TranslationService } from '../../services/translation.service';
import { TranslateService } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
  standalone: false
})
export class RegisterPage implements OnInit {
  registerForm: FormGroup;
  
  showPassword = false;
  showConfirmPassword = false;
  isLoading = false;
  
  currentLang: string = 'fr';
  
  passwordCriteria = {
    length: false,
    uppercase: false,
    lowercase: false,
    number: false,
    special: false
  };

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private alertController: AlertController,
    private translationService: TranslationService,
    private translate: TranslateService,
    private cdr: ChangeDetectorRef,
    private renderer: Renderer2
  ) {
    this.registerForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', {
        validators: [
          Validators.required, 
          Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(com|fr|tn|net|org|edu|gov|info|io|co|ma|dz|ly|uk|us|ca|de|es|it|nl|be|ch|at|lu|ru|cn|jp|kr|in|br|au|za){1}$/i)
        ],
        asyncValidators: [this.emailAvailabilityValidator()],
        updateOn: 'blur'
      }],
      phone: ['', [Validators.required, Validators.pattern('^[0-9]{8}$')]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]],
      terms: [false, [Validators.requiredTrue]]
    }, { validators: this.passwordMatchValidator });
    
    this.currentLang = this.translationService.getCurrentLang();
    this.translate.use(this.currentLang);
    
    this.setDocumentDirection(this.currentLang);
  }

  ngOnInit() {
    this.registerForm.get('password')?.valueChanges.subscribe(value => {
      this.checkPasswordCriteria(value || '');
    });
  }

  private setDocumentDirection(lang: string): void {
    const dir = lang === 'ar' ? 'rtl' : 'ltr';
    this.renderer.setAttribute(document.documentElement, 'dir', dir);
    this.renderer.setAttribute(document.documentElement, 'lang', lang);
  }

  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.setDocumentDirection(lang);
    this.cdr.detectChanges();
  }

  getCurrentLang(): string {
    return this.currentLang;
  }

  passwordMatchValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.get('password')?.value;
    const confirmPassword = control.get('confirmPassword')?.value;
    if (password && confirmPassword && password !== confirmPassword) {
      return { passwordMismatch: true };
    }
    return null;
  }

  emailAvailabilityValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      if (!control.value || control.value.length < 3) {
        return of(null);
      }
      control.setErrors({ checking: true });
      return this.authService.checkEmail(control.value).pipe(
        map(response => {
          if (!response.available) {
            return { emailTaken: true };
          }
          return null;
        }),
        catchError(() => of(null))
      );
    };
  }

  // Getters...
  get firstNameInvalid(): boolean {
    const control = this.registerForm.get('firstName');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }
  get firstNameError(): string {
    const control = this.registerForm.get('firstName');
    if (control?.errors?.['required']) return this.translate.instant('REGISTER.ERRORS.FIRST_NAME_REQUIRED');
    if (control?.errors?.['minlength']) return this.translate.instant('REGISTER.ERRORS.FIRST_NAME_MINLENGTH');
    return '';
  }
  get lastNameInvalid(): boolean {
    const control = this.registerForm.get('lastName');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }
  get lastNameError(): string {
    const control = this.registerForm.get('lastName');
    if (control?.errors?.['required']) return this.translate.instant('REGISTER.ERRORS.LAST_NAME_REQUIRED');
    if (control?.errors?.['minlength']) return this.translate.instant('REGISTER.ERRORS.LAST_NAME_MINLENGTH');
    return '';
  }
  get emailInvalid(): boolean {
    const control = this.registerForm.get('email');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }
  get emailError(): string {
    const control = this.registerForm.get('email');
    if (control?.errors?.['required']) return this.translate.instant('REGISTER.ERRORS.EMAIL_REQUIRED');
    if (control?.errors?.['pattern']) return this.translate.instant('REGISTER.ERRORS.EMAIL_INVALID');
    if (control?.errors?.['emailTaken']) return this.translate.instant('REGISTER.ERRORS.EMAIL_ALREADY_USED');
    if (control?.errors?.['checking']) return this.translate.instant('REGISTER.ERRORS.CHECKING_EMAIL');
    return '';
  }
  get phoneInvalid(): boolean {
    const control = this.registerForm.get('phone');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }
  get phoneError(): string {
    const control = this.registerForm.get('phone');
    if (control?.errors?.['required']) return this.translate.instant('REGISTER.ERRORS.PHONE_REQUIRED');
    if (control?.errors?.['pattern']) return this.translate.instant('REGISTER.ERRORS.PHONE_INVALID');
    return '';
  }
  get passwordInvalid(): boolean {
    const control = this.registerForm.get('password');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }
  get passwordError(): string {
    const control = this.registerForm.get('password');
    if (control?.errors?.['required']) return this.translate.instant('REGISTER.ERRORS.PASSWORD_REQUIRED');
    if (control?.errors?.['minlength']) return this.translate.instant('REGISTER.ERRORS.PASSWORD_MINLENGTH');
    return '';
  }
  get confirmPasswordInvalid(): boolean {
    const control = this.registerForm.get('confirmPassword');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }
  get confirmPasswordError(): string {
    const control = this.registerForm.get('confirmPassword');
    if (control?.errors?.['required']) return this.translate.instant('REGISTER.ERRORS.CONFIRM_PASSWORD_REQUIRED');
    if (this.registerForm.errors?.['passwordMismatch']) {
      return this.translate.instant('REGISTER.ERRORS.PASSWORD_MISMATCH');
    }
    return '';
  }
  get termsInvalid(): boolean {
    const control = this.registerForm.get('terms');
    return !!(control?.invalid && (control?.dirty || control?.touched));
  }
  get termsError(): string {
    const control = this.registerForm.get('terms');
    if (control?.errors?.['required']) return this.translate.instant('REGISTER.ERRORS.TERMS_REQUIRED');
    return '';
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }
  toggleConfirmPassword(): void {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  checkPasswordCriteria(password: string): void {
    this.passwordCriteria = {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[^A-Za-z0-9]/.test(password)
    };
  }

  onPasswordChange(): void {
    const password = this.registerForm.get('password')?.value || '';
    this.checkPasswordCriteria(password);
  }

  async onSubmit(): Promise<void> {
    if (this.registerForm.invalid) {
      this.markFormGroupTouched(this.registerForm);
      return;
    }
    const formValues = this.registerForm.value;
    this.isLoading = true;

    try {
      const emailCheck = await firstValueFrom(this.authService.checkEmail(formValues.email));
      if (!emailCheck?.available) {
        await this.showAlert(
          this.translate.instant('REGISTER.ERRORS.EMAIL_ALREADY_USED'),
          this.translate.instant('REGISTER.ERRORS.EMAIL_ALREADY_USED_DESC')
        );
        this.isLoading = false;
        return;
      }
      const registrationData = {
        firstName: formValues.firstName,
        lastName: formValues.lastName,
        email: formValues.email,
        phone: formValues.phone,
        password: formValues.password
      };
      sessionStorage.setItem('temp_registration', JSON.stringify(registrationData));
      sessionStorage.setItem('registration_email', registrationData.email);
      this.router.navigate(['/farm-setup']);
    } catch (error) {
      console.error(error);
      await this.showAlert(this.translate.instant('COMMON.ERROR'), this.translate.instant('REGISTER.ERRORS.GENERIC'));
    } finally {
      this.isLoading = false;
    }
  }

  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) this.markFormGroupTouched(control);
    });
  }

  private async showAlert(header: string, message: string): Promise<void> {
    const alert = await this.alertController.create({
      header,
      message,
      buttons: [this.translate.instant('COMMON.OK')]
    });
    await alert.present();
  }

  handleImageError(event: any): void {
    const img = event.target as HTMLImageElement;
    img.src = 'assets/photos/logo-default.png';
  }

  async openTerms(event: Event): Promise<void> {
    event.preventDefault();
    event.stopPropagation();

    const alert = await this.alertController.create({
      header: 'Conditions Générales d\'Utilisation',
      message: `
        <div style="text-align: left; line-height: 1.5;">
          <h3>1. Acceptation des conditions</h3>
          <p>En créant un compte sur AgriTunisie, vous acceptez pleinement et sans réserve les présentes conditions générales d'utilisation.</p>
          
          <h3>2. Description du service</h3>
          <p>AgriTunisie fournit des outils d'aide à la décision pour l'agriculture intelligente en Tunisie, incluant :</p>
          <ul>
            <li>Suivi d'irrigation et recommandations basées sur l'IA</li>
            <li>Détection des maladies des cultures</li>
            <li>Prédictions de rendement</li>
            <li>Forum d'échange entre agriculteurs</li>
            <li>Données météorologiques en temps réel</li>
          </ul>
          
          <h3>3. Responsabilité</h3>
          <p>Vous êtes responsable de la confidentialité de votre compte et de toutes les activités qui s'y déroulent. AgriTunisie fournit des recommandations à titre indicatif, vous restez seul responsable de vos décisions agricoles.</p>
          
          <h3>4. Données agricoles</h3>
          <p>Vos données agricoles sont utilisées uniquement pour :</p>
          <ul>
            <li>Personnaliser nos recommandations</li>
            <li>Améliorer nos algorithmes d'IA</li>
            <li>Fournir des prédictions plus précises</li>
          </ul>
          <p>Ces données sont anonymisées et ne sont jamais partagées avec des tiers sans votre consentement explicite.</p>
          
          <h3>5. Propriété intellectuelle</h3>
          <p>Tous les contenus, logos, et fonctionnalités d'AgriTunisie sont protégés par les droits d'auteur et restent la propriété exclusive d'AgriTunisie.</p>
          
          <h3>6. Modification des conditions</h3>
          <p>Nous nous réservons le droit de modifier ces conditions à tout moment. Les modifications entrent en vigueur dès leur publication sur la plateforme.</p>
          
          <p><strong>Contact :</strong> support@agritunisie.tn | +216 XX XXX XXX</p>
        </div>
      `,
      buttons: ['Fermer'],
      cssClass: 'terms-alert'
    });
    await alert.present();
  }

  async openPrivacy(event: Event): Promise<void> {
    event.preventDefault();
    event.stopPropagation();

    const alert = await this.alertController.create({
      header: 'Politique de Confidentialité',
      message: `
        <div style="text-align: left; line-height: 1.5;">
          <h3>🔒 Notre engagement</h3>
          <p>AgriTunisie respecte votre vie privée et s'engage à protéger vos données personnelles.</p>
          
          <h3>1. Données collectées</h3>
          <p><strong>Données personnelles :</strong> Nom, prénom, email, téléphone, adresse de la ferme (optionnel)</p>
          <p><strong>Données agricoles :</strong> Informations sur vos parcelles, types de cultures, données d'irrigation, historique des rendements</p>
          
          <h3>2. Utilisation des données</h3>
          <p>Vos données sont utilisées pour :</p>
          <ul>
            <li>Fournir des recommandations personnalisées d'irrigation</li>
            <li>Détecter les maladies des cultures</li>
            <li>Prédire les rendements</li>
            <li>Améliorer nos algorithmes d'intelligence artificielle</li>
          </ul>
          
          <h3>3. Protection des données</h3>
          <p>Nous mettons en œuvre des mesures de sécurité avancées :</p>
          <ul>
            <li>Chiffrement SSL/TLS pour toutes les communications</li>
            <li>Base de données chiffrée avec accès restreint</li>
            <li>Authentification sécurisée avec JWT</li>
          </ul>
          
          <h3>4. Vos droits</h3>
          <p>Conformément à la loi tunisienne, vous disposez des droits suivants :</p>
          <ul>
            <li>Droit d'accès à vos données</li>
            <li>Droit de rectification des données inexactes</li>
            <li>Droit à l'effacement de vos données</li>
            <li>Droit à la portabilité des données</li>
          </ul>
          
          <h3>5. Conservation des données</h3>
          <p>Vos données sont conservées aussi longtemps que votre compte est actif. En cas de suppression du compte, vos données sont anonymisées après 30 jours.</p>
          
          <p><strong>Contact :</strong> privacy@agritunisie.tn</p>
        </div>
      `,
      buttons: ['Fermer'],
      cssClass: 'privacy-alert'
    });
    await alert.present();
  }
}