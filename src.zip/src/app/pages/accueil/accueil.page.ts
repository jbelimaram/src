// src/app/pages/accueil/accueil.page.ts
import { Component, HostListener } from '@angular/core';
import { TranslationService } from '../../services/translation.service';

@Component({
  selector: 'app-accueil',
  templateUrl: './accueil.page.html',
  styleUrls: ['./accueil.page.scss'],
  standalone: false
})
export class AccueilPage {
  currentLang: string = 'fr';
  mobileMenuOpen: boolean = false;

  constructor(
    private translationService: TranslationService
  ) {
    this.currentLang = this.translationService.getCurrentLang();
    console.log('✅ Page Accueil chargée, langue:', this.currentLang);
  }

  changeLanguage(lang: string) {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
  }

  getCurrentLang(): string {
    return this.currentLang;
  }

  toggleMobileMenu() {
    this.mobileMenuOpen = !this.mobileMenuOpen;
  }

  closeMobileMenu() {
    this.mobileMenuOpen = false;
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (!target.closest('.mobile-menu-btn') && !target.closest('.mobile-menu')) {
      this.mobileMenuOpen = false;
    }
  }
}