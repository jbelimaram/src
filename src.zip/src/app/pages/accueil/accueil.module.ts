import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { SharedModule } from '../../shared/shared.module';
import { AccueilPage } from './accueil.page';
import { AccueilPageRoutingModule } from './accueil-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AccueilPageRoutingModule,
    SharedModule
  ],
  declarations: [AccueilPage],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AccueilPageModule {}