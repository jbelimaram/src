import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ToastController, AlertController } from '@ionic/angular';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { TranslationService } from '../../services/translation.service';
import { TranslateService } from '@ngx-translate/core';
import { ForumService, Topic, Reply } from '../../services/forum.service';
import { AuthService } from '../../services/auth.service';
import { WeatherService, WeatherData } from '../../services/weather.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-forum',
  templateUrl: './forum.page.html',
  styleUrls: ['./forum.page.scss'],
  standalone: false
})
export class ForumPage implements OnInit {
  // ========== LANGUE ET AFFICHAGE ==========
  currentLang: string = 'fr';
  currentYear: number = new Date().getFullYear();
  activeRoute: string = 'forum';
  displayName: string = '';
  userEmail: string = '';
  isAdmin: boolean = false;

  // ========== DRAWERS ET NOTIFICATIONS ==========
  navDrawerOpen: boolean = false;
  notificationsPanelOpen: boolean = false;
  notifications: Notification[] = [];
  unreadNotifications: number = 0;

  // ========== MÉTÉO ==========
  weatherData: WeatherData | null = null;
  weatherLoading: boolean = false;
  weatherError: boolean = false;

  // ========== CHATBOT ==========
  chatbotOpen: boolean = false;

  // ========== FORUM ==========
  searchTerm = '';
  currentCategory = 'all';
  currentSort = 'recent';
  currentPageNum = 1;
  itemsPerPage = 5;
  totalPages = 1;
  
  // New topic modal
  showTopicModal = false;
  newTopic = {
    title: '',
    category: '' as 'irrigation' | 'diseases' | 'yield' | '',
    content: ''
  };
  selectedImages: File[] = [];
  imagePreviews: string[] = [];
  uploadingImages = false;

  // Topic detail modal
  showTopicDetailModal = false;
  selectedTopic: Topic | null = null;
  topicReplies: Reply[] = [];
  newReplyContent = '';
  replyImages: File[] = [];
  replyImagePreviews: string[] = [];
  uploadingReplyImages = false;

  // Image modal
  selectedImageUrl: string | null = null;
  selectedImageCaption: string | null = null;

  // Data
  allTopics: Topic[] = [];
  filteredTopics: Topic[] = [];
  paginatedTopics: Topic[] = [];

  userTopics: Topic[] = [];
  showUserTopics = false;

  // Current user info
  currentUserName: string | null = null;
  currentUserEmail: string | null = null;

  constructor(
    private toastController: ToastController,
    private alertController: AlertController,
    private router: Router,
    private translationService: TranslationService,
    private translate: TranslateService,
    private cdr: ChangeDetectorRef,
    private forumService: ForumService,
    private authService: AuthService,
    private weatherService: WeatherService,
    private notificationService: NotificationService
  ) {
    this.currentLang = this.translationService.getCurrentLang();
    
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      const url = event.urlAfterRedirects || event.url;
      this.setActiveRouteFromUrl(url);
    });
  }

  ngOnInit() {
    this.loadUserData();
    this.loadWeather();
    this.loadNotifications();
    this.loadCurrentUser();
    this.loadTopics();
    this.setActiveRouteFromUrl(this.router.url);
    document.addEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  ngOnDestroy() {
    document.removeEventListener('keydown', this.handleEscapeKey.bind(this));
  }

  // ========== GESTION UTILISATEUR ==========
  private loadUserData() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.displayName = user.username || user.name || 'Agriculteur';
      this.userEmail = user.email;
      this.isAdmin = user.role === 'admin';
    }
  }

  loadCurrentUser() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.currentUserName = user.name;
      this.currentUserEmail = user.email;
    }
  }

  isCurrentUserAuthor(topic: Topic | null): boolean {
    if (!topic || !this.currentUserEmail) return false;
    return topic.author_email === this.currentUserEmail;
  }

  // ========== MÉTÉO ==========
  private loadWeather() {
    this.weatherLoading = true;
    this.weatherService.getWeatherFallback().subscribe({
      next: (data) => {
        this.weatherData = data;
        this.weatherLoading = false;
        this.weatherError = false;
        this.cdr.detectChanges();
      },
      error: () => {
        this.weatherError = true;
        this.weatherLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  retryWeather() {
    this.loadWeather();
  }

  // ========== NOTIFICATIONS ==========
  private async loadNotifications() {
    try {
      this.notifications = await firstValueFrom(this.notificationService.getNotifications());
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur chargement notifications:', error);
    }
  }

  async markNotificationAsRead(notificationId: string) {
    try {
      await firstValueFrom(this.notificationService.markAsRead(notificationId));
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) notif.read = true;
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  async markAllNotificationsAsRead() {
    try {
      await firstValueFrom(this.notificationService.markAllAsRead());
      this.notifications.forEach(n => n.read = true);
      this.unreadNotifications = 0;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Erreur:', error);
    }
  }

  // ========== DRAWERS ==========
  toggleNavDrawer() {
    this.navDrawerOpen = !this.navDrawerOpen;
  }

  closeNavDrawer() {
    this.navDrawerOpen = false;
  }

  toggleNotificationsPanel() {
    this.notificationsPanelOpen = !this.notificationsPanelOpen;
  }

  closeNotificationsPanel() {
    this.notificationsPanelOpen = false;
  }

  handleEscapeKey(event: KeyboardEvent): void {
    if (event.key === 'Escape') {
      if (this.navDrawerOpen) this.closeNavDrawer();
      if (this.notificationsPanelOpen) this.closeNotificationsPanel();
    }
  }

  // ========== LANGUE ==========
  changeLanguage(lang: string): void {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.cdr.detectChanges();
  }

  getCurrentLang(): string {
    return this.currentLang;
  }

  // ========== CHATBOT ==========
  toggleChatbot(): void {
    this.chatbotOpen = !this.chatbotOpen;
  }

  onChatbotClose(): void {
    this.chatbotOpen = false;
  }

  // ========== NAVIGATION ==========
  setActiveRouteFromUrl(url: string) {
    if (url.includes('/dashboard')) this.activeRoute = 'dashboard';
    else if (url.includes('/irrigation')) this.activeRoute = 'irrigation';
    else if (url.includes('/diseases')) this.activeRoute = 'maladies';
    else if (url.includes('/forum')) this.activeRoute = 'forum';
    else if (url.includes('/history')) this.activeRoute = 'history';
    else if (url.includes('/rendement')) this.activeRoute = 'rendement';
  }

  // ========== FORUM ==========
  async loadTopics() {
    try {
      const topics = await firstValueFrom(this.forumService.getTopics(this.currentCategory, this.currentSort));
      this.allTopics = topics;
      this.filterTopics();
    } catch (error) {
      console.error('Erreur chargement sujets:', error);
      this.showNotification('FORUM.NOTIFICATIONS.LOAD_ERROR', 'error');
    }
  }

  async loadMyTopics() {
    try {
      const topics = await firstValueFrom(this.forumService.getMyTopics());
      this.userTopics = topics;
    } catch (error) {
      console.error('Erreur chargement mes sujets:', error);
      this.showNotification('FORUM.NOTIFICATIONS.LOAD_ERROR', 'error');
    }
  }

  getCategoryName(category: string): string {
    const categories: { [key: string]: string } = {
      'irrigation': 'FORUM.CATEGORIES.IRRIGATION',
      'diseases': 'FORUM.CATEGORIES.DISEASES',
      'yield': 'FORUM.CATEGORIES.YIELD'
    };
    return this.translate.instant(categories[category] || 'FORUM.CATEGORIES.ALL');
  }

  onSearch() {
    this.currentPageNum = 1;
    this.filterTopics();
  }

  filterTopics() {
    let filtered = [...this.allTopics];
    if (this.searchTerm.trim() !== '') {
      const term = this.searchTerm.toLowerCase().trim();
      filtered = filtered.filter(topic =>
        topic.title.toLowerCase().includes(term) ||
        topic.excerpt.toLowerCase().includes(term)
      );
    }
    this.filteredTopics = filtered;
    this.updatePagination();
  }

  changeCategory(category: string) {
    this.currentCategory = category;
    this.showUserTopics = false;
    this.currentPageNum = 1;
    this.loadTopics();
  }

  onSortChange() {
    if (!this.showUserTopics) {
      this.loadTopics();
    }
  }

  updatePagination() {
    this.totalPages = Math.max(1, Math.ceil(this.filteredTopics.length / this.itemsPerPage));
    const startIndex = (this.currentPageNum - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedTopics = this.filteredTopics.slice(startIndex, endIndex);
  }

  previousPage() {
    if (this.currentPageNum > 1) {
      this.currentPageNum--;
      this.updatePagination();
    }
  }

  nextPage() {
    if (this.currentPageNum < this.totalPages) {
      this.currentPageNum++;
      this.updatePagination();
    }
  }

  onTopicImagesSelected(event: any) {
    const files: FileList = event.target.files;
    if (files) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.type.startsWith('image/')) {
          this.selectedImages.push(file);
          const reader = new FileReader();
          reader.onload = (e) => {
            this.imagePreviews.push(e.target?.result as string);
            this.cdr.detectChanges();
          };
          reader.readAsDataURL(file);
        }
      }
    }
  }

  removeTopicImage(index: number) {
    this.selectedImages.splice(index, 1);
    this.imagePreviews.splice(index, 1);
  }

  async uploadImages(files: File[]): Promise<string[]> {
    const uploadPromises = files.map(file => firstValueFrom(this.forumService.uploadImage(file)));
    const results = await Promise.all(uploadPromises);
    return results.map(r => r.url);
  }

  openNewTopicModal() {
    this.showTopicModal = true;
    this.selectedImages = [];
    this.imagePreviews = [];
    this.newTopic = { title: '', category: '', content: '' };
  }

  closeNewTopicModal() {
    this.showTopicModal = false;
    this.resetNewTopic();
  }

  resetNewTopic() {
    this.newTopic = { title: '', category: '', content: '' };
    this.selectedImages = [];
    this.imagePreviews = [];
  }

  async createTopic() {
    if (!this.newTopic.title.trim()) {
      await this.showNotification('FORUM.NOTIFICATIONS.TITLE_REQUIRED', 'error');
      return;
    }
    if (!this.newTopic.category) {
      await this.showNotification('FORUM.NOTIFICATIONS.CATEGORY_REQUIRED', 'error');
      return;
    }
    if (!this.newTopic.content.trim()) {
      await this.showNotification('FORUM.NOTIFICATIONS.CONTENT_REQUIRED', 'error');
      return;
    }

    this.uploadingImages = true;
    let imageUrls: string[] = [];
    if (this.selectedImages.length > 0) {
      try {
        imageUrls = await this.uploadImages(this.selectedImages);
      } catch (error) {
        console.error('Erreur upload images:', error);
        await this.showNotification('FORUM.NOTIFICATIONS.IMAGE_UPLOAD_ERROR', 'error');
        this.uploadingImages = false;
        return;
      }
    }

    const payload = {
      title: this.newTopic.title,
      category: this.newTopic.category,
      fullContent: this.newTopic.content,
      images: imageUrls
    };

    try {
      await firstValueFrom(this.forumService.createTopic(payload));
      await this.loadTopics();
      if (this.showUserTopics) {
        await this.loadMyTopics();
      }
      this.closeNewTopicModal();
      await this.showNotification('FORUM.NOTIFICATIONS.TOPIC_CREATED', 'success');
    } catch (error) {
      console.error('Erreur création sujet:', error);
      await this.showNotification('FORUM.NOTIFICATIONS.CREATE_ERROR', 'error');
    } finally {
      this.uploadingImages = false;
    }
  }

  // forum.page.ts - Dans openTopicDetail, après avoir chargé les réponses
async openTopicDetail(topic: Topic) {
  try {
    const fullTopic = await firstValueFrom(this.forumService.getTopic(topic.id));
    this.selectedTopic = fullTopic;
    const replies = await firstValueFrom(this.forumService.getReplies(topic.id));
    
    // ⭐ Marquer les réponses déjà likées par l'utilisateur actuel
    const currentUserEmail = this.authService.getCurrentUser()?.email;
    this.topicReplies = replies.map(reply => ({
      ...reply,
      userHasMarkedHelpful: reply.helpful_users?.includes(currentUserEmail) || false
    }));
    
    this.newReplyContent = '';
    this.replyImages = [];
    this.replyImagePreviews = [];
    this.showTopicDetailModal = true;
  } catch (error) {
    console.error('Erreur chargement sujet:', error);
    this.showNotification('FORUM.NOTIFICATIONS.LOAD_ERROR', 'error');
  }
}

  closeTopicDetail() {
    this.showTopicDetailModal = false;
    this.selectedTopic = null;
    this.topicReplies = [];
    this.newReplyContent = '';
    this.replyImages = [];
    this.replyImagePreviews = [];
    this.closeImageModal();
  }

  onReplyImagesSelected(event: any) {
    const files: FileList = event.target.files;
    if (files) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.type.startsWith('image/')) {
          this.replyImages.push(file);
          const reader = new FileReader();
          reader.onload = (e) => {
            this.replyImagePreviews.push(e.target?.result as string);
            this.cdr.detectChanges();
          };
          reader.readAsDataURL(file);
        }
      }
    }
  }

  removeReplyImage(index: number) {
    this.replyImages.splice(index, 1);
    this.replyImagePreviews.splice(index, 1);
  }

  async addReply() {
    if (!this.selectedTopic || !this.newReplyContent.trim()) {
      await this.showNotification('FORUM.NOTIFICATIONS.REPLY_REQUIRED', 'error');
      return;
    }

    this.uploadingReplyImages = true;
    let imageUrls: string[] = [];
    if (this.replyImages.length > 0) {
      try {
        imageUrls = await this.uploadImages(this.replyImages);
      } catch (error) {
        console.error('Erreur upload images réponse:', error);
        await this.showNotification('FORUM.NOTIFICATIONS.IMAGE_UPLOAD_ERROR', 'error');
        this.uploadingReplyImages = false;
        return;
      }
    }

    try {
      await firstValueFrom(this.forumService.addReply(this.selectedTopic.id, this.newReplyContent, imageUrls));
      const replies = await firstValueFrom(this.forumService.getReplies(this.selectedTopic.id));
      this.topicReplies = replies;
      this.newReplyContent = '';
      this.replyImages = [];
      this.replyImagePreviews = [];
      const idx = this.allTopics.findIndex(t => t.id === this.selectedTopic!.id);
      if (idx !== -1) {
        this.allTopics[idx].replies++;
        this.filterTopics();
      }
      await this.showNotification('FORUM.NOTIFICATIONS.REPLY_ADDED', 'success');
    } catch (error) {
      console.error('Erreur ajout réponse:', error);
      await this.showNotification('FORUM.NOTIFICATIONS.REPLY_ERROR', 'error');
    } finally {
      this.uploadingReplyImages = false;
    }
  }

  // forum.page.ts - Modifier la méthode markHelpful
async markHelpful(replyId: string) {
  try {
    await firstValueFrom(this.forumService.markHelpful(replyId));
    
    // Mettre à jour l'affichage local
    const reply = this.topicReplies.find(r => r.id === replyId);
    if (reply) {
      reply.helpfulCount++;
      // Optionnel : désactiver le bouton pour ce reply
      // reply.userHasMarkedHelpful = true;
    }
    
    await this.showNotification('Merci ! Votre feedback a été enregistré.', 'success');
  } catch (error: any) {
    console.error('Erreur marque utile:', error);
    const errorMessage = error.error?.detail || 'Vous avez déjà marqué cette réponse comme utile.';
    this.showNotification(errorMessage, 'error');
  }
}

  // Remplacer la méthode reportTopic existante par celle-ci
async reportTopic(topicId: string | undefined) {
  if (!topicId) return;
  
  if (this.selectedTopic && this.isCurrentUserAuthor(this.selectedTopic)) {
    await this.showNotification('FORUM.NOTIFICATIONS.CANNOT_REPORT_OWN', 'error');
    return;
  }
  
  try {
    await firstValueFrom(this.forumService.reportTopic(topicId));
    this.showNotification('FORUM.NOTIFICATIONS.REPORT_SUCCESS', 'success');
    
    // Optionnel : fermer le modal après signalement
    // this.closeTopicDetail();
  } catch (error: any) {
    console.error('Erreur signalement:', error);
    const errorMessage = error.error?.detail || 'FORUM.NOTIFICATIONS.REPORT_ERROR';
    this.showNotification(errorMessage, 'error');
  }
}

  async deleteTopic(topic: Topic, event?: Event) {
    if (event) {
      event.stopPropagation();
    }

    const confirm = await this.showConfirmDialog(
      'Supprimer le sujet',
      `Voulez-vous vraiment supprimer "${topic.title}" ? Cette action est irréversible.`
    );
    if (!confirm) return;

    try {
      await firstValueFrom(this.forumService.deleteTopic(topic.id));
      await this.showNotification('Sujet supprimé avec succès', 'success');

      if (this.showUserTopics) {
        await this.loadMyTopics();
      } else {
        await this.loadTopics();
      }

      if (this.selectedTopic?.id === topic.id) {
        this.closeTopicDetail();
      }
    } catch (error) {
      console.error('Erreur suppression:', error);
      this.showNotification('Erreur lors de la suppression', 'error');
    }
  }

  async showConfirmDialog(header: string, message: string): Promise<boolean> {
    return new Promise(async (resolve) => {
      const alert = await this.alertController.create({
        header,
        message,
        buttons: [
          {
            text: 'Annuler',
            role: 'cancel',
            handler: () => resolve(false)
          },
          {
            text: 'Supprimer',
            handler: () => resolve(true)
          }
        ]
      });
      await alert.present();
    });
  }

  openImageModal(imageUrl: string, caption?: string) {
    this.selectedImageUrl = imageUrl;
    this.selectedImageCaption = caption || null;
  }

  closeImageModal() {
    this.selectedImageUrl = null;
    this.selectedImageCaption = null;
  }

  async showNotification(key: string, type: 'success' | 'error' | 'warning' | 'info' = 'success') {
    const message = this.translate.instant(key);
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'top',
      color: type === 'success' ? 'success' : type === 'error' ? 'danger' : type === 'warning' ? 'warning' : 'primary'
    });
    await toast.present();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  // Ajoutez cette méthode pour le drag & drop des images
onImageDrop(event: DragEvent) {
  event.preventDefault();
  const files = event.dataTransfer?.files;
  if (files) {
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.type.startsWith('image/')) {
        this.selectedImages.push(file);
        const reader = new FileReader();
        reader.onload = (e) => {
          this.imagePreviews.push(e.target?.result as string);
          this.cdr.detectChanges();
        };
        reader.readAsDataURL(file);
      }
    }
  }
}

  onImageError(event: any, name: string) {
    const img = event.target as HTMLImageElement;
    img.src = `https://ui-avatars.com/api/?name=${name}&background=4CAF50&color=fff&size=128`;
  }
}