import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { TranslationService } from '../../services/translation.service';
import { AuthService } from '../../services/auth.service';
import { AdminService, User, Disease, Topic, TopicDetail, AdminStats } from '../../services/admin.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { firstValueFrom } from 'rxjs';
import { environment } from '../../../environments/environment';
export interface Reply {
  id: string;
  topicId: string;
  author: string;
  author_email: string;
  content: string;
  date: Date;
  helpfulCount: number;
  images?: string[];
}

@Component({
  selector: 'app-admin',
  templateUrl: './admin.page.html',
  styleUrls: ['./admin.page.scss'],
  standalone: false
})
export class AdminPage implements OnInit {
  currentLang: string = 'fr';
  activeTab: string = 'dashboard';
  currentDate: Date = new Date();
  adminEmail: string = '';
  navDrawerOpen: boolean = false;

  // Notifications
  notificationsPanelOpen: boolean = false;
  notifications: Notification[] = [];
  unreadNotifications: number = 0;

  users: User[] = [];
  filteredUsers: User[] = [];
  diseases: Disease[] = [];
  filteredDiseases: Disease[] = [];
  recentUsers: User[] = [];
  reportedTopics: Topic[] = [];
  recentTopics: Topic[] = [];
  pendingTopics: Topic[] = [];
  
  stats: AdminStats = {
    totalUsers: 0,
    newUsers: 0,
    totalParcelles: 0,
    totalArea: 0,
    totalTopics: 0,
    pendingTopics: 0,
    totalDiseases: 0,
    diseaseDetections: 0
  };

  userSearchTerm: string = '';
  diseaseSearchTerm: string = '';

  // Modals visibility
  showUserModal: boolean = false;
  showDiseaseModal: boolean = false;
  showDiseaseDetailModal: boolean = false;
  showDeleteModal: boolean = false;
  showReportedTopicModal: boolean = false;

  // Form data
  userForm: any = {};
  
  diseaseForm: {
    name?: string;
    plant?: string;
    severity?: 'Faible' | 'Moyenne' | 'Haute';
    symptoms?: string | string[];
    treatment?: string;
    prevention?: string;
    description?: string;
    images?: string[];
  } = {
    name: '',
    plant: '',
    severity: 'Moyenne',
    symptoms: [],
    treatment: '',
    prevention: '',
    description: '',
    images: []
  };

  editingUser: User | null = null;
  editingDisease: Disease | null = null;
  selectedDiseaseForDetail: Disease | null = null;
  
  // Reported topic consultation
  selectedReportedTopic: TopicDetail | null = null;
  reportedTopicReplies: Reply[] = [];
  loadingReportedTopic: boolean = false;

  // Loading states
  savingUser: boolean = false;
  savingDisease: boolean = false;
  deleting: boolean = false;

  // Password visibility
  showPassword: boolean = false;

  // Upload d'images
  selectedFiles: File[] = [];
  imagesToDelete: string[] = [];

  // Image modal
  selectedImageUrl: string | null = null;
  selectedImageCaption: string | null = null;

  // Delete confirmation
  deleteItemType: 'user' | 'disease' | 'topic' = 'user';
  deleteItemId: string | null = null;
  deleteItemName: string = '';

  constructor(
    private router: Router,
    private translationService: TranslationService,
    private authService: AuthService,
    private adminService: AdminService,
    private notificationService: NotificationService,
    private toastController: ToastController,
    private cdr: ChangeDetectorRef
  ) {
    this.currentLang = this.translationService.getCurrentLang();
  }

  ngOnInit() {
    this.loadAllData();
    this.loadPendingTopics();
    this.setAdminEmail();
    this.loadAdminNotifications();
  }

  ionViewWillEnter() {
    const user = this.authService.getCurrentUser();
    if (!user || user.role !== 'admin') {
      this.router.navigate(['/accueil']);
    } else {
      this.loadAllData();
      this.loadPendingTopics();
      this.setAdminEmail();
      this.loadAdminNotifications();
    }
  }

  // ==================== NOTIFICATIONS ====================
  async loadAdminNotifications() {
    try {
      const result = await firstValueFrom(this.notificationService.getAdminUnreadCount());
      this.unreadNotifications = result.unreadCount;
      this.notifications = await firstValueFrom(this.notificationService.getNotifications());
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Error loading notifications:', error);
    }
  }

  async markNotificationAsRead(notificationId: string) {
    try {
      await firstValueFrom(this.notificationService.markAsRead(notificationId));
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) notif.read = true;
      this.unreadNotifications = this.notifications.filter(n => !n.read).length;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  }

  async markAllNotificationsAsRead() {
    try {
      await firstValueFrom(this.notificationService.markAllAsRead());
      this.notifications.forEach(n => n.read = true);
      this.unreadNotifications = 0;
      this.cdr.detectChanges();
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  }

  toggleNotificationsPanel() {
    this.notificationsPanelOpen = !this.notificationsPanelOpen;
  }

  closeNotificationsPanel() {
    this.notificationsPanelOpen = false;
  }

  // ==================== UTILITAIRES ====================
  setAdminEmail() {
    const user = this.authService.getCurrentUser();
    this.adminEmail = user?.email || 'admin@agritunisie.com';
  }

  toggleNavDrawer() {
    this.navDrawerOpen = !this.navDrawerOpen;
  }

  closeNavDrawer() {
    this.navDrawerOpen = false;
  }

  changeLanguage(lang: string) {
    this.translationService.switchLanguage(lang);
    this.currentLang = lang;
    this.cdr.detectChanges();
  }

  logout() {
    this.authService.logout();
  }

  setActiveTab(tab: string) {
    this.activeTab = tab;
    this.closeNavDrawer();
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  getCategoryName(category: string | undefined): string {
  const categories: { [key: string]: string } = {
    'irrigation': 'Irrigation',
    'diseases': 'Maladies',
    'yield': 'Rendement'
  };
  return categories[category || ''] || 'Général';
}

  // ==================== CHARGEMENT DES DONNÉES ====================
  async loadAllData() {
    try {
      const users = await firstValueFrom(this.adminService.getUsers());
      const diseases = await firstValueFrom(this.adminService.getDiseases());
      const stats = await firstValueFrom(this.adminService.getStats());
      const reportedTopics = await firstValueFrom(this.adminService.getReportedTopics());
      const recentTopics = await firstValueFrom(this.adminService.getRecentTopics());

      this.users = users || [];
      this.filteredUsers = [...this.users];
      this.diseases = diseases || [];
      this.filteredDiseases = [...this.diseases];
      this.stats = stats || this.stats;
      this.reportedTopics = reportedTopics || [];
      this.recentTopics = recentTopics || [];

      this.recentUsers = [...this.users]
        .sort((a, b) => {
          const dateA = a.date ? new Date(a.date).getTime() : 0;
          const dateB = b.date ? new Date(b.date).getTime() : 0;
          return dateB - dateA;
        })
        .slice(0, 5);

      this.cdr.detectChanges();
    } catch (error) {
      console.error('Error loading data:', error);
      this.showNotification('Erreur de chargement des données', 'error');
    }
  }

  async loadPendingTopics() {
    try {
      this.pendingTopics = await firstValueFrom(this.adminService.getPendingTopics());
    } catch (error) {
      console.error('Error loading pending topics:', error);
    }
  }

  // ==================== FILTRES ====================
  filterUsers() {
    if (!this.userSearchTerm.trim()) {
      this.filteredUsers = [...this.users];
    } else {
      const term = this.userSearchTerm.toLowerCase().trim();
      this.filteredUsers = this.users.filter(u =>
        u.name.toLowerCase().includes(term) ||
        u.email.toLowerCase().includes(term)
      );
    }
  }

  filterDiseases() {
    if (!this.diseaseSearchTerm.trim()) {
      this.filteredDiseases = [...this.diseases];
    } else {
      const term = this.diseaseSearchTerm.toLowerCase().trim();
      this.filteredDiseases = this.diseases.filter(d =>
        d.name.toLowerCase().includes(term) ||
        (d.plants && d.plants.some(p => p.toLowerCase().includes(term))) ||
        (d.description && d.description.toLowerCase().includes(term))
      );
    }
  }

  // ==================== MÉTHODES UTILITAIRES POUR L'AFFICHAGE ====================
  getFirstImage(disease: Disease): string {
    if (disease.images && disease.images.length > 0) {
      return disease.images[0];
    }
    return 'assets/default-disease.jpg';
  }

  getFirstPlant(disease: Disease): string {
    if (disease.plants && disease.plants.length > 0) {
      return disease.plants[0];
    }
    return 'Plante non spécifiée';
  }

  onImageError(event: any) {
    event.target.src = 'assets/default-disease.jpg';
  }

  getFilePreviewUrl(file: File): string {
    return URL.createObjectURL(file);
  }

  openImageModal(imageUrl: string, caption?: string) {
    this.selectedImageUrl = imageUrl;
    this.selectedImageCaption = caption || null;
  }

  closeImageModal() {
    this.selectedImageUrl = null;
    this.selectedImageCaption = null;
  }

  // ==================== GESTION DES IMAGES POUR L'UPLOAD ====================
  onFilesSelected(event: any) {
    const files = Array.from(event.target.files) as File[];
    const validFiles: File[] = [];
    
    for (const file of files) {
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
      const isValidType = validTypes.includes(file.type);
      const isValidSize = file.size <= 5 * 1024 * 1024;
      
      if (!isValidType) {
        this.showNotification(`Format non supporté: ${file.name}`, 'error');
      } else if (!isValidSize) {
        this.showNotification(`Fichier trop volumineux: ${file.name} (max 5MB)`, 'error');
      } else {
        validFiles.push(file);
      }
    }
    
    this.selectedFiles = [...this.selectedFiles, ...validFiles];
  }

  removeSelectedFile(index: number) {
    this.selectedFiles.splice(index, 1);
  }

  removeExistingImage(imageUrl: string) {
    const filename = imageUrl.split('/').pop();
    if (filename) {
      this.imagesToDelete.push(filename);
      const index = this.diseaseForm.images?.indexOf(imageUrl);
      if (index !== undefined && index > -1) {
        this.diseaseForm.images?.splice(index, 1);
      }
    }
  }

  prepareDiseaseFormData(): FormData {
    const formData = new FormData();
    
    formData.append('name', this.diseaseForm.name || '');
    formData.append('plant', this.diseaseForm.plant || '');
    formData.append('severity', this.diseaseForm.severity || 'Moyenne');
    
    const symptomsValue = typeof this.diseaseForm.symptoms === 'string' 
      ? this.diseaseForm.symptoms 
      : (this.diseaseForm.symptoms as string[]).join('\n');
    formData.append('symptoms', symptomsValue);
    
    formData.append('treatment', this.diseaseForm.treatment || '');
    
    if (this.diseaseForm.prevention) {
      formData.append('prevention', this.diseaseForm.prevention);
    }
    if (this.diseaseForm.description) {
      formData.append('description', this.diseaseForm.description);
    }
    
    this.selectedFiles.forEach(file => {
      formData.append('images', file);
    });
    
    return formData;
  }

  // ==================== GESTION DES UTILISATEURS ====================
  openUserModal(user?: User) {
    if (user) {
      this.editingUser = user;
      this.userForm = {
        name: user.name,
        email: user.email,
        role: user.role,
        status: user.status,
        password: ''
      };
    } else {
      this.editingUser = null;
      this.userForm = {
        name: '',
        email: '',
        role: 'user',
        status: 'actif',
        password: ''
      };
    }
    this.showPassword = false;
    this.showUserModal = true;
  }

  closeUserModal() {
    this.showUserModal = false;
    this.editingUser = null;
    this.userForm = {};
    this.showPassword = false;
    this.savingUser = false;
  }

  async saveUser() {
    if (!this.userForm.name || !this.userForm.email) {
      this.showNotification('Veuillez remplir tous les champs obligatoires', 'error');
      return;
    }
    
    if (!this.editingUser && (!this.userForm.password || this.userForm.password.length < 6)) {
      this.showNotification('Le mot de passe doit contenir au moins 6 caractères', 'error');
      return;
    }

    this.savingUser = true;

    try {
      const userData: any = {
        name: this.userForm.name,
        email: this.userForm.email,
        role: this.userForm.role,
        status: this.userForm.status
      };
      
      if (this.userForm.password && this.userForm.password.trim() !== '') {
        userData.password = this.userForm.password;
      }
      
      if (this.editingUser) {
        await firstValueFrom(this.adminService.updateUser(this.editingUser.id, userData));
        this.showNotification('Utilisateur modifié avec succès', 'success');
      } else {
        await firstValueFrom(this.adminService.createUser(userData));
        this.showNotification('Utilisateur créé avec succès', 'success');
      }
      
      await this.loadAllData();
      this.closeUserModal();
    } catch (error: any) {
      console.error('Error saving user:', error);
      const errorMessage = error.error?.detail || 'Erreur lors de la sauvegarde';
      this.showNotification(errorMessage, 'error');
    } finally {
      this.savingUser = false;
    }
  }

  async toggleUserStatus(user: User) {
    const newStatus = user.status === 'actif' ? 'inactif' : 'actif';
    try {
      await firstValueFrom(this.adminService.updateUser(user.id, { status: newStatus }));
      user.status = newStatus;
      this.filterUsers();
      this.showNotification(`Utilisateur ${newStatus === 'actif' ? 'activé' : 'suspendu'}`, 'success');
    } catch (error) {
      console.error('Error updating status:', error);
      this.showNotification('Erreur lors de la mise à jour', 'error');
    }
  }

  // ==================== GESTION DES MALADIES ====================
  openDiseaseModal(disease?: Disease) {
    this.selectedFiles = [];
    this.imagesToDelete = [];
    
    if (disease) {
      this.editingDisease = disease;
      this.diseaseForm = {
        name: disease.name,
        plant: disease.plants && disease.plants.length ? disease.plants.join(', ') : '',
        severity: disease.severity,
        symptoms: disease.symptoms.join('\n'),
        treatment: disease.treatment,
        prevention: disease.prevention || '',
        description: disease.description || '',
        images: disease.images ? [...disease.images] : []
      };
    } else {
      this.editingDisease = null;
      this.diseaseForm = {
        name: '',
        plant: '',
        severity: 'Moyenne',
        symptoms: '',
        treatment: '',
        prevention: '',
        description: '',
        images: []
      };
    }
    this.showDiseaseModal = true;
  }

  closeDiseaseModal() {
    this.showDiseaseModal = false;
    this.editingDisease = null;
    this.selectedFiles = [];
    this.imagesToDelete = [];
    this.savingDisease = false;
    this.diseaseForm = {
      name: '',
      plant: '',
      severity: 'Moyenne',
      symptoms: '',
      treatment: '',
      prevention: '',
      description: '',
      images: []
    };
  }

  async saveDisease() {
    if (!this.diseaseForm.name) {
      this.showNotification('Veuillez saisir le nom de la maladie', 'error');
      return;
    }

    this.savingDisease = true;
    const formData = this.prepareDiseaseFormData();

    try {
      if (this.editingDisease) {
        const imagesToKeep = this.diseaseForm.images || [];
        formData.append('existing_images', JSON.stringify(imagesToKeep));
        await firstValueFrom(this.adminService.updateDiseaseWithImages(this.editingDisease.id, formData));
        this.showNotification('Maladie modifiée avec succès', 'success');
      } else {
        await firstValueFrom(this.adminService.createDiseaseWithImages(formData));
        this.showNotification('Maladie créée avec succès', 'success');
      }
      
      await this.loadAllData();
      this.closeDiseaseModal();
    } catch (error) {
      console.error('Error saving disease:', error);
      this.showNotification('Erreur lors de la sauvegarde', 'error');
    } finally {
      this.savingDisease = false;
    }
  }

  openDiseaseDetailModal(disease: Disease) {
    this.selectedDiseaseForDetail = disease;
    this.showDiseaseDetailModal = true;
  }

  closeDiseaseDetailModal() {
    this.showDiseaseDetailModal = false;
    this.selectedDiseaseForDetail = null;
  }

  // ==================== GESTION DES SUJETS SIGNALÉS ====================
  async viewReportedTopic(topic: Topic) {
  this.loadingReportedTopic = true;
  
  try {
    // Récupérer les détails complets du sujet
    const fullTopic = await firstValueFrom(this.adminService.getTopicById(topic.id));
    this.selectedReportedTopic = fullTopic;
    
    // Récupérer les réponses du sujet
    this.reportedTopicReplies = await firstValueFrom(this.adminService.getTopicReplies(topic.id));
    
    this.showReportedTopicModal = true;
  } catch (error) {
    console.error('Error loading topic details:', error);
    this.showNotification('Erreur lors du chargement du sujet', 'error');
  } finally {
    this.loadingReportedTopic = false;
  }
}


  closeReportedTopicModal() {
    this.showReportedTopicModal = false;
    this.selectedReportedTopic = null;
    this.reportedTopicReplies = [];
  }

  async approveTopicFromModal() {
    if (!this.selectedReportedTopic) return;
    
    try {
      await firstValueFrom(this.adminService.approveTopic(this.selectedReportedTopic.id));
      this.reportedTopics = this.reportedTopics.filter(t => t.id !== this.selectedReportedTopic!.id);
      this.showNotification('Sujet approuvé', 'success');
      this.closeReportedTopicModal();
      await this.loadAllData();
    } catch (error) {
      console.error('Error approving topic:', error);
      this.showNotification('Erreur lors de l\'approbation', 'error');
    }
  }

  deleteTopicFromModal() {
    if (!this.selectedReportedTopic) return;
    
    this.deleteItemType = 'topic';
    this.deleteItemId = this.selectedReportedTopic.id;
    this.deleteItemName = this.selectedReportedTopic.title;
    this.showDeleteModal = true;
    this.closeReportedTopicModal();
  }

  // ==================== SUPPRESSION ====================
  confirmDeleteUser(user: User) {
    this.deleteItemType = 'user';
    this.deleteItemId = user.id;
    this.deleteItemName = user.name;
    this.showDeleteModal = true;
  }

  confirmDeleteDisease(disease: Disease) {
    this.deleteItemType = 'disease';
    this.deleteItemId = disease.id;
    this.deleteItemName = disease.name;
    this.showDeleteModal = true;
  }

  async confirmDelete() {
    if (!this.deleteItemId) return;
    
    this.deleting = true;

    try {
      if (this.deleteItemType === 'user') {
        await firstValueFrom(this.adminService.deleteUser(this.deleteItemId));
        this.showNotification('Utilisateur supprimé', 'success');
      } else if (this.deleteItemType === 'disease') {
        await firstValueFrom(this.adminService.deleteDisease(this.deleteItemId));
        this.showNotification('Maladie supprimée', 'success');
      } else if (this.deleteItemType === 'topic') {
        await firstValueFrom(this.adminService.deleteTopic(this.deleteItemId));
        this.showNotification('Sujet supprimé', 'success');
      }
      
      await this.loadAllData();
      await this.loadPendingTopics();
      await this.loadAdminNotifications();
      this.showDeleteModal = false;
    } catch (error) {
      console.error('Error deleting:', error);
      this.showNotification('Erreur lors de la suppression', 'error');
    } finally {
      this.deleting = false;
    }
  }

  // ==================== ACTIONS FORUM ====================
  async approveTopic(topic: Topic) {
    try {
      await firstValueFrom(this.adminService.approveTopic(topic.id));
      this.reportedTopics = this.reportedTopics.filter(t => t.id !== topic.id);
      this.showNotification('Sujet approuvé', 'success');
    } catch (error) {
      console.error('Error approving topic:', error);
      this.showNotification('Erreur lors de l\'approbation', 'error');
    }
  }

  deleteTopic(topic: Topic) {
    this.deleteItemType = 'topic';
    this.deleteItemId = topic.id;
    this.deleteItemName = topic.title;
    this.showDeleteModal = true;
  }

  viewTopic(topic: Topic) {
    this.router.navigate(['/forum', topic.id]);
  }

  async approveForumTopic(topic: Topic) {
    try {
      await firstValueFrom(this.adminService.approveForumTopic(topic.id));
      this.pendingTopics = this.pendingTopics.filter(t => t.id !== topic.id);
      this.showNotification('Sujet approuvé', 'success');
    } catch (error) {
      console.error('Error approving topic:', error);
      this.showNotification('Erreur lors de l\'approbation', 'error');
    }
  }

  async rejectForumTopic(topic: Topic) {
    try {
      await firstValueFrom(this.adminService.rejectForumTopic(topic.id));
      this.pendingTopics = this.pendingTopics.filter(t => t.id !== topic.id);
      this.showNotification('Sujet rejeté', 'success');
    } catch (error) {
      console.error('Error rejecting topic:', error);
      this.showNotification('Erreur lors du rejet', 'error');
    }
  }

  async deleteForumTopic(topic: Topic) {
    try {
      await firstValueFrom(this.adminService.deleteForumTopic(topic.id));
      this.pendingTopics = this.pendingTopics.filter(t => t.id !== topic.id);
      this.showNotification('Sujet supprimé', 'success');
    } catch (error) {
      console.error('Error deleting topic:', error);
      this.showNotification('Erreur lors de la suppression', 'error');
    }
  }

  // ==================== NOTIFICATIONS TOAST ====================
  async showNotification(message: string, type: 'success' | 'error' | 'warning' | 'info' = 'success') {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'top',
      color: type === 'success' ? 'success' : type === 'error' ? 'danger' : type === 'warning' ? 'warning' : 'primary'
    });
    await toast.present();
  }
}