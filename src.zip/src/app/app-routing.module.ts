import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './services/auth.guards';
import { FarmSetupGuard } from './services/farm-setup.guards';
import { DashboardGuard } from './services/dashboard.guards';
import { AdminGuard } from './services/admin.guard';
import { ResetPasswordGuard } from './services/reset-password.guard';
import { SetPasswordGuard } from './services/set-password.guard';
import { SimpleCallbackComponent } from './components/simple-callback/simple-callback.component';

const routes: Routes = [
  {
    path: 'auth-callback',
    component: SimpleCallbackComponent
  },
  {
    path: 'forgot-password',
    loadChildren: () => import('./pages/forgot-password/forgot-password.module').then(m => m.ForgotPasswordPageModule)
  },
  {
    path: 'reset-password',
    loadChildren: () => import('./pages/reset-password/reset-password.module').then(m => m.ResetPasswordPageModule),
    canActivate: [ResetPasswordGuard]
  },
  {
    path: 'set-password',
    loadChildren: () => import('./pages/set-password/set-password.module').then(m => m.SetPasswordPageModule),
    canActivate: [AuthGuard, SetPasswordGuard]
  },
  {
    path: 'accueil',
    loadChildren: () => import('./pages/accueil/accueil.module').then(m => m.AccueilPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then(m => m.LoginPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./pages/register/register.module').then(m => m.RegisterPageModule)
  },
  {
    path: 'demo',
    loadChildren: () => import('./pages/demo/demo.module').then(m => m.DemoPageModule)
  },
  {
    path: 'farm-setup',
    loadChildren: () => import('./pages/farm-setup/farm-setup.module').then(m => m.FarmSetupPageModule),
    canActivate: [AuthGuard, FarmSetupGuard]
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./pages/dashboard/dashboard.module').then(m => m.DashboardPageModule),
    canActivate: [AuthGuard, DashboardGuard]
  },
  {
    path: 'irrigation',
    loadChildren: () => import('./pages/irrigation/irrigation.module').then(m => m.IrrigationPageModule),
    canActivate: [AuthGuard, DashboardGuard]
  },
  {
    path: 'diseases',
    loadChildren: () => import('./pages/diseases/diseases.module').then(m => m.DiseasesPageModule),
    canActivate: [AuthGuard, DashboardGuard]
  },
  {
    path: 'forum',
    loadChildren: () => import('./pages/forum/forum.module').then(m => m.ForumPageModule),
    canActivate: [AuthGuard, DashboardGuard]
  },
  {
    path: 'history',
    loadChildren: () => import('./pages/history/history.module').then(m => m.HistoryPageModule),
    canActivate: [AuthGuard, DashboardGuard]
  },
  {
    path: 'rendement',
    loadChildren: () => import('./pages/rendement/rendement.module').then(m => m.RendementPageModule),
    canActivate: [AuthGuard, DashboardGuard]
  },
  {
    path: 'admin',
    loadChildren: () => import('./pages/admin/admin.module').then(m => m.AdminPageModule),
    canActivate: [AuthGuard, AdminGuard]
  },
  {
    path: '',
    redirectTo: 'accueil',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'accueil'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }