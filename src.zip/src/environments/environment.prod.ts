export const environment = {
  production: true,   // or true for prod
  apiUrl: 'https://agritunisie-backend.onrender.com',
  baseUrl: 'https://agritunisie-backend.onrender.com',
  hfToken: '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'  // keep as is or move to env var
};